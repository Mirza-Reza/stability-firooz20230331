"""
Predictive Peng Robinson 78 EoS  (PPR78) for mixtures
J.-N. Jaubert, F. Mutelet / Fluid Phase Equilibria 224 (2004) 285–304 (doi:10.1016/j.fluid.2004.06.059)
@author: Gustavo Oviedo
"""
import os

import numpy as np
import copy
from sklearn import linear_model
import csv
import pandas as pd
import matplotlib.pyplot as plt
# import functions
import csv
import math
import scipy.optimize
from scipy.optimize import fsolve, least_squares

from sympy import symbols, Eq, solve
import time
from sklearn.metrics import mean_squared_error, r2_score

import mixingRules
from PPR78 import EoS
from mixingRules import mixRules
from fugacity import fug
from fugacityCriteria import fugC
from rachfordRiceEq import rrm
from theta import thetaFunc
from solver import solveEOS
from carbon import addCarbon

import warnings
import random

fixedKij = []

warnings.filterwarnings("ignore",
                        category=np.VisibleDeprecationWarning)  # I need to check the reason.  =asanyarray(ary)

t1 = time.perf_counter() # It does include time elapsed during sleep and is system-wide.
t2 = time.time()
t3=time.process_time() #It does not include time elapsed during sleep.
t4=time.thread_time()   #It does not include time elapsed during sleep.




# #=========================dead oil (x1)=========================================
# composition = [{'name': '2,2-dimethylbutane', 'z': 0.1192, 'Tc': 489.21, 'Pc': 3102000, 'w': 0.2251},
#                {'name': 'n-heptane', 'z': 0.1047, 'Tc': 540.3, 'Pc': 2734000, 'w': 0.3481},
#                {'name': 'ethylcyclohexane', 'z': 0.0621, 'Tc': 606.9, 'Pc': 3250000, 'w': 0.318},
#                {'name': 'n-nonane', 'z': 0.0503, 'Tc': 594.7, 'Pc': 2280000, 'w': 0.4409},
#                {'name': 'propylcyclohexane', 'z': 0.0301, 'Tc': 630.8, 'Pc': 2860000, 'w': 0.3149},
#                {'name': '1,2,3,4-tetrahydronaphthalene', 'z': 0.0454, 'Tc': 719.5, 'Pc': 3630000, 'w': 0.3318},
#                {'name': '1,3,5-triethylbenzene', 'z': 0.0666, 'Tc': 679, 'Pc': 2330000, 'w': 0.507},
#                {'name': '1-phenylhexane', 'z': 0.0379, 'Tc': 695, 'Pc': 2350000, 'w': 0.4498},
#                {'name': 'n-tridecane', 'z': 0.0127, 'Tc': 676, 'Pc': 1679000, 'w': 0.6099},
#                {'name': '1-phenyloctane', 'z': 0.0638, 'Tc': 725, 'Pc': 1980000, 'w': 0.5845},
#                {'name': 'n-pentadecane', 'z': 0.0310, 'Tc': 707.5, 'Pc': 1479000, 'w': 0.7192},
#                {'name': 'n-hexadecane', 'z': 0.0131, 'Tc': 722.4, 'Pc': 1401000, 'w': 0.7442},
#                {'name': 'octadecane', 'z': 0.0420, 'Tc': 747.7, 'Pc': 1292000, 'w': 0.802},
#                {'name': 'nonadecane', 'z': 0.0365, 'Tc': 755.3, 'Pc': 1160000, 'w': 0.8722},
#                {'name': '1-phenylhexadecane', 'z': 0.0449, 'Tc': 827.35, 'Pc': 1279000, 'w': 0.9055},
#                {'name': 'tetracosane', 'z': 0.0066, 'Tc': 799.8, 'Pc': 1075000, 'w': 1.184},
#                {'name': 'squalane', 'z': 0.2331, 'Tc': 820, 'Pc': 900000, 'w': 1.2436}]
#
#                # {'name': 'methane', 'z': 0.0, 'Tc': 190.56, 'Pc': 4599000, 'w': 0.01},
#                # {'name': 'ethane', 'z': 0.0, 'Tc': 305.32, 'Pc': 4885000, 'w': 0.099},
#                # {'name': 'propane', 'z': 0.0, 'Tc': 370.01, 'Pc': 4260000, 'w': 0.152}]
#
# nc = len(composition)  # Components number of the composition

#====================live oil-x2  ==================================
# composition = [{'name': '2,2-dimethylbutane', 'z': 0.0715, 'Tc': 489.21, 'Pc': 3102000, 'w': 0.2251},
#                {'name': 'n-heptane', 'z': 0.0628, 'Tc': 540.3, 'Pc': 2734000, 'w': 0.3481},
#                {'name': 'ethylcyclohexane', 'z': 0.0373, 'Tc': 606.9, 'Pc': 3250000, 'w': 0.318},
#                {'name': 'n-nonane', 'z': 0.0302, 'Tc': 594.7, 'Pc': 2280000, 'w': 0.4409},
#                {'name': 'propylcyclohexane', 'z': 0.0181, 'Tc': 630.8, 'Pc': 2860000, 'w': 0.3149},
#                {'name': '1,2,3,4-tetrahydronaphthalene', 'z': 0.0272, 'Tc': 719.5, 'Pc': 3630000, 'w': 0.3318},
#                {'name': '1,3,5-triethylbenzene', 'z': 0.04, 'Tc': 679, 'Pc': 2330000, 'w': 0.507},
#                {'name': '1-phenylhexane', 'z': 0.0227, 'Tc': 695, 'Pc': 2350000, 'w': 0.4498},
#                {'name': 'n-tridecane', 'z': 0.0076, 'Tc': 676, 'Pc': 1679000, 'w': 0.6099},
#                {'name': '1-phenyloctane', 'z': 0.0383, 'Tc': 725, 'Pc': 1980000, 'w': 0.5845},
#                {'name': 'n-pentadecane', 'z': 0.0186, 'Tc': 707.5, 'Pc': 1479000, 'w': 0.7192},
#                {'name': 'n-hexadecane', 'z': 0.0079, 'Tc': 722.4, 'Pc': 1401000, 'w': 0.7442},
#                {'name': 'octadecane', 'z': 0.0252, 'Tc': 747.7, 'Pc': 1292000, 'w': 0.802},
#                {'name': 'nonadecane', 'z': 0.0219, 'Tc': 755.3, 'Pc': 1160000, 'w': 0.8722},
#                {'name': '1-phenylhexadecane', 'z': 0.0269, 'Tc': 827.35, 'Pc': 1279000, 'w': 0.9055},
#                {'name': 'tetracosane', 'z': 0.004, 'Tc': 799.8, 'Pc': 1075000, 'w': 1.184},
#                {'name': 'squalane', 'z': 0.1399, 'Tc': 820, 'Pc': 900000, 'w': 1.2436},
#                {'name': 'methane', 'z': 0.3252, 'Tc': 190.56, 'Pc': 4599000, 'w': 0.01},
#                {'name': 'ethane', 'z': 0.0504, 'Tc': 305.32, 'Pc': 4885000, 'w': 0.099},
#                {'name': 'propane', 'z': 0.0244, 'Tc': 370.01, 'Pc': 4260000, 'w': 0.152}]
# nc = len(composition)  # Components number of the composition
#==================================================================

#=========================Live oil =x3=========================================
composition = [{'name': '2,2-dimethylbutane', 'z': 0.0417, 'Tc': 489.21, 'Pc': 3102000, 'w': 0.2251},
               {'name': 'n-heptane', 'z': 0.0366, 'Tc': 540.3, 'Pc': 2734000, 'w': 0.3481},
               {'name': 'ethylcyclohexane', 'z': 0.0217, 'Tc': 606.9, 'Pc': 3250000, 'w': 0.318},
               {'name': 'n-nonane', 'z': 0.0176, 'Tc': 594.7, 'Pc': 2280000, 'w': 0.4409},
               {'name': 'propylcyclohexane', 'z': 0.0105, 'Tc': 630.8, 'Pc': 2860000, 'w': 0.3149},
               {'name': '1,2,3,4-tetrahydronaphthalene', 'z': 0.0159, 'Tc': 719.5, 'Pc': 3630000, 'w': 0.3318},
               {'name': '1,3,5-triethylbenzene', 'z': 0.0233, 'Tc': 679, 'Pc': 2330000, 'w': 0.507},
               {'name': '1-phenylhexane', 'z': 0.0133, 'Tc': 695, 'Pc': 2350000, 'w': 0.4498},
               {'name': 'n-tridecane', 'z': 0.0044, 'Tc': 676, 'Pc': 1679000, 'w': 0.6099},
               {'name': '1-phenyloctane', 'z': 0.0223, 'Tc': 725, 'Pc': 1980000, 'w': 0.5845},
               {'name': 'n-pentadecane', 'z': 0.0109, 'Tc': 707.5, 'Pc': 1479000, 'w': 0.7192},
               {'name': 'n-hexadecane', 'z': 0.0046, 'Tc': 722.4, 'Pc': 1401000, 'w': 0.7442},
               {'name': 'octadecane', 'z': 0.0147, 'Tc': 747.7, 'Pc': 1292000, 'w': 0.802},
               {'name': 'nonadecane', 'z': 0.0128, 'Tc': 755.3, 'Pc': 1160000, 'w': 0.8722},
               {'name': '1-phenylhexadecane', 'z': 0.0157, 'Tc': 827.35, 'Pc': 1279000, 'w': 0.9055},
               {'name': 'tetracosane', 'z': 0.0023, 'Tc': 799.8, 'Pc': 1075000, 'w': 1.184},
               {'name': 'squalane', 'z': 0.0816, 'Tc': 820, 'Pc': 900000, 'w': 1.2436},
               {'name': 'methane', 'z': 0.5285, 'Tc': 190.56, 'Pc': 4599000, 'w': 0.01},
               {'name': 'ethane', 'z': 0.0819, 'Tc': 305.32, 'Pc': 4885000, 'w': 0.099},
               {'name': 'propane', 'z': 0.0397, 'Tc': 370.01, 'Pc': 4260000, 'w': 0.152}]

nc = len(composition)  # Components number of the composition

#========================================================================================




#======initial guess for x2 and x3 =======================================
#Produced by Matlab code
#
# xo = np.array([[0.01, 0.1, 0.005],
#                [0.015, 0.09, 0.105],
#                [0.02, 0.08, 0.205],
#                [0.025, 0.07, 0.105],
#                [0.03, 0.06, 0.108333333333333],
#                [0.035, 0.05, 0.00833333333333333],
#                [0.04, 0.04, 0.0116666666666667],
#                [0.045, 0.03, 0.015],
#                [0.05, 0.03125, 0.0183333333333333],
#                [0.055, 0.0325, 0.0216666666666667],
#                [0.06, 0.03375, 0.025],
#                [0.0625, 0.035, 0.0283333333333333],
#                [0.065, 0.03625, 0.0316666666666667],
#                [0.0675, 0.0375, 0.035],
#                [0.07, 0.03875, 0.0383333333333333],
#                [0.0725, 0.04, 0.0416666666666667],
#                [0.075, 0.04125, 0.045],
#                [0.0775, 0.0425, 0.0483333333333333],
#                [0.08, 0.04375, 0.0516666666666667],
#                [0.045, 0.0675, 0.05167]])

# initial guess of the molar fraction equilibrium composition of zi
################# play for observasions##########################3

# import numpy as np, numpy.random
# print(np.random.dirichlet(np.ones(3),size=20))
# To generate rows sum to 1, use above code
beta = np.array([[0.381, 0.09, 0.5285]])

# from numpy.core.fromnumeric import transpose
# # import numpy as np, numpy.random
# xoo=np.random.dirichlet(np.ones(20),size=3)
# xo=np.array(transpose(xoo))
####################################3
# z=np.zeros((20,1))
# for t in range(len(xo[:,2])):
#     A= xo[:,0]
#     z[t] = composition[t]['z']
#     xo[t,2]=(z[t]-(beta[0,0]*xo[t,0])-(beta[0,1]*xo[t,1]))/beta[0,2]
#
#     print((xo))
#     print((z,'=======================', max(z)))

#
# print(sum(xo[:,2]))
# # print(xo[0,2])
# # print(beta[0,2])
# xoLast=xo[-1,2]
# print(xoLast)
# xo[-1,2]=1-(sum(xo[:,2])-xoLast)
# print(xo[-1,2],'AAAAAAAAAAAAAAAAAAAAA', xoLast, xoLast+xo[-1,2])
# print(sum(xo[:,2]))
# xx=xo

# To generate columns sum to 1, use above code
###################################################
# # this initial guess is generated randomly and the results didnt change, mining that the calculation is not rely on InG
#
#
xo = np.array([[8.95462861e-04,7.26575284e-03,8.97659689e-02],
                 [1.99524433e-02,2.53132148e-02,7.03574295e-02],
                 [7.25769379e-02,4.84908405e-02,1.83857950e-05],
                 [1.18398278e-01,1.31392545e-01,2.74714341e-02],
                 [2.06984222e-02,4.46545332e-02,2.67048477e-02],
                 [8.22529882e-02,1.82743006e-02,4.44816819e-02],
                 [1.03133692e-02,8.08897533e-02,2.29176145e-02],
                 [2.92232299e-02,1.12083674e-02,1.24046563e-02],
                 [1.59088444e-01,1.28949413e-02,4.78702442e-02],
                 [1.52174445e-02,1.21133189e-02,7.12133382e-02],
                 [4.03845243e-02,1.03677277e-01,2.46897496e-01],
                 [1.81436595e-02,2.85969417e-03,3.90366756e-03],
                 [1.03896707e-02,1.96190525e-02,1.66912594e-02],
                 [7.60145152e-03,1.68300294e-03,3.66444062e-02],
                 [4.89561438e-02,2.51930966e-01,3.78553825e-02],
                 [1.78458940e-02,1.30034543e-01,3.75956657e-02],
                 [2.60442607e-02,9.43520675e-03,2.27755605e-02],
                 [2.28570110e-01,4.19722040e-02,1.88475341e-02],
                 [7.20918159e-02,3.05252736e-02,1.26898946e-01],
                 [1.35544932e-03,1.57652120e-02,3.86844810e-02]])

# xo = np.array([[0.00191971,0.01337566,0.02145679],
#                  [0.04155901,0.02334115,0.00879811],
#                  [0.02360892,0.11162969,0.09836033],
#                  [0.03297239,0.16142069,0.01210876],
#                  [0.05091514,0.03953436,0.00564079],
#                  [0.06593678,0.07482758,0.11268936],
#                  [0.01368815,0.05250511,0.04214342],
#                  [0.00674704,0.04963918,0.01796498],
#                  [0.05756473,0.00165546,0.02975071],
#                  [0.04102528,0.01355948,0.03065223],
#                  [0.03123083,0.00166727,0.15204763],
#                  [0.18076734,0.07657221,0.09154497],
#                  [0.00850867,0.01134484,0.0660299],
#                  [0.07784341,0.01335915,0.01402315],
#                  [0.04121271,0.09011272,0.02768873],
#                  [0.18154008,0.08373844,0.00676119],
#                  [0.01051587,0.08629486,0.0673802],
#                  [0.01354542,0.0240844,0.05605855],
#                  [0.04047392,0.00154087,0.10089889],
#                  [0.07842459,0.06979687,0.03800132]])


# xo = np.array([[0.05426243,0.07535492,0.08082395],
#                  [0.07096805,0.12986502,0.00525356],
#                  [0.14544663,0.07084051,0.08910307],
#                  [0.04064727,0.02572375,0.04078222],
#                  [0.00396485,0.02511555,0.04027849],
#                  [0.01283282,0.16965869,0.01747957],
#                  [0.04080517,0.01355939,0.00404427],
#                  [0.00647514,0.01917338,0.2310882],
#                  [0.04449086,0.0113677, 0.04660853],
#                  [0.04922518,0.00074793,0.05735293],
#                  [0.06661824,0.07493085,0.10038441],
#                  [0.04371825,0.05728684,0.00964635],
#                  [0.03505479,0.05298537,0.01183555],
#                  [0.24095781,0.12174307,0.00353881],
#                  [0.01599614,0.03388231,0.06087315],
#                  [0.03784263,0.00298719,0.11958829],
#                  [0.00448538,0.00342377,0.00048037],
#                  [0.00225795,0.0317223, 0.01961552],
#                  [0.07564219,0.0167467, 0.02139856],
#                  [0.00830822,0.06288475,0.03982423]])




xx=xo


#==== initial for x1---with 17 components=========================================
# we try to add change the 20 component to 17 component by adding the last 3 rows to rows above it(Naive idea)
#   20,19,18 add to 1,2,3===> sum=1


# xo = np.array([[0.01, 0.1, 0.005],
#                [0.015, 0.09, 0.105],
#                [0.02, 0.08, 0.205],
#                [0.025, 0.07, 0.105],
#                [0.03, 0.06, 0.108333333333333],
#                [0.035, 0.05, 0.00833333333333333],
#                [0.04, 0.04, 0.0116666666666667],
#                [0.045, 0.03, 0.015],
#                [0.05, 0.03125, 0.0183333333333333],
#                [0.055, 0.0325, 0.0216666666666667],
#                [0.06, 0.03375, 0.025],
#                [0.0625, 0.035, 0.0283333333333333],
#                [0.065, 0.03625, 0.0316666666666667],
#                [0.0675, 0.0375, 0.035],
#                [0.07, 0.03875, 0.0383333333333333],
#                [0.0725, 0.04, 0.0416666666666667],
#                [0.075, 0.04125, 0.045]])
#
#=====last 3
               # [0.0775, 0.0425, 0.0483333333333333],
               # [0.08, 0.04375, 0.0516666666666667],
               # [0.045, 0.0675, 0.05167]])  # initial guess of the molar fraction equilibrium composition of zi

# xo = np.array([[0.01, 0.1, 0.005],
#                [0.015, 0.09, 0.105],
#                [0.02, 0.08, 0.205],
#                [0.025, 0.07, 0.105],
#                [0.03, 0.06, 0.108333333333333],
#                [0.035, 0.05, 0.00833333333333333],
#                [0.04, 0.04, 0.0116666666666667],
#                [0.045, 0.03, 0.015],
#                [0.05, 0.03125, 0.0183333333333333],
#                [0.055, 0.0325, 0.0216666666666667],
#                [0.06, 0.03375, 0.025],
#                [0.0625, 0.035, 0.0283333333333333],
#                [0.065, 0.03625, 0.0316666666666667],
#                [0.0675, 0.0375, 0.035],
#                [0.1475, 0.08125, 0.08666667],
#                [0.1525, 0.08375, 0.09333333],
#                [0.12, 0.10875, 0.09667]])

#
# xo = np.array([[0.06259217,0.01878038,0.01120139],
#                  [0.00069862,0.05211332,0.0282024 ],
#                  [0.01288667,0.01844221,0.06173524],
#                  [0.05366062,0.01675211,0.08177981],
#                  [0.06232646,0.10210147,0.02251327],
#                  [0.01796026,0.06680419,0.00278925],
#                  [0.00755125,0.11474367,0.01564453],
#                  [0.07178383,0.01451975,0.00662496],
#                  [0.20097086,0.02183005,0.09468002],
#                  [0.07789639,0.0324111,0.06266133],
#                  [0.14518657,0.04234082,0.0957611 ],
#                  [0.10601677,0.14739974,0.15336791],
#                  [0.00603442,0.05819649,0.02414346],
#                  [0.04379196,0.08485291,0.05682765],
#                  [0.10414645,0.0586402,0.05724785],
#                  [0.00601727,0.10786048,0.08760863],
#                  [0.02047942,0.04221111,0.13721117]])
# #
xx=xo





#================================================================================

# Zic=[22.7, 22.52, 22.34, 22.16, 21.98, 21.8, 21.619999999999997, 21.619999999999997, 21.439999999999998, 21.259999999999998, 21.08]
# data = pd.read_csv (r'C:\Users\rezau\Desktop\Opt-b&c\Fig6c\fig6-c.csv')   #read the csv file (put 'r' before the path string to address any special characters in the path, such as '\'). Don't forget to put the file name at the end of the path + ".csv"
# df = pd.DataFrame(data, columns= ['x-423','y-423'])
# print (df)




# LiveOil1-EXP=======================================================================================================
# Note that the first zEXP and pEXP is excluded since it started with z=0.
# also for computing the MSE it needs to exclude the last values too



# T423-Lo1
# zEXP=[0.0643,0.2197,0.4203,0.5995,0.7285,0.79,0.8724,0.9164,0.9503,0.9613,0.9678,0.9725]
# pEXP=[14.47,17.45,22.46,27.51,30.87,31.96,33.12,33.38,32.75,31.5,31.03,30.02]


# T373-LO1
# zEXP=[0.0648,0.22,0.2739,0.4205,0.4433,0.5996,0.632,0.7286,0.7595,0.79,0.8157,0.845,0.8724,0.9164,0.9503,0.9613,0.9678,0.9725,0.9788,0.9827,0.9846]
# pEXP=[13.06,15.46,16.45,19.55,20.05,23.56,24.37,26.75,27.34,27.92,28.28,28.75,29.06,29.5,28.95,28,27.5,26.95,25.92,25.03,24.45]

# T323-LO1
# zEXP=[0.0654,0.2205,0.4208,0.5998,0.7287,0.79,0.8297,0.8494,0.8724,0.875,0.9041,0.9164,0.9323,0.9453,0.9493,0.9583,0.9618,0.9717,0.9788,0.9846,0.9868,0.9915]
# pEXP=[11.04,12.48,14.62,16.71,20.24,22.15,23.52,24.05,25.05,24.93,26.42,27.05,26.45,25.85,25.55,24.5,24,22.15,20.22,16.65,16.23,14.92]


# LiveOil2-EXP==============================================================================================================
# T423-Lo2
zEXP=[0.12690,0.33480,0.50760,0.62620,0.67110,0.75350,0.82300,0.86080,0.88370,0.90100,0.92200,0.95030]#,0.96950] #,0.99020]
pEXP=[29.58000,32.45000,34.28000,35.10000,35.30000,35.20000,35.10000,34.70000,34.25000,33.50000,32.80000,31.12000]#,29.01000]#,25.37000]
# zEXP=[0.90100,0.92200,0.95030,0.96950]
# pEXP=[33.50000,32.80000,31.12000,29.01000]
# T373-Lo2
# zEXP=[0.1401,0.3425,0.5121,0.629,0.7078,0.7588,0.8114,0.8432,0.8923,0.9225,0.9565,0.9624,0.9753,0.9788,0.9859,0.9922,0.9933]
# pEXP=[28.015,29.52,31.38,32.14,32.692,32.45,31.75,31.1,29.815,28.645,26.215,25.62,24.05,23.22,22.13,21.07,20.25]


# T323-Lo2
# zEXP=[0.1403, 0.3426, 0.5122, 0.6291, 0.7078, 0.7605, 0.8432, 0.8835, 0.9226 , 0.9412, 0.9526, 0.9594, 0.9653, 0.9773, 0.9855, 0.9933, 0.9944]
# pEXP=[25.03,25.83,26.77,27.12,26.95,26.75,26.4,26,25.35,23.62,22.05,21.13,19.94,18.4,16.9,15.02,14.13]
# Note that the first zEXP and pEXP is excluded since it started with z=0.

ZCO2 = 0.9695
mainXo = xo
mainComposition = copy.deepcopy(composition)

nc,composition,xo = addCarbon(ZCO2,composition,xo)
startPressure = 12.0e6
targetPressure = 38.0e6
beta = np.array([[0.381, 0.09, 0.5285]])
# beta = np.array([[0.0, 0.0, 1]])
# beta = np.array([[0.001, 0.09, 0.909]])
# beta = np.array([[0.05640923,0.41651961,0.52707117]])  #first random B,
# beta = np.array([[0.46261997,0.00872899,0.52865104]])   ##second random B,
# beta = np.array([[0.0,0.01,1]])   ###third random B,
phases = [['liquid1'], ['liquid2'], ['vapour']]
Nsamples = 500
temp = 423.15
dPressure = (targetPressure - startPressure) / Nsamples
pCounter=0
fixedKij = [0]


fixedKij[0] = 0.107
ZCO2=0.951
dz = (1.0 - 0.0) / 100.0
dzz = (1.0 - 0.8) / 100.0
# dzz = dz
j = 0
# KijList.append(fixedKij[0])
pKij = []
while (j<800 and ZCO2>0.1):
    nc,composition,_ = addCarbon(ZCO2,mainComposition,mainXo)
    #print(composition)
    condBreak = -1
    i = 0
    while i < 500 and condBreak == -1:
        currentPressure = dPressure * i + startPressure
        if currentPressure < 0 :
            currentPressure = 0.0
            print(ZCO2, currentPressure * 1e-6, i )
            break
        iter, beta, xo, phases,tol = solveEOS(temp, currentPressure, composition, xo, beta,phases,fixedKij)
        i = i + 1
        # print(ZCO2, currentPressure * 1e-6, beta)
        if beta[0, 0] > 0.99999:
            condBreak = 0

    # This happen when you are to close or above the curve, so you need to go down and start there.
    #     pCounter is how many times you can jump down
    #     ZCO2>0 since in some cases, previouse version of code: the first calculation for very small zCO2 the iteration was 1,
    #     but not now
    #     Why for computing the MSE we exclude the last value? since for big ZCO2 like 0.9999 does not mather how many
    #     times we jump down, we can not go under the curve since we pass the step size

    ############################################################################
    ############# check if we are above the curve then jump down################

    if i < 3 and pCounter < 25 :#  and ZCO2 < 0.8:
        startPressure = currentPressure - 5.0 * dPressure
        pCounter += 1
    else:
        j = j + 1
        # print(ZCO2, currentPressure * 1e-6,i,'=====', phases,'-------------', beta)
        print(ZCO2, currentPressure * 1e-6, i)
        if ZCO2 < 0.8:
            LastZ=ZCO2+dz
        else:
            LastZ=ZCO2+dzz

        ######################################################################################
        ########### Find the closest point to ZCO2 for calculating MSE########################

        for c in range(len(zEXP)):
            if zEXP[c]>=ZCO2 and zEXP[c]<LastZ:
                # print(zEXP[c],ZCO2, '<=====>', zEXP[c]-ZCO2,'------------------' )
                pKij.append(currentPressure * 1e-6)


        LastZ = ZCO2
        if ZCO2 < 0.8 :
            ZCO2 -= dz
            startPressure = currentPressure - 1 * dPressure
        else:
            ZCO2 -= dzz
            startPressure = currentPressure - 5 * dPressure

        pCounter = 0
print(pKij,'___________________')

T1 = (time.time() - t1)
T2 = (time.time() - t2)
T3 = (time.time() - t3)
T4 = (time.time() - t4)

print(T1,'=========',T2,'=======', T3,'=======',T4)
#===MSE calculation################################################

Err=[]
list=[]
result = mean_squared_error(pEXP, pKij)
Err.append(result)
print('MSE:  ',Err,'------------------>')
list.append(Err)



#########CPU-time
# T1 = (time.time() - t1)
T2 = (time.time() - t2)
# T3 = (time.time() - t3)
# T4 = (time.time() - t4)

print('CPUtime:', T2, 'second', T2/60, 'min')
# break







