import numpy as np
from PPR78 import EoS
import math
import matplotlib.pyplot as plt
import scipy.optimize
from scipy.optimize import fsolve
import numpy as np
import pandas as pd
import math
import matplotlib.pyplot as plt
import scipy.optimize
from scipy.optimize import fsolve
import copy
import csv

##### Solution   ##############################
y_sol=np.array([[0.01746],[0.01294],[0.00237],[0.00203],[0.00088],[0.00067],[0.0073],[0.00049],[0.00037],[0.0003],[0.00012],[0.00004],[0.00006],[0.00003],[0.00001],[0],[0.00001],[0.42709],[0.04858],[0.01729],[0.4685]])

x_sol=np.array([[0.06658],[0.05969],[0.03815],[0.03083],[0.01865],[0.02836],[0.04183],[0.0237],[0.00783],[0.04024],[0.01956],[0.00832],[0.02656],[0.02309],[0.02838],[0.00422],[0.1476],[0.12642],[0.02853],[0.01697],[0.21448 ]])

#=========================Live oil =x3=========================================
composition = [{'name': '2,2-dimethylbutane', 'z': 0.0417, 'Tc': 489.21, 'Pc': 3102000, 'w': 0.2251},
               {'name': 'n-heptane', 'z': 0.0366, 'Tc': 540.3, 'Pc': 2734000, 'w': 0.3481},
               {'name': 'ethylcyclohexane', 'z': 0.0217, 'Tc': 606.9, 'Pc': 3250000, 'w': 0.318},
               {'name': 'n-nonane', 'z': 0.0176, 'Tc': 594.7, 'Pc': 2280000, 'w': 0.4409},
               {'name': 'propylcyclohexane', 'z': 0.0105, 'Tc': 630.8, 'Pc': 2860000, 'w': 0.3149},
               {'name': '1,2,3,4-tetrahydronaphthalene', 'z': 0.0159, 'Tc': 719.5, 'Pc': 3630000, 'w': 0.3318},
               {'name': '1,3,5-triethylbenzene', 'z': 0.0233, 'Tc': 679, 'Pc': 2330000, 'w': 0.507},
               {'name': '1-phenylhexane', 'z': 0.0133, 'Tc': 695, 'Pc': 2350000, 'w': 0.4498},
               {'name': 'n-tridecane', 'z': 0.0044, 'Tc': 676, 'Pc': 1679000, 'w': 0.6099},
               {'name': '1-phenyloctane', 'z': 0.0223, 'Tc': 725, 'Pc': 1980000, 'w': 0.5845},
               {'name': 'n-pentadecane', 'z': 0.0109, 'Tc': 707.5, 'Pc': 1479000, 'w': 0.7192},
               {'name': 'n-hexadecane', 'z': 0.0046, 'Tc': 722.4, 'Pc': 1401000, 'w': 0.7442},
               {'name': 'octadecane', 'z': 0.0147, 'Tc': 747.7, 'Pc': 1292000, 'w': 0.802},
               {'name': 'nonadecane', 'z': 0.0128, 'Tc': 755.3, 'Pc': 1160000, 'w': 0.8722},
               {'name': '1-phenylhexadecane', 'z': 0.0157, 'Tc': 827.35, 'Pc': 1279000, 'w': 0.9055},
               {'name': 'tetracosane', 'z': 0.0023, 'Tc': 799.8, 'Pc': 1075000, 'w': 1.184},
               {'name': 'squalane', 'z': 0.0816, 'Tc': 820, 'Pc': 900000, 'w': 1.2436},
               {'name': 'methane', 'z': 0.5285, 'Tc': 190.56, 'Pc': 4599000, 'w': 0.01},
               {'name': 'ethane', 'z': 0.0819, 'Tc': 305.32, 'Pc': 4885000, 'w': 0.099},
               {'name': 'propane', 'z': 0.0397, 'Tc': 370.01, 'Pc': 4260000, 'w': 0.152}]
nc = len(composition)


#============== CO2 ===================================

zCO2=0.3

########################
# for xcoo in range(len(zCarbonDioxVal)):
#     compCarbonDiox = [{'name': 'carbon dioxide', 'z': 0.51, 'Tc': 304.16, 'Pc': 7.378e6, 'w': 0.231}]

# compCarbonDiox[0]['z']=zCarbonDioxVal[xcoo]
# compCarbonDiox=compCarbonDiox[0]

if zCO2>0:
    compCarbonDiox = {'name': 'carbon dioxide', 'z': zCO2, 'Tc': 304.16, 'Pc': 7.378e6, 'w': 0.231}
    composition.append(compCarbonDiox)
    nc = len(composition)  # Components number of the composition

    for xz in range(0,nc-1):
        composition[xz]['z']=composition[xz]['z']*(1-composition[nc-1]['z'])


else:
    composition=composition
print(composition)



#=================================================================================================================




mainComposition = copy.deepcopy(composition)
pressure = 10.0e6
phase =  ["vapour"]   # ["liquid1"]
temp = 423.15

zi = np.zeros((1, nc)).transpose()
for comp in range(0, nc):
    zi[comp, 0] = np.array([[composition[comp]['z']]])
# print(zi)
# Add yi here ba formule Cruz
# generate yi for now
from numpy.core.fromnumeric import transpose
import numpy as np, numpy.random
# y=np.random.dirichlet(np.ones(20),size=1)
# yi=np.array(transpose(y))
# yi=zi


########### ai bi ###################################
from PPR78 import EoS
ai, bi = EoS(pressure, temp, composition)

# =================aij  bij ================================================================================
from mixingRules import mixRules
aij, bij = mixRules(pressure, temp, composition, ai, bi)


#### TPDm #############################
from fugacity import fug
def TPDm(composition,pressure, temp, phase, zi, yi, bi, aij, bij ):
    from fugacity import fug
    phi_zi = [fug(pressure, temp, zi, phase, bi, aij, bij, composition)]
    phi_yi = [fug(pressure, temp, yi, phase, bi, aij, bij, composition)]
    LnPhi_zi = np.log(phi_zi)
    LnPhi_yi = np.log(phi_yi)
    Ln_zi = np.log(zi)
    Ln_yi = np.log(yi)
    A = (LnPhi_yi + Ln_yi)
    B = (LnPhi_zi + Ln_zi)
    TPD = np.sum(yi * [A - B])
    return TPD


#### TPD_B #############################
from fugacity import fug
def TPD_x(composition,pressure, temp, phase, zi, xi, bi, aij, bij ):
    from fugacity import fug
    phi_zi = fug(pressure, temp, zi, phase, bi, aij, bij, composition)
    phi_xi = fug(pressure, temp, xi, phase, bi, aij, bij, composition)
    LnPhi_zi = np.log(phi_zi)
    LnPhi_xi = np.log(phi_xi)
    Ln_zi = np.log(zi)
    Ln_xi = np.log(xi)
    A = (LnPhi_xi + Ln_xi)
    B = (LnPhi_zi + Ln_zi)
    TPD = np.sum(xi * [A - B])
    return TPD


#============ Wilson =======================================
def Kfunc(pressure, temp, composition):


    # Kwil=pressure/temp
    Kwil=np.zeros((len(composition), 1))
    for i in range(0, len(composition)):
        Kwil[i,0]= (composition[i]['Pc']/pressure)* np.exp(5.373*(1+ composition[i]['w'])*(1-(composition[i]['Tc']/temp)))


    return Kwil
# ki_wil=Kfunc(pressure, temp, composition)
# print(ki_wil)

##########   Wilson-Daniel     ################################
from math import exp
Pci = np.zeros((1, nc)).transpose()
for press in range(0, nc):
    Pci[press, 0] = np.array([[composition[press]['Pc']]])
m = -1
# print(Pci)
# print(pressure/Pci)
# print(zi[0],Pci[0],ai[0][0],bi[0][0])
# print(Pci)
# def myFun(m, temp, ai, bi):
#     return math.exp(ai/(m*temp* bi))
# myFn = np.vectorize(myFun)
# Ex=myFn(m,temp,ai,bi)
Ex=np.exp(ai/(m*temp* bi))
C_tilda=1/(np.sum(zi*(pressure/Pci)*Ex))
C=-m*np.log(C_tilda)

# ym=np.array(zi*(pressure/Pci)*C_tilda*Ex)
# print(ym,np.shape(ym), type(ym), sum(ym))




######## Loop for TPD(yi) over m #####################33
import csv
m = -100
Coord =[]
with open(r'Coord.csv', 'w') as f1:  # need "a" and not w to append to a file, if not will overwrite
    f1.close()
while m<0 :
    Ex = np.exp(ai / (m * temp * bi))
    C_tilda = 1 / (np.sum(zi * (pressure / Pci) * Ex))
    C = -m * np.log(C_tilda)
    ym = np.array(zi * (pressure / Pci) * C_tilda * Ex)
    TPD=TPDm(composition,pressure, temp, phase, zi, ym, bi, aij, bij)
    Coord.append(TPD)
    with open(r'Coord.csv', 'a') as f1:  # need "a" and not w to append to a file, if not will overwrite
        writer = csv.writer(f1, delimiter=';', lineterminator='\n', )
        row = [m,TPD]
        writer.writerow(row)

    print(m,'=======',TPD)
    Min_TPD = min(Coord)
    if TPD <= Min_TPD:
        m_Min=m
        TPDm_Min=TPD
        print(ym)
        yi=ym
        m+=1
    else:
        m = m + 1
print(m_Min, "Min ==", TPDm_Min, yi)

# ======================  comparison of the results ==============================================





# vstack rows by rows
#hstack columns by columns

# different ki's for different methods
#======Wilson=========
ki_wil=Kfunc(pressure, temp, composition)
print(ki_wil)

#===== Wilson-Daniel====
ki=yi/zi
print(ki, sum(yi))
#===== Solution of the code=====
ki_sol=y_sol/x_sol
print(ki_sol)



# print result of the comparison of [ki's] as csv file
with open(r'Compare.csv', 'w') as f1:  # need "a" and not w to append to a file, if not will overwrite
    f1.close()
result= np.hstack((ki_sol, ki_wil, ki, abs(ki_sol-ki_wil),abs(ki_sol-ki),abs(ki_wil-ki)))
# result= np.hstack((zi, yi, y_sol, zi - yi, zi - y_sol, yi - y_sol, (zi - yi) / zi, (zi - y_sol) / zi))
with open(r'Compare.csv', 'a') as f1:
    headers = ['ki_sol', 'ki_wil', 'ki','|ki_sol-ki_wil|','|ki_sol-ki|','|ki_wil-ki|']
    writer = csv.writer(f1,  delimiter=',', lineterminator='\n')
    writer.writerow(headers)
    for row in result:
        writer.writerow(row)


# print result of the comparison of [yi's] as csv file
with open(r'Compare-yi.csv', 'w') as f1:  # need "a" and not w to append to a file, if not will overwrite
    f1.close()
result= np.hstack((y_sol, yi,abs(y_sol-yi)))
with open(r'Compare-yi.csv', 'a') as f1:
    headers = ['y_sol', 'yi', '|y_sol - yi|']
    writer = csv.writer(f1,  delimiter=',', lineterminator='\n')
    writer.writerow(headers)
    for row in result:
        writer.writerow(row)


#=============== TPD_y over B ==============================================
# this os not a good idea since for fix yi we always get same TPD(yi)----------
# unless you want to get diff yi for diff B, which has conflict with Daniel formula



with open(r'TPDy_B.csv', 'w') as f2:  # need "a" and not w to append to a file, if not will overwrite
    f2.close()
B=0
B_step=0.01
TPDy_B =[]
ki=yi/zi
while B<1:
    # yi?
    
    TPDy = TPDm(composition, pressure, temp, phase, zi,yi, bi, aij, bij)
    TPDy_B.append(TPDy)
    with open(r'TPDy_B.csv', 'a') as f2:  # need "a" and not w to append to a file, if not will overwrite
        writer = csv.writer(f2, delimiter=';', lineterminator='\n', )
        row = [B, TPDy]
        writer.writerow(row)

    print(B, '=======', TPDy)
    Min_TPDy = min(TPDy_B)
    if TPDy <= Min_TPDy:
        By_Min = B
        TPDy_Min=TPDy
        # print(xi)
        yi_min = yi
        B += B_step
    else:
        B += B_step
print(By_Min, "Min ==", TPDy_Min)

#=============== TPD_x over B ==============================================
with open(r'TPDx_B.csv', 'w') as f2:  # need "a" and not w to append to a file, if not will overwrite
    f2.close()
B=0.01
B_step=0.01
Coord2 =[]
ki=yi/zi
phase = ["liquid1"]
while B<1:
    # xi=(zi)/(1+B*(ki-1))
    xi=(zi)/(1-B+B*ki)
    # xi=(zi-(B*yi))/(1-B)
    TPDx = TPD_x(composition, pressure, temp, phase, zi,xi, bi, aij, bij)
    print(TPDx,'-----------------------------------------------', B)
    Coord2.append(TPDx)
    with open(r'TPDx_B.csv', 'a') as f2:  # need "a" and nt w to append to a file, if not will overwrite
        writer = csv.writer(f2, delimiter=';', lineterminator='\n', )
        row = [B, TPDx]
        writer.writerow(row)

    print(B, '=======', TPDx)
    Min_TPDx = min(Coord2)
    if TPDx <= Min_TPDx:
        B_Min = B
        TPDx_Min=TPDx
        # print(xi)
        xi_min = xi
        B += B_step
    else:
        B += B_step
print(B_Min, "Min ==", TPDx_Min)
print(xi_min)





with open(r'Cmpare_xi.csv', 'w') as f1:  # need "a" and not w to append to a file, if not will overwrite
    f1.close()
result= np.hstack((x_sol, xi,abs(x_sol-xi)))
with open(r'Cmpare_xi.csv', 'a') as f1:
    headers = ['x_Sol', 'xi', '|x_Sol - xi|']
    writer = csv.writer(f1,  delimiter=',', lineterminator='\n')
    writer.writerow(headers)
    for row in result:
        writer.writerow(row)



#======================== Beta calculation  =========================================
from scipy.optimize import root_scalar
from scipy import optimize
# from scipy import root
# B=5
# objective=0
# Bmin=n
K=0
# B=0.5
A=np.zeros((len(zi),1))
for i in range(len(zi)):
    A[i,0]=(zi[i]*((((1-B)*yi[i])/(zi[i]-B*yi[i]))-1))/(1-B+ B*(((1-B)*yi[i])/(zi[i]-B*yi[i])))
    K=K+A[i,0]
    print(i, A[i,0], '===========', K)
print(np.sum((zi*((((1-B)*yi)/(zi-B*yi))-1))/(1-B+ B*(((1-B)*yi)/(zi-B*yi)))),'+++++++++++++++++++')

#======================== RR sum eq 33 over B ==========================
# import csv
# import random
# ki_r=copy.deepcopy(ki)
# d=[]
# def Root(zi,ki,B):
#     #print((zi * (ki - 1)) / (1 + B * (ki - 1)))
#     for i in range(0,len(zi)):
#         d = 0.3* random.random()
#         ki_r[i] = ki[i]*(1+d)
#         i+=1
#     print(ki_r)
#     ki=ki_r
#     objective = np.sum((zi * (ki - 1)) / (1 + B * (ki - 1)))
#     # objective = np.sum((zi * (ki - 1)) / (1 + B * (ki - 1)))
#     return objective
#
# TPD_B=[]
# Bint=0
# Btarg=1
# Bsteps=100
# TPDgraph =[]
# i=1
# with open(r'TPDD.csv', 'w') as f1:  # need "a" and not w to append to a file, if not will overwrite
#     f1.close()
# while i<100:
#     B=i*((Btarg-Bint)/Bsteps)
#     # objective = np.sum((zi * (ki - 1)) / (1 + B * (ki - 1)))
#     # print(B,objective)
#     Rootb=Root(zi,ki,B)
#     TPD_B.append(Rootb)
#     # i+=1
#     with open(r'TPDD.csv', 'a') as f1:  # need "a" and not w to append to a file, if not will overwrite
#         writer = csv.writer(f1, delimiter=';', lineterminator='\n', )
#         row = [B,Rootb]
#         writer.writerow(row)
#     i+=1
#     # print(m,'=======',objective)
#
#
# print(np.sum((zi * (ki - 1))))  # looks like sum numerator =1



# print(ki)
# yi=ym
# ki=yi/zi
B=0.66
xxi=(zi)/(1-B+B*(ki))
xi=1/B*(zi-((1-B)*yi))
ki=yi/xxi
print(ki)

H=((1-B)*yi)
np.sum((zi * (ki - 1)) / (1 + B * (ki - 1)))
#========================Solvers====================================

def Beta(B):
    A=np.sum((zi * (ki - 1)) / (1 + B * (ki - 1)))
        # objective=np.sum((zi*(ki-1))/(1+B*(ki-1)))
    # print(B, A)
    return B
#
# yi=zi
# print(ki)
solution = root_scalar(Beta,  bracket=[0,1], method='brenth')
solution.root, solution.iterations, solution.function_calls
beta=solution.root
it=solution.iterations
print('B=', beta,'it=', it)

solution = root_scalar(Beta,  bracket=[0,1], method='brentq')
solution.root, solution.iterations, solution.function_calls
beta=solution.root
it=solution.iterations
print('B=', beta,'it=', it)

from scipy.optimize import fsolve , least_squares
solution = least_squares(Beta,0.5, method='lm')
print(solution)


from scipy.optimize import fsolve
solution = fsolve(Beta,0.5)
print(solution,it)


#______________________________________________________________________-
# rrmVal = np.dot(np.array(zi / (np.vstack(Ki[:, 0]) + np.dot((np.vstack(Ki[:, 1:nUph]) - Krm),np.vstack(betaVal).reshape(-1,1)))).flatten(),
#                     np.vstack(Ki[:, 1:nUph]) - Krm)

def beta(beta,zi,ki):
    A=np.sum((zi * (ki - 1)) / (1 + beta * (ki - 1)))
        # objective=np.sum((zi*(ki-1))/(1+B*(ki-1)))
    # print(B, A)
    return beta

# rrmVal = np.sum((zi*(ki-1))/(1+B*(ki-1)))
# print(yi)
# yi=y_sol
# print(yi)
# print(ki)
# ki=yi/zi
# print(ki)


import random
ki_r=copy.deepcopy(ki)
print(ki)
for i in range(0,len(zi)):
    d = 0.9* random.random()
    ki_r[i] = ki[i]*(1+d)
    i+=1
print(ki_r)
ki=ki_r
print(ki)
#
betaFuncAux = scipy.optimize.root(beta,0.1,  args=(zi, ki), method='lm')
betaFunc = betaFuncAux.x
print(betaFunc,it)

#---------------------------------------------------------------------


#======  Swarms
import sys
# import numpy as np
# import matplotlib.pyplot as plt
#
# # Import PySwarms
# import pyswarms as ps
#
# Bmin=0.001*np.ones(1)
# Bmax=0.9999*np.ones(1)
# bounds=(Bmin,Bmax)
#
# options = {'c1': 0.5, 'c2': 0.3, 'w':0.3}
#
# # Call instance of PSO
# optimizer = ps.single.GlobalBestPSO(n_particles=21, dimensions=1, options=options, bounds=bounds)
#
# # Perform optimization
# cost, pos = optimizer.optimize(Beta, iters=10000)
# # print(cost, pos, '==================', Beta(B))














