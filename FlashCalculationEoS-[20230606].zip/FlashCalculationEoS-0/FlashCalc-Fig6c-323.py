"""
Predictive Peng Robinson 78 EoS  (PPR78) for mixtures
J.-N. Jaubert, F. Mutelet / Fluid Phase Equilibria 224 (2004) 285–304 (doi:10.1016/j.fluid.2004.06.059)
@author: Gustavo Oviedo
"""
import os

import numpy as np
import copy
from sklearn import linear_model
import csv
import pandas as pd
import matplotlib.pyplot as plt
# import functions
import csv
import math
import scipy.optimize
from scipy.optimize import fsolve, least_squares

from sympy import symbols, Eq, solve
import time
from sklearn.metrics import mean_squared_error, max_error
from sklearn.metrics import mean_absolute_error as mae
from math import sqrt
from keras import backend as K

# https://pyquestions.com/rmse-rmsle-loss-function-in-keras
import tensorflow as tf
# import tensorflow.keras.backend as k

def root_mean_squared_log_error(y_true, y_pred):
    msle = tf.keras.losses.MeanSquaredLogarithmicError()
    return K.sqrt(msle(y_true, y_pred))

##################3
import matplotlib.pyplot as plt
# from IPython.display import clear_output
import time
#################


import mixingRules
from PPR78 import EoS
from mixingRules import mixRules
from fugacity import fug
from fugacityCriteria import fugC
from rachfordRiceEq import rrm
from theta import thetaFunc
from solver import solveEOS
from carbon import addCarbon

import warnings
import random

fixedKij = []

warnings.filterwarnings("ignore",
                        category=np.VisibleDeprecationWarning)  # I need to check the reason.  =asanyarray(ary)

tic = time.perf_counter()
##########################################3

t1 = time.perf_counter() # It does include time elapsed during sleep and is system-wide.
t2 = time.time()
t3=time.process_time() #It does not include time elapsed during sleep.
t4=time.thread_time()   #It does not include time elapsed during sleep.

###################################3#######
# ==================Component properties composition & input variables==========================================
# modelEoS= [{'PR78', 'PPR78', 'SRK', 'PC-SAFT', 'CPA'}]
tempMinVal = 298.15  # 189  # 155.60857142857      #Critical point 203.465 #203.468
tempMaxInVal = 298.15  # 189  # 155.60857142857    #Critical point203.465  #203.468
tempNumbSpaces = 1  # 150
tempVal = np.zeros([tempNumbSpaces])
DtempVal = (tempMaxInVal - tempMinVal) / tempNumbSpaces

pressMinVal = 7.1480e6 #9.8e6 7.5e6
pressMaxInVal = 7.1480e6 #9.8e6 7.5e6
pressNumbSpaces = 1
pressVal = np.zeros([pressNumbSpaces])
DpressVal = (pressMaxInVal - pressMinVal) / pressNumbSpaces

zCarbonDioxMinVal = 0.1659 #0.0659  # Minimum molar composition of carbon dioxide (CO2).
zCarbonDioxMaxVal = 0.1659 #0.0659 # Maximum molar composition of carbon dioxide (CO2).
zCarbonDioxNumbSpaces = 1
if zCarbonDioxNumbSpaces > 0:
    zCarbonDioxVal = np.zeros([zCarbonDioxNumbSpaces])
    DzCarbonDioxVal = (zCarbonDioxMaxVal - zCarbonDioxMinVal) / zCarbonDioxNumbSpaces
else:
    zCarbonDioxVal = []

betaPrint = []
xoPrint = []
p = 0
#====================live oil-x2  ==================================
# composition = [{'name': '2,2-dimethylbutane', 'z': 0.0715, 'Tc': 489.21, 'Pc': 3102000, 'w': 0.2251},
#                {'name': 'n-heptane', 'z': 0.0628, 'Tc': 540.3, 'Pc': 2734000, 'w': 0.3481},
#                {'name': 'ethylcyclohexane', 'z': 0.0373, 'Tc': 606.9, 'Pc': 3250000, 'w': 0.318},
#                {'name': 'n-nonane', 'z': 0.0302, 'Tc': 594.7, 'Pc': 2280000, 'w': 0.4409},
#                {'name': 'propylcyclohexane', 'z': 0.0181, 'Tc': 630.8, 'Pc': 2860000, 'w': 0.3149},
#                {'name': '1,2,3,4-tetrahydronaphthalene', 'z': 0.0272, 'Tc': 719.5, 'Pc': 3630000, 'w': 0.3318},
#                {'name': '1,3,5-triethylbenzene', 'z': 0.04, 'Tc': 679, 'Pc': 2330000, 'w': 0.507},
#                {'name': '1-phenylhexane', 'z': 0.0227, 'Tc': 695, 'Pc': 2350000, 'w': 0.4498},
#                {'name': 'n-tridecane', 'z': 0.0076, 'Tc': 676, 'Pc': 1679000, 'w': 0.6099},
#                {'name': '1-phenyloctane', 'z': 0.0383, 'Tc': 725, 'Pc': 1980000, 'w': 0.5845},
#                {'name': 'n-pentadecane', 'z': 0.0186, 'Tc': 707.5, 'Pc': 1479000, 'w': 0.7192},
#                {'name': 'n-hexadecane', 'z': 0.0079, 'Tc': 722.4, 'Pc': 1401000, 'w': 0.7442},
#                {'name': 'octadecane', 'z': 0.0252, 'Tc': 747.7, 'Pc': 1292000, 'w': 0.802},
#                {'name': 'nonadecane', 'z': 0.0219, 'Tc': 755.3, 'Pc': 1160000, 'w': 0.8722},
#                {'name': '1-phenylhexadecane', 'z': 0.0269, 'Tc': 827.35, 'Pc': 1279000, 'w': 0.9055},
#                {'name': 'tetracosane', 'z': 0.004, 'Tc': 799.8, 'Pc': 1075000, 'w': 1.184},
#                {'name': 'squalane', 'z': 0.1399, 'Tc': 820, 'Pc': 900000, 'w': 1.2436},
#                {'name': 'methane', 'z': 0.3252, 'Tc': 190.56, 'Pc': 4599000, 'w': 0.01},
#                {'name': 'ethane', 'z': 0.0504, 'Tc': 305.32, 'Pc': 4885000, 'w': 0.099},
#                {'name': 'propane', 'z': 0.0244, 'Tc': 370.01, 'Pc': 4260000, 'w': 0.152}]
#
# nc = len(composition)  # Components number of the composition
#==================================================================

#=========================Live oil =x3=========================================
# composition = [{'name': '2,2-dimethylbutane', 'z': 0.0417, 'Tc': 489.21, 'Pc': 3102000, 'w': 0.2251},
#                {'name': 'n-heptane', 'z': 0.0366, 'Tc': 540.3, 'Pc': 2734000, 'w': 0.3481},
#                {'name': 'ethylcyclohexane', 'z': 0.0217, 'Tc': 606.9, 'Pc': 3250000, 'w': 0.318},
#                {'name': 'n-nonane', 'z': 0.0176, 'Tc': 594.7, 'Pc': 2280000, 'w': 0.4409},
#                {'name': 'propylcyclohexane', 'z': 0.0105, 'Tc': 630.8, 'Pc': 2860000, 'w': 0.3149},
#                {'name': '1,2,3,4-tetrahydronaphthalene', 'z': 0.0159, 'Tc': 719.5, 'Pc': 3630000, 'w': 0.3318},
#                {'name': '1,3,5-triethylbenzene', 'z': 0.0233, 'Tc': 679, 'Pc': 2330000, 'w': 0.507},
#                {'name': '1-phenylhexane', 'z': 0.0133, 'Tc': 695, 'Pc': 2350000, 'w': 0.4498},
#                {'name': 'n-tridecane', 'z': 0.0044, 'Tc': 676, 'Pc': 1679000, 'w': 0.6099},
#                {'name': '1-phenyloctane', 'z': 0.0223, 'Tc': 725, 'Pc': 1980000, 'w': 0.5845},
#                {'name': 'n-pentadecane', 'z': 0.0109, 'Tc': 707.5, 'Pc': 1479000, 'w': 0.7192},
#                {'name': 'n-hexadecane', 'z': 0.0046, 'Tc': 722.4, 'Pc': 1401000, 'w': 0.7442},
#                {'name': 'octadecane', 'z': 0.0147, 'Tc': 747.7, 'Pc': 1292000, 'w': 0.802},
#                {'name': 'nonadecane', 'z': 0.0128, 'Tc': 755.3, 'Pc': 1160000, 'w': 0.8722},
#                {'name': '1-phenylhexadecane', 'z': 0.0157, 'Tc': 827.35, 'Pc': 1279000, 'w': 0.9055},
#                {'name': 'tetracosane', 'z': 0.0023, 'Tc': 799.8, 'Pc': 1075000, 'w': 1.184},
#                {'name': 'squalane', 'z': 0.0816, 'Tc': 820, 'Pc': 900000, 'w': 1.2436},
#                {'name': 'methane', 'z': 0.5285, 'Tc': 190.56, 'Pc': 4599000, 'w': 0.01},
#                {'name': 'ethane', 'z': 0.0819, 'Tc': 305.32, 'Pc': 4885000, 'w': 0.099},
#                {'name': 'propane', 'z': 0.0397, 'Tc': 370.01, 'Pc': 4260000, 'w': 0.152}]
#
# nc = len(composition)  # Components number of the composition

#========================================================================================
# #=========================dead oil=========================================
# composition = [{'name': '2,2-dimethylbutane', 'z': 0.1192, 'Tc': 489.21, 'Pc': 3102000, 'w': 0.2251},
#                {'name': 'n-heptane', 'z': 0.1047, 'Tc': 540.3, 'Pc': 2734000, 'w': 0.3481},
#                {'name': 'ethylcyclohexane', 'z': 0.0621, 'Tc': 606.9, 'Pc': 3250000, 'w': 0.318},
#                {'name': 'n-nonane', 'z': 0.0503, 'Tc': 594.7, 'Pc': 2280000, 'w': 0.4409},
#                {'name': 'propylcyclohexane', 'z': 0.0301, 'Tc': 630.8, 'Pc': 2860000, 'w': 0.3149},
#                {'name': '1,2,3,4-tetrahydronaphthalene', 'z': 0.0454, 'Tc': 719.5, 'Pc': 3630000, 'w': 0.3318},
#                {'name': '1,3,5-triethylbenzene', 'z': 0.0666, 'Tc': 679, 'Pc': 2330000, 'w': 0.507},
#                {'name': '1-phenylhexane', 'z': 0.0379, 'Tc': 695, 'Pc': 2350000, 'w': 0.4498},
#                {'name': 'n-tridecane', 'z': 0.0127, 'Tc': 676, 'Pc': 1679000, 'w': 0.6099},
#                {'name': '1-phenyloctane', 'z': 0.0638, 'Tc': 725, 'Pc': 1980000, 'w': 0.5845},
#                {'name': 'n-pentadecane', 'z': 0.0310, 'Tc': 707.5, 'Pc': 1479000, 'w': 0.7192},
#                {'name': 'n-hexadecane', 'z': 0.0131, 'Tc': 722.4, 'Pc': 1401000, 'w': 0.7442},
#                {'name': 'octadecane', 'z': 0.0420, 'Tc': 747.7, 'Pc': 1292000, 'w': 0.802},
#                {'name': 'nonadecane', 'z': 0.0365, 'Tc': 755.3, 'Pc': 1160000, 'w': 0.8722},
#                {'name': '1-phenylhexadecane', 'z': 0.0449, 'Tc': 827.35, 'Pc': 1279000, 'w': 0.9055},
#                {'name': 'tetracosane', 'z': 0.0066, 'Tc': 799.8, 'Pc': 1075000, 'w': 1.184},
#                {'name': 'squalane', 'z': 0.2331, 'Tc': 820, 'Pc': 900000, 'w': 1.2436}]
#
#                # {'name': 'methane', 'z': 0.0, 'Tc': 190.56, 'Pc': 4599000, 'w': 0.01},
#                # {'name': 'ethane', 'z': 0.0, 'Tc': 305.32, 'Pc': 4885000, 'w': 0.099},
#                # {'name': 'propane', 'z': 0.0, 'Tc': 370.01, 'Pc': 4260000, 'w': 0.152}]
#
# nc = len(composition)  # Components number of the composition



#======initial for x2 and x3 =======================================

xo = np.array([[0.01, 0.1, 0.005],
               [0.015, 0.09, 0.105],
               [0.02, 0.08, 0.205],
               [0.025, 0.07, 0.105],
               [0.03, 0.06, 0.108333333333333],
               [0.035, 0.05, 0.00833333333333333],
               [0.04, 0.04, 0.0116666666666667],
               [0.045, 0.03, 0.015],
               [0.05, 0.03125, 0.0183333333333333],
               [0.055, 0.0325, 0.0216666666666667],
               [0.06, 0.03375, 0.025],
               [0.0625, 0.035, 0.0283333333333333],
               [0.065, 0.03625, 0.0316666666666667],
               [0.0675, 0.0375, 0.035],
               [0.07, 0.03875, 0.0383333333333333],
               [0.0725, 0.04, 0.0416666666666667],
               [0.075, 0.04125, 0.045],
               [0.0775, 0.0425, 0.0483333333333333],
               [0.08, 0.04375, 0.0516666666666667],
               [0.045, 0.0675, 0.05167]])  # initial guess of the molar fraction equilibrium composition of zi


import random

# print()
# # our initial guess
# xo = np.zeros((nc, 3))
# for i in range(0,nc):
#     d = 0.1* random.random()
#     d1 = [np.array([[composition[i]['z']]]),0.01, (1+d)*np.array([[composition[i]['z']]])]
#     for j in range(0, 3):
#         xo[i, j] = d1[j] #np.array([[composition[i]['z']]])


#==== initial for x1---with 17 components=========================================
#
# xo = np.array([[0.01, 0.1, 0.005],
#                [0.015, 0.09, 0.105],
#                [0.02, 0.08, 0.205],
#                [0.025, 0.07, 0.105],
#                [0.03, 0.06, 0.108333333333333],
#                [0.035, 0.05, 0.00833333333333333],
#                [0.04, 0.04, 0.0116666666666667],
#                [0.045, 0.03, 0.015],
#                [0.05, 0.03125, 0.0183333333333333],
#                [0.055, 0.0325, 0.0216666666666667],
#                [0.06, 0.03375, 0.025],
#                [0.0625, 0.035, 0.0283333333333333],
#                [0.065, 0.03625, 0.0316666666666667],
#                [0.0675, 0.0375, 0.035],
#                [0.07, 0.03875, 0.0383333333333333],
#                [0.0725, 0.04, 0.0416666666666667],
#                [0.075, 0.04125, 0.045]])
#


               # [0.0775, 0.0425, 0.0483333333333333],
               # [0.08, 0.04375, 0.0516666666666667],
               # [0.045, 0.0675, 0.05167]])  # initial guess of the molar fraction equilibrium composition of zi


#=====last 3

# xo = np.array([[0.01, 0.1, 0.005],
#                [0.015, 0.09, 0.105],
#                [0.02, 0.08, 0.205],
#                [0.025, 0.07, 0.105],
#                [0.03, 0.06, 0.108333333333333],
#                [0.035, 0.05, 0.00833333333333333],
#                [0.04, 0.04, 0.0116666666666667],
#                [0.045, 0.03, 0.015],
#                [0.05, 0.03125, 0.0183333333333333],
#                [0.055, 0.0325, 0.0216666666666667],
#                [0.06, 0.03375, 0.025],
#                [0.0625, 0.035, 0.0283333333333333],
#                [0.065, 0.03625, 0.0316666666666667],
#                [0.0675, 0.0375, 0.035],
#                [0.1475, 0.08125, 0.08666667],
#                [0.1525, 0.08375, 0.09333333],
#                [0.12, 0.10875, 0.09667]])







#   20,19,18 add to 1,2,3===> sum=1
#================================================================================

# Zic=[22.7, 22.52, 22.34, 22.16, 21.98, 21.8, 21.619999999999997, 21.619999999999997, 21.439999999999998, 21.259999999999998, 21.08]
# data = pd.read_csv (r'C:\Users\rezau\Desktop\Opt-b&c\Fig6c\fig6-c.csv')   #read the csv file (put 'r' before the path string to address any special characters in the path, such as '\'). Don't forget to put the file name at the end of the path + ".csv"
# df = pd.DataFrame(data, columns= ['x-423','y-423'])
# print (df)
# zEXP=[0.12690,0.33480,0.50760,0.62620,0.67110,0.75350,0.82300,0.86080,0.88370,0.90100,0.92200,0.95030,0.96950,0.99020]
# pEXP=[29.58000,32.45000,34.28000,35.10000,35.30000,35.20000,35.10000,34.70000,34.25000,33.50000,32.80000,31.12000,29.01000,25.37000]


# LiveOil1-EXP==============================================================================================================
# T423-Lo1
# zEXP=[0.0643,0.2197,0.4203,0.5995,0.7285,0.79,0.8724,0.9164,0.9503,0.9613,0.9678,0.9725]
# pEXP=[14.47,17.45,22.46,27.51,30.87,31.96,33.12,33.38,32.75,31.5,31.03,30.02]


# T373-LO1
# zEXP=[0.0648,0.22,0.2739,0.4205,0.4433,0.5996,0.632,0.7286,0.7595,0.79,0.8157,0.845,0.8724,0.9164,0.9503,0.9613,0.9678,0.9725,0.9788,0.9827,0.9846]
# pEXP=[13.06,15.46,16.45,19.55,20.05,23.56,24.37,26.75,27.34,27.92,28.28,28.75,29.06,29.5,28.95,28,27.5,26.95,25.92,25.03,24.45]



# T323-LO1
# zEXP=[0.0654,0.2205,0.4208,0.5998,0.7287,0.79,0.8297,0.8494,0.8724,0.875,0.9041,0.9164,0.9323,0.9453,0.9493,0.9583,0.9618,0.9717,0.9788,0.9846,0.9868,0.9915]
# pEXP=[11.04,12.48,14.62,16.71,20.24,22.15,23.52,24.05,25.05,24.93,26.42,27.05,26.45,25.85,25.55,24.5,24,22.15,20.22,16.65,16.23,14.92]
# Note that the first zEXP and pEXP is excluded since it started with z=0.



# LiveOil2-EXP==============================================================================================================
# T423-Lo2
zEXP=[0.12690,0.33480,0.50760,0.62620,0.67110,0.75350,0.82300,0.86080,0.88370,0.90100,0.92200,0.95030,0.96950]#,0.99020]
pEXP=[29.58000,32.45000,34.28000,35.10000,35.30000,35.20000,35.10000,34.70000,34.25000,33.50000,32.80000,31.12000,29.01000]#,25.37000]


# T373-Lo2
# zEXP=[0.1401,0.3425,0.5121,0.629,0.7078,0.7588,0.8114,0.8432,0.8923,0.9225,0.9565,0.9624,0.9753,0.9788,0.9859,0.9922,0.9933]
# pEXP=[28.015,29.52,31.38,32.14,32.692,32.45,31.75,31.1,29.815,28.645,26.215,25.62,24.05,23.22,22.13,21.07,20.25]



# T323-Lo2
# zEXP=[0.1403, 0.3426, 0.5122, 0.6291, 0.7078, 0.7605, 0.8432, 0.8835, 0.9226 , 0.9412, 0.9526, 0.9594, 0.9653, 0.9773, 0.9855, 0.9933, 0.9944]
# pEXP=[25.03,25.83,26.77,27.12,26.95,26.75,26.4,26,25.35,23.62,22.05,21.13,19.94,18.4,16.9,15.02,14.13]
# Note that the first zEXP and pEXP is excluded since it started with z=0.




ZCO2 = 0.3
mainXo = xo
mainComposition = copy.deepcopy(composition)

nc,composition,xo = addCarbon(ZCO2,composition,xo)
# nc,composition,xo = addCarbon(0.2208,composition,xo)
startPressure = 1.0e6
targetPressure = 38.0e6
# beta = np.array([[0.11111, 0.00001, 0.88888]])
beta = np.array([[0.909, 0.09, 0.001]])
# beta = np.array([[0.5, 0.5, 0.0]])
phases = [['liquid1'], ['liquid2'], ['vapour']]
Nsamples = 500
xres1 = []
pCounter=0
# iter, beta, xo, phases, tol = solveEOS(298.15, 6.0654e6, composition, xo, beta, phases)
# iter, beta, xo, phases, tol = solveEOS(290 , startPressure, composition, xo, beta, phases)
# iter, beta, xo, phases, tol = solveEOS(295, startPressure, composition, xo, beta, phases)
#======================================================
# startT = 250
# targetT = 500
# N = 100
# k=0
# condBreak = -1
# while k < N and condBreak == -1:
#     currentT = (targetT-startT)/ Nsamples * k + startT
#     # currentPressure =  startPressure - ( startPressure-targetPressure ) / Nsamples * i
#     # iter, beta, xo, phases,tol = solveEOS(temp, currentPressure, composition, xo, beta,phases)
#     # print( beta)
#     print(kij[20,17])
#     condBreak = 0

#====================================================
#
#
# temp = 423.15
# hBeta = []
# hXo = []
# hPhases = []
# hPressure = []
#
# i = 0
# condBreak = -1
# while i < Nsamples and condBreak == -1:
#     currentPressure = (targetPressure-startPressure)/ Nsamples * i + startPressure
#     # currentPressure =  startPressure - ( startPressure-targetPressure ) / Nsamples * i
#     iter, beta, xo, phases,tol = solveEOS(temp, currentPressure, composition, xo, beta,phases,ZCO2,fixedKij)
#     # print( beta)
#     print(i, ",", currentPressure * 1e-6, ",", phases, beta)
#     hBeta.append(beta)
#     hXo.append(xo)
#     hPhases.append(phases)
#     hPressure.append(currentPressure)
#     i = i + 1
#
#     if  beta[0, 0]>0.99999:
#     # if not (['vapour'] in phases):
#     # if beta[0, 0] < 0.001:
#     # if  :
#         condBreak = 0
#
#     # eps = 1.0e-8
#     # if len(phases) == 2:
#     #     nXo = np.zeros((18, 3))
#     #     nXo[:, 0] = copy.deepcopy(xo[:, 0])
#     #     nXo[:, 1] = copy.deepcopy(xo[:, 1])
#     #     if not (['liquid1'] in phases):
#     #         A = np.array(phases).reshape(2).tolist().index('liquid2')
#     #         B = np.array(phases).reshape(2).tolist().index('vapour')
#     #         phases = [['liquid1'], ['liquid2'], ['vapour']]
#     #         nXo[:, 0] = np.ones(18) / 18.0  # copy.deepcopy(xo[:, A])
#     #         # nXo[:, 0] = mainXo[:, 2]
#     #         nXo[:, 1] = copy.deepcopy(xo[:, A])
#     #         nXo[:, 2] = copy.deepcopy(xo[:, B])
#     #         beta = np.array([[2 * eps, beta[0, A] - eps, beta[0, B] - eps]])
#     #     elif not (['liquid2'] in phases):
#     #         A = np.array(phases).reshape(2).tolist().index('liquid1')
#     #         B = np.array(phases).reshape(2).tolist().index('vapour')
#     #         phases = [['liquid1'], ['liquid2'], ['vapour']]
#     #         nXo[:, 0] = copy.deepcopy(xo[:, A])
#     #         nXo[:, 1] = np.ones(18) / 18.0  # copy.deepcopy(xo[:, A])
#     #         # nXo[:, 1] = mainXo[:, 2]
#     #         nXo[:, 2] = copy.deepcopy(xo[:, B])
#     #         beta = np.array([[beta[0, A] - eps, 2 * eps, beta[0, B] - eps]])
#     #     else:
#     #         A = np.array(phases).reshape(2).tolist().index('liquid1')
#     #         B = np.array(phases).reshape(2).tolist().index('liquid2')
#     #         phases = [['liquid1'], ['liquid2'], ['vapour']]
#     #         nXo[:, 0] = copy.deepcopy(xo[:, A])
#     #         nXo[:, 1] = copy.deepcopy(xo[:, B])
#     #         # nXo[:, 2] =mainXo[:,2]
#     #         nXo[:, 2] = np.ones(18) / 18.0  # copy.deepcopy(xo[:, A])
#     #         beta = np.array([[beta[0, A] - eps, beta[0, B] - eps, 2 * eps]])
#     #     xo = copy.deepcopy(nXo)
#     #     # beta = np.array([[beta[0, 0] - 0.001, beta[0, 1] - 0.001, 0.002]])
#     #     # print(phases, beta)
#     # elif len(phases) == 1:
#     #     print("XXXXXXX")
#
# print(xo)
# print(beta)





#############################################3##


import csv
with open('Abol.csv', 'w', newline='') as file:
    writer = csv.writer(file)


temp = 423.15
fixedKij = [0]
# fixedKij[0] = 0
# fixedKij = [0]
ZCO2=0.01
# fixedKij = 0.10
# x1= [0]

def CalcCalc(temp,xo,startPressure,beta,phases,x):

    # pKijappend=[]
    # Errappend=[0]*len(pEXP)

    dPressure = (targetPressure - startPressure) / Nsamples
    # ep=0.05
    l=0
    RK=0.1
    LK=-0.1
    x1 = RK
    x2 = LK
    NK=20
    dK=(RK-LK)/NK
    # condBreak = 1
    fixedKij[0] = x
    pKij=[]
    KijList=[]
    MSEList=[]
    while l < NK :
        # print(l)
        # fixedKij[0] = dK * l + LK
        # fixedKij[0] = x1
        ZCO2=0.01
        # startPressure = hPressure[-1]
        dz = (1.0 - 0.0) / 100.0
        dzz = (1.0 - 0.8) / 100.0
        # dzz = dz
        j = 0
        # ZCO2 = 0.7332
        # XOOO = []
        # BetaOOO = []
        # KijList.append(fixedKij[0])
        pKij = []
        while (j<800 and ZCO2<0.999):
            # print(fixedKij[0])
            # ZCO2 = (1.0 - 0.0009) / 100.0 * j + 0.0009
            # ZCO2 = (1.0 - 0.0009) / 100.0 * j + 0.0009
            # ZCO2 = 0.820162
            nc,composition,_ = addCarbon(ZCO2,mainComposition,mainXo)
            #print(composition)
            condBreak = -1
            i = 0
            while i < 500 and condBreak == -1:
                currentPressure = dPressure * i + startPressure
                # currentPressure = startPressure - dPressure * i
                # if ZCO2 < 0.97 :
                #     currentPressure = dPressure * i + startPressure
                # else :
                #     currentPressure = dPressure * i + startPressure
                    # currentPressure = dPressure / 10 * i + startPressure
                if currentPressure < 0 :
                    currentPressure = 0.0
                    print(ZCO2, currentPressure * 1e-6, i )
                    break
                iter, beta, xo, phases,tol = solveEOS(temp, currentPressure, composition, xo, beta,phases,ZCO2,fixedKij)
                #print(i,",ZCo2=",ZCO2, ",", currentPressure,",",tol, ",", beta[0, 0])
                i = i + 1
                # phases
                # check = 0
                # if (['liquid1'] in phases):
                #     A = np.array(phases).reshape(2).tolist().index('liquid1')
                #     check = check + beta[0, A]
                # if (['liquid2'] in phases):
                #     B = np.array(phases).reshape(2).tolist().index('liquid2')
                #     check = check + beta[0, B]
                #
                # if check > 0.99999:
                #    condBreak = 0
                #    XOOO.append(xo)
                #    BetaOOO.append(beta)

                if beta[0, 0] > 0.99999:
                    condBreak = 0

                #     i = i + 1
                # else:
                #     condBreak = 0

                # eps = 1.0e-5
                # if len(phases) == 2:
                #     nXo = np.zeros((18, 3))
                #     nXo[:, 0] = copy.deepcopy(xo[:, 0])
                #     nXo[:, 1] = copy.deepcopy(xo[:, 1])
                #     if not (['liquid1'] in phases):
                #         A = np.array(phases).reshape(2).tolist().index('liquid2')
                #         B = np.array(phases).reshape(2).tolist().index('vapour')
                #         phases = [['liquid1'], ['liquid2'], ['vapour']]
                #         nXo[:, 0] = np.ones(18) / 18.0  # copy.deepcopy(xo[:, A])
                #         nXo[:, 1] = copy.deepcopy(xo[:, A])
                #         nXo[:, 2] = copy.deepcopy(xo[:, B])
                #         beta = np.array([[2 * eps, beta[0, A] - eps, beta[0, B] - eps]])
                #     elif not (['liquid2'] in phases):
                #         A = np.array(phases).reshape(2).tolist().index('liquid1')
                #         B = np.array(phases).reshape(2).tolist().index('vapour')
                #         phases = [['liquid1'], ['liquid2'], ['vapour']]
                #         nXo[:, 0] = copy.deepcopy(xo[:, A])
                #         nXo[:, 1] = np.ones(18) / 18.0  # copy.deepcopy(xo[:, A])
                #         nXo[:, 2] = copy.deepcopy(xo[:, B])
                #         beta = np.array([[beta[0, A] - eps, 2 * eps, beta[0, B] - eps]])
                #     else:
                #         A = np.array(phases).reshape(2).tolist().index('liquid1')
                #         B = np.array(phases).reshape(2).tolist().index('liquid2')
                #         phases = [['liquid1'], ['liquid2'], ['vapour']]
                #         nXo[:, 0] = copy.deepcopy(xo[:, A])
                #         nXo[:, 1] = copy.deepcopy(xo[:, B])
                #         nXo[:, 2] = np.ones(18) / 18.0  # copy.deepcopy(xo[:, A])
                #         beta = np.array([[beta[0, A] - eps, beta[0, B] - eps, 2 * eps]])
                #     xo = copy.deepcopy(nXo)
                #     # beta = np.array([[beta[0, 0] - 0.001, beta[0, 1] - 0.001, 0.002]])
                # elif len(phases) == 1:
                #     print("XXXXXXX")




            # print(f'{ZCO2:.10f}' , f'{currentPressure:.10f}')
            # if ZCO2 < 0.8:
            #     startPressure = currentPressure - 5 * dPressure
            # elif ZCO2 > 0.8 and ZCO2< 0.91:
            #     startPressure = currentPressure +5  * dPressure
            # else:
                # if ZCO2 < 0.95:
                #     startPressure = currentPressure - 15 * dPressure
                # elif ZCO2 > 0.95 and ZCO2 < 0.97:
                #     startPressure = currentPressure -25 * dPressure
                # startPressure = currentPressure - 40 * dPressure


            # print(ZCO2,currentPressure,i)
            # startPressure = currentPressure - 10*dPressure
        #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            if i < 3 and pCounter < 25 :  #and ZCO2 > 0.8:
                startPressure = currentPressure - 5.0 * dPressure
                # print("XXXX")
                # xo = copy.deepcopy(XOOO[-1])
                # beta = copy.deepcopy(BetaOOO[-2])
                # startPressure = currentPressure + 2.0 * dPressure
                #ZCO2=ZCO2
                pCounter += 1
            else:
                j = j + 1
                print(ZCO2, currentPressure * 1e-6,i,fixedKij[0])
                if ZCO2 < 0.8:
                    LastZ=ZCO2-dz
                else:
                    LastZ=ZCO2-dzz
                #print the selected results

                for c in range(len(zEXP)):
                    if zEXP[c]<ZCO2 and zEXP[c]>=LastZ:
                        print(zEXP[c],ZCO2, '<=====>', pEXP[c]-currentPressure*1e-6,'22222@@@@@222222' )
                        pKij.append(currentPressure * 1e-6)
                        # writer.writerow(pKij)
                        # data=pKij



                # cvs_writer.writerows(pKij)

                # fh.close()

                LastZ = ZCO2


                # KijList.append(fixedKij)
                # MSEList.append(MSEList)

                #====save
                # data_list = ['filepath1.csv', 'filepath2.csv', 'filepath3.csv']
                # d = {}
                # for i in enumerate(data_list):
                #     file_name = "df" + str(_)
                #     d[file_name] = pd.read_csv(filepath)

                # ZCO2 += dz
                # startPressure = currentPressure - dPressure
                startPressure = currentPressure + 1 * dPressure
                if ZCO2 < 0.8 :
                    ZCO2 += dz
                else:
                    ZCO2 += dzz
                    startPressure = currentPressure - 5 * dPressure

                pCounter = 0
        print(pKij,'___________________')



        #===MSE
        # pKij=pEXP

        Err=[]
        list=[]
        result = mean_squared_error(pEXP, pKij)
        Err.append(result)
        print('MSE=',Err,'------------------>')
        list.append(Err)
        # print('max=', max_error(pEXP, pKij), '==================')
        # print('RMSE=', sqrt(mean_squared_error(pEXP, pKij)), '==================')
        # print('MAE=', mae(pEXP, pKij), '==================')
        # print('RMSLE=', root_mean_squared_log_error(pEXP, pKij), '==================')



        # pKijappend[l]=pKij
        # Errappend[l]=Err
        # print(Errappend)
        # Errfile=pd.DataFrame(Errappend)
        # Errfile.to_csv(r'C:\Users\rezau\Desktop\a\result-CO2.csv', ';')
        #save resultsf
        # kVal=[]
        # kVal[l]=fixedKij[0]
        # with open('data', 'w', newline='') as csvfile:
        #     fieldnames=['Kij','Err']
        #     writer=csv.DictWriter(csvfile, fieldnames=fieldnames)
        #     writer.writeheader()
        #     writer.writerow({'Kij':fixedKij[0], 'Err': Err})



        l = l + 1
        # break


        ###################################################################
        # T1 = (time.time() - t1)
        # T2 = (time.time() - t2)
        # T3 = (time.time() - t3)
        # T4 = (time.time() - t4)
        #
        # print(T1, '=========', T2, '=======', T3, '=======', T4)



        #################################################################
        # break

        #+++++++++++++++++++++++++++++++++++++++++++++++++++
            # j = j + 1

        # print("==========================================================")
        # print(xres1)
        # print("==========================================================")
        # print(xo)
        # print("==========================================================")

        # if len(phases)==2:
        #     nXo = np.zeros((21, 3))
        #     nXo[:, 0] = xo[:, 0].copy()
        #     nXo[:, 1] = xo[:, 1].copy()
        #     if not ('liquid1' in phases):
        #         phases = [phases[0], phases[1],['liquid1']]
        #         A = np.array(phases).reshape(3).tolist().index('liquid2') #np.where(np.array(phases).reshape(3)=='liquid2')
        #         nXo[:, 2] = xo[:, A].copy()
        #     elif not ('liquid2' in phases):
        #         phases = [phases[0], phases[1], ['liquid2']]
        #         A = np.array(phases).reshape(3).tolist().index('liquid2')
        #         nXo[:, 2] = xo[:, A].copy()
        #     else:
        #         print("Error!!!")
        #     xo = nXo.copy()
        #     beta = np.array([[beta[0, 0] - 0.001, beta[0, 1] - 0.001, 0.002]])
        # elif len(phases)==1:
        #     print("XXXXXXX")

    # return iter, beta, xo, phases, tol, Err
    return Err
# CalcCalc(temp,xo,startPressure,beta,phases,fixedKij)
# fixedKij=0
# MSE=CalcCalc(temp,xo,startPressure,beta,phases,fixedKij)
# print(MSE)

#
######GoldenSettings###########################3
x1 = 0.1
x2 = -0.1
def func_fx(x):
    fx=CalcCalc(temp,xo,startPressure,beta,phases,x)
    return fx

# #############################################
def check_pos(x1,x2):
    if x2<x1:
        label='right'
    else:
        label=''
    return label

# #######################
#
#
def update_interior(xl,xu):
    # d=0.618
    d=((np.sqrt(5)-1)/2)*(xu-xl)
    x1=xl+d
    x2=xu-d
    return x1,x2

# ########################
#
# #FINDING MAXIMUM FUNCTION
def find_max(xl,xu,x1,x2,label):
    fx1=func_fx(x1)
    fx2=func_fx(x2)
    if fx2>fx1 and label=='right':
        xl=xl
        xu=x1
        new_x=update_interior(xl,xu)
        x1=new_x[0]
        x2=new_x[1]
        xopt=x2
    else:
        xl=x2
        xu=xu
        new_x=update_interior(xl,xu)
        x1=new_x[0]
        x2=new_x[1]
        xopt=x1
    return xl,xu,xopt
#
# #################################################
#
# #FINDING MINIMUM FUNCTION
def find_min(xl,xu,x1,x2,label):
    fx1=func_fx(x1)
    fx2=func_fx(x2)
    if fx2>fx1 and label=='right':
        xl=x2
        xu=xu
        new_x=update_interior(xl,xu)
        x1=new_x[0]
        x2=new_x[1]
        xopt=x1
    else:
        xl=xl
        xu=x1
        new_x=update_interior(xl,xu)
        x1=new_x[0]
        x2=new_x[1]
        xopt=x2
    return xl,xu,xopt

#
# ###############################################
#
# # PLOTTING FUNCTION
# def plot_graph(xl, xu, x1, x2):
#     clear_output(wait=True)
#
#     # plot sinus graph
#     plt.plot(x, y)
#     plt.plot([0, 6], [0, 0], 'k')
#
#     # plot x1 point
#     plt.plot(x1, func_fx(x1), 'ro', label='x1')
#     plt.plot([x1, x1], [0, func_fx(x1)], 'k')
#
#     # plot x2 point
#     plt.plot(x2, func_fx(x2), 'bo', label='x2')
#     plt.plot([x2, x2], [0, func_fx(x2)], 'k')
#
#     # plot xl line
#     plt.plot([xl, xl], [0, func_fx(xl)])
#     plt.annotate('xl', xy=(xl - 0.01, -0.2))
#
#     # plot xu line
#     plt.plot([xu, xu], [0, func_fx(xu)])
#     plt.annotate('xu', xy=(xu - 0.01, -0.2))
#
#     # plot x1 line
#     plt.plot([x1, x1], [0, func_fx(x1)], 'k')
#     plt.annotate('x1', xy=(x1 - 0.01, -0.2))
#
#     # plot x2 line
#     plt.plot([x2, x2], [0, func_fx(x2)], 'k')
#     plt.annotate('x2', xy=(x2 - 0.01, -0.2))
#
#     # y-axis limit
#     plt.ylim([-1.2, 1.2])
#     plt.show()
#
#
# ##############################################
#
def golden_search(xl, xu, mode, et):
    it = 0
    e = 1
    while e >= et:
        new_x = update_interior(xl, xu)
        x1 = new_x[0]
        x2 = new_x[1]
        fx1 = func_fx(x1)
        fx2 = func_fx(x2)
        label = check_pos(x1, x2)
        # clear_output(wait=True)
        # plot_graph(xl, xu, x1, x2)  # PLOTTING
        # plt.show()

        # SELECTING AND UPDATING BOUNDARY-INTERIOR POINTS
        if mode == 'max':
            new_boundary = find_max(xl, xu, x1, x2, label)
        elif mode == 'min':
            new_boundary = find_min(xl, xu, x1, x2, label)
        else:
            print('Please define min/max mode')
            break  # exit if mode not min or max
        xl = new_boundary[0]
        xu = new_boundary[1]
        xopt = new_boundary[2]

        it += 1
        print('Iteration: ', it)
        r = (np.sqrt(5) - 1) / 2  # GOLDEN RATIO
        # r=0.618
        e = ((1 - r) * (abs((xu - xl) / xopt))) * 100  # Error
        print('Error:', e)
        time.sleep(1)
#
#  #################################################################
# # GENERATE POINT FOR SINE GRAPH
# x = np.linspace(0, 6, 100)
# y = func_fx(x)
#
# # EXECUTING GOLDEN SEARCH FUNCTION
# def golden_search(xl,xu,mode,tol):
golden_search(-0.1, 0.1, 'min', 0.001)
#
#
# https://www.geodose.com/2021/06/golden-section-search-python-application-example.html
#  #################################################################
