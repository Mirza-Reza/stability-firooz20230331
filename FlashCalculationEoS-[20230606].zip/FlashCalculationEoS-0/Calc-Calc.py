def CalcCalc(temp,pressure,composition,xo,beta0,phases0,ZCO2,fixedKij):


    phases = copy.deepcopy(phases0)  # [['liquid1'], ['liquid2'], ['vapour']]

    nc = len(composition)  # Components number of the composition
    nph = len(phases)  # phases number
    nUph = nph

    zi = np.zeros((1, nc)).transpose()
    for comp in range(0, nc):
        zi[comp, 0] = np.array([[composition[comp]['z']]])

    betaInitVal = copy.deepcopy(beta0)  # # Initial guess of the phase fraction -beta-  [liquid, vapour]

    # =======================================================================================================

    import csv
    with open('Abol.csv', 'w', newline='') as file:
        writer = csv.writer(file)

    pKijappend = []
    Errappend = [0] * len(pEXP)
    temp = 423.15
    dPressure = (targetPressure - startPressure) / Nsamples
    # ep=0.05
    l = 0
    RK = 0.15
    LK = 0.1
    NK = 4
    dK = (RK - LK) / NK
    # condBreak = 1
    fixedKij = [0]
    pKij = []
    KijList = []
    MSEList = []
    while l < NK:

        # print(l)
        fixedKij[0] = dK * l + LK
        # fixedKij[0] = 0.107
        ZCO2 = 0.01
        # startPressure = hPressure[-1]
        dz = (1.0 - 0.0) / 100.0
        dzz = (1.0 - 0.8) / 100.0
        # dzz = dz
        j = 0
        # ZCO2 = 0.7332
        # XOOO = []
        # BetaOOO = []
        KijList.append(fixedKij[0])
        pKij = []
        while (j < 800 and ZCO2 < 0.999):
            # print(fixedKij[0])
            # ZCO2 = (1.0 - 0.0009) / 100.0 * j + 0.0009
            # ZCO2 = (1.0 - 0.0009) / 100.0 * j + 0.0009
            # ZCO2 = 0.820162
            nc, composition, _ = addCarbon(ZCO2, mainComposition, mainXo)
            # print(composition)
            condBreak = -1
            i = 0
            while i < 500 and condBreak == -1:
                currentPressure = dPressure * i + startPressure
                # currentPressure = startPressure - dPressure * i
                # if ZCO2 < 0.97 :
                #     currentPressure = dPressure * i + startPressure
                # else :
                #     currentPressure = dPressure * i + startPressure
                # currentPressure = dPressure / 10 * i + startPressure
                if currentPressure < 0:
                    currentPressure = 0.0
                    print(ZCO2, currentPressure * 1e-6, i)
                    break
                iter, beta, xo, phases, tol = solveEOS(temp, currentPressure, composition, xo, beta, phases, ZCO2,
                                                       fixedKij)
                # print(i,",ZCo2=",ZCO2, ",", currentPressure,",",tol, ",", beta[0, 0])
                i = i + 1
                # phases
                # check = 0
                # if (['liquid1'] in phases):
                #     A = np.array(phases).reshape(2).tolist().index('liquid1')
                #     check = check + beta[0, A]
                # if (['liquid2'] in phases):
                #     B = np.array(phases).reshape(2).tolist().index('liquid2')
                #     check = check + beta[0, B]
                #
                # if check > 0.99999:
                #    condBreak = 0
                #    XOOO.append(xo)
                #    BetaOOO.append(beta)

                if beta[0, 0] > 0.99999:
                    condBreak = 0

                #     i = i + 1
                # else:
                #     condBreak = 0

                # eps = 1.0e-5
                # if len(phases) == 2:
                #     nXo = np.zeros((18, 3))
                #     nXo[:, 0] = copy.deepcopy(xo[:, 0])
                #     nXo[:, 1] = copy.deepcopy(xo[:, 1])
                #     if not (['liquid1'] in phases):
                #         A = np.array(phases).reshape(2).tolist().index('liquid2')
                #         B = np.array(phases).reshape(2).tolist().index('vapour')
                #         phases = [['liquid1'], ['liquid2'], ['vapour']]
                #         nXo[:, 0] = np.ones(18) / 18.0  # copy.deepcopy(xo[:, A])
                #         nXo[:, 1] = copy.deepcopy(xo[:, A])
                #         nXo[:, 2] = copy.deepcopy(xo[:, B])
                #         beta = np.array([[2 * eps, beta[0, A] - eps, beta[0, B] - eps]])
                #     elif not (['liquid2'] in phases):
                #         A = np.array(phases).reshape(2).tolist().index('liquid1')
                #         B = np.array(phases).reshape(2).tolist().index('vapour')
                #         phases = [['liquid1'], ['liquid2'], ['vapour']]
                #         nXo[:, 0] = copy.deepcopy(xo[:, A])
                #         nXo[:, 1] = np.ones(18) / 18.0  # copy.deepcopy(xo[:, A])
                #         nXo[:, 2] = copy.deepcopy(xo[:, B])
                #         beta = np.array([[beta[0, A] - eps, 2 * eps, beta[0, B] - eps]])
                #     else:
                #         A = np.array(phases).reshape(2).tolist().index('liquid1')
                #         B = np.array(phases).reshape(2).tolist().index('liquid2')
                #         phases = [['liquid1'], ['liquid2'], ['vapour']]
                #         nXo[:, 0] = copy.deepcopy(xo[:, A])
                #         nXo[:, 1] = copy.deepcopy(xo[:, B])
                #         nXo[:, 2] = np.ones(18) / 18.0  # copy.deepcopy(xo[:, A])
                #         beta = np.array([[beta[0, A] - eps, beta[0, B] - eps, 2 * eps]])
                #     xo = copy.deepcopy(nXo)
                #     # beta = np.array([[beta[0, 0] - 0.001, beta[0, 1] - 0.001, 0.002]])
                # elif len(phases) == 1:
                #     print("XXXXXXX")

            # print(f'{ZCO2:.10f}' , f'{currentPressure:.10f}')
            # if ZCO2 < 0.8:
            #     startPressure = currentPressure - 5 * dPressure
            # elif ZCO2 > 0.8 and ZCO2< 0.91:
            #     startPressure = currentPressure +5  * dPressure
            # else:
            # if ZCO2 < 0.95:
            #     startPressure = currentPressure - 15 * dPressure
            # elif ZCO2 > 0.95 and ZCO2 < 0.97:
            #     startPressure = currentPressure -25 * dPressure
            # startPressure = currentPressure - 40 * dPressure

            # print(ZCO2,currentPressure,i)
            # startPressure = currentPressure - 10*dPressure
            # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            if i < 3 and pCounter < 25:  # and ZCO2 > 0.8:
                startPressure = currentPressure - 5.0 * dPressure
                # print("XXXX")
                # xo = copy.deepcopy(XOOO[-1])
                # beta = copy.deepcopy(BetaOOO[-2])
                # startPressure = currentPressure + 2.0 * dPressure
                # ZCO2=ZCO2
                pCounter += 1
            else:
                j = j + 1
                print(ZCO2, currentPressure * 1e-6, i, fixedKij[0])
                if ZCO2 < 0.8:
                    LastZ = ZCO2 - dz
                else:
                    LastZ = ZCO2 - dzz
                # print the selected results

                for c in range(len(zEXP)):
                    if zEXP[c] < ZCO2 and zEXP[c] >= LastZ:
                        print(zEXP[c], ZCO2, '<=====>', pEXP[c] - currentPressure * 1e-6, '22222@@@@@222222')
                        pKij.append(currentPressure * 1e-6)
                        # writer.writerow(pKij)
                        # data=pKij

                # cvs_writer.writerows(pKij)

                # fh.close()

                LastZ = ZCO2

                # KijList.append(fixedKij)
                # MSEList.append(MSEList)

                # ====save
                # data_list = ['filepath1.csv', 'filepath2.csv', 'filepath3.csv']
                # d = {}
                # for i in enumerate(data_list):
                #     file_name = "df" + str(_)
                #     d[file_name] = pd.read_csv(filepath)

                # ZCO2 += dz
                # startPressure = currentPressure - dPressure
                startPressure = currentPressure + 1 * dPressure
                if ZCO2 < 0.8:
                    ZCO2 += dz
                else:
                    ZCO2 += dzz
                    startPressure = currentPressure - 5 * dPressure

                pCounter = 0
        print(pKij, '___________________')

        # ===MSE
        # pKij=pEXP

        Err = []
        list = []
        result = mean_squared_error(pEXP, pKij)
        Err.append(result)
        print('MSE=', Err, '------------------>')
        list.append(Err)
        print('max=', max_error(pEXP, pKij), '==================')
        print('RMSE=', sqrt(mean_squared_error(pEXP, pKij)), '==================')
        print('MAE=', mae(pEXP, pKij), '==================')
        print('RMSLE=', root_mean_squared_log_error(pEXP, pKij), '==================')

        # pKijappend[l]=pKij
        # Errappend[l]=Err
        # print(Errappend)
        # Errfile=pd.DataFrame(Errappend)
        # Errfile.to_csv(r'C:\Users\rezau\Desktop\a\result-CO2.csv', ';')
        # save resultsf
        # kVal=[]
        # kVal[l]=fixedKij[0]
        # with open('data', 'w', newline='') as csvfile:
        #     fieldnames=['Kij','Err']
        #     writer=csv.DictWriter(csvfile, fieldnames=fieldnames)
        #     writer.writeheader()
        #     writer.writerow({'Kij':fixedKij[0], 'Err': Err})

        l = l + 1

        ###################################################################
        T1 = (time.time() - t1)
        T2 = (time.time() - t2)
        T3 = (time.time() - t3)
        T4 = (time.time() - t4)

        print(T1, '=========', T2, '=======', T3, '=======', T4)

        #################################################################
        # break

        # +++++++++++++++++++++++++++++++++++++++++++++++++++
        # j = j + 1

        # print("==========================================================")
        # print(xres1)
        # print("==========================================================")
        # print(xo)
        # print("==========================================================")

        # if len(phases)==2:
        #     nXo = np.zeros((21, 3))
        #     nXo[:, 0] = xo[:, 0].copy()
        #     nXo[:, 1] = xo[:, 1].copy()
        #     if not ('liquid1' in phases):
        #         phases = [phases[0], phases[1],['liquid1']]
        #         A = np.array(phases).reshape(3).tolist().index('liquid2') #np.where(np.array(phases).reshape(3)=='liquid2')
        #         nXo[:, 2] = xo[:, A].copy()
        #     elif not ('liquid2' in phases):
        #         phases = [phases[0], phases[1], ['liquid2']]
        #         A = np.array(phases).reshape(3).tolist().index('liquid2')
        #         nXo[:, 2] = xo[:, A].copy()
        #     else:
        #         print("Error!!!")
        #     xo = nXo.copy()
        #     beta = np.array([[beta[0, 0] - 0.001, beta[0, 1] - 0.001, 0.002]])
        # elif len(phases)==1:
        #     print("XXXXXXX")