import numpy as np
from PPR78 import EoS
import math
import matplotlib.pyplot as plt
import scipy.optimize
from scipy.optimize import fsolve
import pandas as pd
import copy
import csv
import time
import csv
import os.path
#See discussions, stats, and author profiles for this publication at: https://www.researchgate.net/publication/227541887
#based on Firoozabadi paper



#========= CPU-time   ==============================
t2 = time.time()

# inputs----------------------------------------------------------------------

#=========================  2  =========================================
# composition = [{'name': 'CH4', 'z': 0.7, 'Tc': 190.6, 'Pc': 4.6e6, 'w': 0.008},
#                {'name': 'C6H14', 'z': 0.3, 'Tc': 507.4, 'Pc': 2.96e6, 'w': 0.26}]
# nc = len(composition)


#========================= 14  =========================================
# composition = [{'name': 'N2', 'z': 0.0019, 'Tc': 126.2, 'Pc': 3.35e6, 'w': 0.040},
#                {'name': 'CO2', 'z': 0.0101, 'Tc': 304.2, 'Pc': 7.28e6, 'w': 0.225},
#                {'name': 'C1', 'z': 0.8649, 'Tc': 190.6, 'Pc': 4.54e6, 'w': 0.008},
#                {'name': 'C2', 'z': 0.02480, 'Tc': 305.4, 'Pc': 4.82e6, 'w': 0.098},
#                {'name': 'C3', 'z': 0.01280, 'Tc': 369.8, 'Pc': 4.19e6, 'w': 0.152},
#                {'name': 'iC4', 'z': 0.00720, 'Tc': 408.1, 'Pc': 3.6e6, 'w': 0.176},
#                {'name': 'nC4', 'z': 0.00370, 'Tc': 425.2, 'Pc': 3.75e6, 'w': 0.193},
#                {'name': 'iC5', 'z': 0.00220, 'Tc': 460.4, 'Pc': 3.34e6, 'w': 0.227},
#                {'name': 'nC5', 'z': 0.00140, 'Tc': 469.6, 'Pc': 3.33e6, 'w': 0.251},
#                {'name': 'C6-C9', 'z': 0.009978, 'Tc': 547.43, 'Pc': 3.03e6, 'w': 0.4099},
#                {'name': 'C10-C14', 'z': 0.012590, 'Tc': 643.77, 'Pc': 2.29e6, 'w': 0.6714},
#                {'name': 'C15-C19', 'z': 0.012321, 'Tc': 724.23, 'Pc': 1.7e6, 'w': 0.9296},
#                {'name': 'C20-C24', 'z': 0.009024, 'Tc': 777.38, 'Pc': 1.34e6, 'w': 1.1603},
#                {'name': 'C25+', 'z': 0.027087, 'Tc': 849.61, 'Pc': 0.99e6, 'w': 1.6043}]
# nc = len(composition)



#========================= 21  =========================================
composition=[{'name': '2,2-dimethylbutane', 'z': 0.02502, 'Tc': 489.21, 'Pc': 3102000, 'w': 0.2251, 'M': 86.1766},
             {'name': 'n-heptane', 'z': 0.02196, 'Tc': 540.3, 'Pc': 2734000, 'w': 0.3481, 'M': 100.203},
             {'name': 'ethylcyclohexane', 'z': 0.01302, 'Tc': 606.9, 'Pc': 3250000, 'w': 0.318, 'M': 112.21},
             {'name': 'n-nonane', 'z': 0.01056, 'Tc': 594.7, 'Pc': 2280000, 'w': 0.4409, 'M': 128.26},
             {'name': 'propylcyclohexane', 'z': 0.0063, 'Tc': 630.8, 'Pc': 2860000, 'w': 0.3149, 'M': 126.24},
             {'name': '1,2,3,4-tetrahydronaphthalene', 'z': 0.00954, 'Tc': 719.5, 'Pc': 3630000, 'w': 0.3318, 'M': 132.21},
             {'name': '1,3,5-triethylbenzene', 'z': 0.013980000000000001, 'Tc': 679, 'Pc': 2330000, 'w': 0.507, 'M': 162.27},
             {'name': '1-phenylhexane', 'z': 0.00798, 'Tc': 695, 'Pc': 2350000, 'w': 0.4498, 'M': 162.27},
             {'name': 'n-tridecane', 'z': 0.00264, 'Tc': 676, 'Pc': 1679000, 'w': 0.6099, 'M': 184.37},
             {'name': '1-phenyloctane', 'z': 0.01338, 'Tc': 725, 'Pc': 1980000, 'w': 0.5845, 'M': 190.32},
             {'name': 'n-pentadecane', 'z': 0.00654, 'Tc': 707.5, 'Pc': 1479000, 'w': 0.7192, 'M': 212.41},
             {'name': 'n-hexadecane', 'z': 0.00276, 'Tc': 722.4, 'Pc': 1401000, 'w': 0.7442, 'M': 226.43},
             {'name': 'octadecane', 'z': 0.00882, 'Tc': 747.7, 'Pc': 1292000, 'w': 0.802, 'M': 254.48},
             {'name': 'nonadecane', 'z': 0.00768, 'Tc': 755.3, 'Pc': 1160000, 'w': 0.8722, 'M': 268.51},
             {'name': '1-phenylhexadecane', 'z': 0.00942, 'Tc': 827.35, 'Pc': 1279000, 'w': 0.9055, 'M': 316.57},
             {'name': 'tetracosane', 'z': 0.00138, 'Tc': 799.8, 'Pc': 1075000, 'w': 1.184, 'M': 338.64},
             {'name': 'squalane', 'z': 0.048960000000000004, 'Tc': 820, 'Pc': 900000, 'w': 1.2436, 'M': 422.82},
             {'name': 'methane', 'z': 0.3171, 'Tc': 190.56, 'Pc': 4599000, 'w': 0.01, 'M': 16.04},
             {'name': 'ethane', 'z': 0.049139999999999996, 'Tc': 305.32, 'Pc': 4872000, 'w': 0.099, 'M': 30.07},
             {'name': 'propane', 'z': 0.023819999999999997, 'Tc': 370.01, 'Pc': 4260000, 'w': 0.152, 'M': 44.1},
             {'name': 'carbon dioxide', 'z': 0.4, 'Tc': 304.2, 'Pc': 7280000.0, 'w': 0.225, 'M': 44.01}]
nc = len(composition)



# composition = [{'name': 'N2', 'z': 0.0019, 'Tc': 126.2, 'Pc': 3.35e6, 'w': 0.040},
#                {'name': 'CO2', 'z': 0.0101, 'Tc': 304.2, 'Pc': 7.28e6, 'w': 0.225},
#                {'name': 'C1', 'z': 0.8649, 'Tc': 190.6, 'Pc': 4.54e6, 'w': 0.008},
#                {'name': 'C2', 'z': 0.02480, 'Tc': 305.4, 'Pc': 4.82e6, 'w': 0.098},
#                {'name': 'C3', 'z': 0.01280, 'Tc': 369.8, 'Pc': 4.19e6, 'w': 0.152},
#                {'name': 'iC4', 'z': 0.00720, 'Tc': 408.1, 'Pc': 3.6e6, 'w': 0.176},
#                {'name': 'nC4', 'z': 0.00370, 'Tc': 425.2, 'Pc': 3.75e6, 'w': 0.193},
#                {'name': 'iC5', 'z': 0.00220, 'Tc': 460.4, 'Pc': 3.34e6, 'w': 0.227},
#                {'name': 'nC5', 'z': 0.00140, 'Tc': 469.6, 'Pc': 3.33e6, 'w': 0.251},
#                {'name': 'C6-C9', 'z': 0.009978, 'Tc': 547.43, 'Pc': 3.03e6, 'w': 0.4099},
#                {'name': 'C10-C14', 'z': 0.012590, 'Tc': 643.77, 'Pc': 2.29e6, 'w': 0.6714},
#                {'name': 'C15-C19', 'z': 0.012321, 'Tc': 724.23, 'Pc': 1.7e6, 'w': 0.9296},
#                {'name': 'C20-C24', 'z': 0.009024, 'Tc': 777.38, 'Pc': 1.34e6, 'w': 1.1603},
#                {'name': 'C25+', 'z': 0.027087, 'Tc': 849.61, 'Pc': 0.99e6, 'w': 1.6043}]
# nc = len(composition)





#=== inputs ===============================================

Zi = np.zeros((1, nc)).transpose()
for comp in range(0, nc):
    Zi[comp, 0] = np.array([[composition[comp]['z']]])
###### kij - 2 component case +++++++++++++++++++++++++++++++++++++++++++++++
# in the case of 2 component kij considered 0
# Kij = [[ 0 for i in range(nc) ] for j in range(nc)]
# for i in range(nc):
#     for j in range(nc):
#         Kij[i][j]=0


# Kij = np.array([[0.0,0.005],
#                 [0.005,0.0]])


#================21 ===============================
# Kij=np.zeros((len(composition), len(composition)))

Kij = np.array([[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]])

print(np.shape(Kij))

# -----------------------------------------------------------------------------------
###### kij - 14 component case ++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# Kij = np.array([[0,-0.02,0.12,0.12,0.12,0.12,0.12,0.12,0.12,0.12,0.12,0.12,0.12,0.12],
# [- 0.02,0,0.093,0.128,0.123,0.136,0.125,0.131,0.12,0.12,0.12,0.12,0.12,0.12],
# [0.12,0.093,0,0,0,0.02,0.02,0.025,0.025,0.035,0.038,0.038,0.038,0.038],
# [0.12,0.128,0,0,0,0,0,0,0,0,0,0,0,0],
# [0.12,0.123,0,0,0,0,0,0,0,0,0,0,0,0],
# [0.12,0.136,0.02,0,0,0,0,0,0,0,0,0,0,0],
# [0.12,0.125,0.02,0,0,0,0,0,0,0,0,0,0,0],
# [0.12,0.131,0.025,0,0,0,0,0,0,0,0,0,0,0],
# [0.12,0.12,0.025,0,0,0,0,0,0,0,0,0,0,0],
# [0.12,0.12,0.035,0,0,0,0,0,0,0,0,0,0,0],
# [0.12,0.12,0.038,0,0,0,0,0,0,0,0,0,0,0],
# [0.12,0.12,0.038,0,0,0,0,0,0,0,0,0,0,0],
# [0.12,0.12,0.038,0,0,0,0,0,0,0,0,0,0,0],
# [0.12,0.12,0.038,0,0,0,0,0,0,0,0,0,0,0]])


#
# Kij = np.array([[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],
#                 [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],
#                 [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],
#                 [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],
#                 [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],
#                 [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],
#                 [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],
#                 [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],
#                 [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],
#                 [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],
#                 [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],
#                 [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],
#                 [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],
#                 [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]])





# Fugacity ------------------------------------------------------------------
# we have fug and fugZi which the difference is in fug defined all here but fugZi calls PPR and Mixing rules
def fug(pressure, temp, composition, Zi, phase):

    R = np.float64(8.314472)  # Ideal gas constant [J.mol^{-1}.K^{-1}]  MPa.cm^3/mol.K
    T = np.float64(temp)  # Temperature [K]
    P = np.float64(pressure)  # Pressure [Pa]
    nc = len(composition)  # Components number of the composition


    # from PPR78 import EoS
    # ai, bi, alphai = EoS(pressure, temp, composition)
    ai = np.zeros((len(composition), 1))
    alphai = np.zeros((len(composition), 1))
    bi = np.zeros((len(composition), 1))
    bj = np.zeros((len(composition), 1))  # used in derivatives


    mi = np.zeros((len(composition), 1))
    for i in range(len(composition)):
        ai[i] = 0.42748 * (pow(R, 2) * pow(composition[i]['Tc'], 2) / composition[i]['Pc'])
        mi[i] = 0.480 + 1.574 * composition[i]['w'] - 0.176 * pow(composition[i]['w'], 2)
        alphai[i] =pow(1 + mi[i] * (1 - pow(T / composition[i]['Tc'], 0.5)), 2)
        bi[i] = 0.08664 * R * composition[i]['Tc'] / composition[i]['Pc']

    # =================aij  bij ================================================================================
    # from mixingRules import mixRules
    # ami, bmi , alphaij,sig= mixRules(pressure, temp, composition,Zi, ai, bi, alphai)

    aijVal = np.zeros((len(composition), len(composition)))
    bijVal = np.zeros((len(composition), len(composition)))

    sigj = np.zeros((len(composition), 1))
    sig = np.zeros((len(composition), 1))

    aj = np.zeros((len(composition), 1))
    alphaij = np.zeros((len(composition), 1))
    biVal = np.zeros((len(composition), 1))
    miVal = np.zeros((len(composition), 1))

    alphaj = np.zeros((len(composition), 1))
    alphaij = np.zeros((len(composition), len(composition)))
    # biVal = np.zeros((len(composition), 1))
    mj = np.zeros((len(composition), 1))
    ami = []
    bmi = []


    lijVal = np.zeros((nc, nc))
    j = 0
    ami = []
    bmi = []
    for i in range(len(composition)):
        sig[i] = 0
        for j in range(len(composition)):
            aj[j] = 0.42748 * (pow(R, 2) * pow(composition[j]['Tc'], 2) / composition[j]['Pc'])
            mj[j] = 0.480 + 1.574 * composition[j]['w'] - 0.176 * pow(composition[j]['w'], 2)
            alphaj[j] = pow(1 + mj[j] * (1 - pow(T / composition[j]['Tc'], 0.5)), 2)
            alphaij[i, j] = (1 - Kij[i, j]) * (pow(alphai[i] * ai[i] * alphaj[j] * aj[j], 0.5))

        j = 0
    bmi = np.array(sum(bi * Zi))
    ami = np.array([sum(alphaij.dot(Zi) * Zi)])

    for i in range(len(composition)):
        sig[i] = 0
        for j in range(len(composition)):
            sigj[j] = (Zi[j] * alphaij[i, j])
            sig[i] += sigj[j]
        j = 0

    # =================Compressibility factor roots & Fugacity Coefficients of the cubic EoS====================================
    # ======Parameters ami and bmi are still part of mixing rules calculus===============
    # ami =np.array([sum(alphaij.dot(xi) * xi)])
    # bmi =np.array(sum(bi*xi)) #sum(bij.dot(xi))
    # ======end of Parameters ami and bmi are still part of mixing rules calculus===============

    A = (ami * P) / (pow(R * T, 2))
    B = bmi * P / (R * T)

    A0 = (ami * P) / (pow(R * T, 2))
    B0 = (bmi * P) / (R * T)

    A = np.array(np.squeeze(A0))
    B = np.array(np.squeeze(B0))


    #============END of ONLY FOR PLOTTING===============================

    # rootSol = np.roots([1,B - 1, A - 2 * B - 3 * B*B,B*B + B*B*B- (A * B)])
    rootSol = np.roots([1, - 1, A - B - B*B , -(A * B)])
    roots = np.real(rootSol[np.isreal(rootSol)])


    # print(rootSol)
    # print(roots)

    if phase == ["liquid1"]  or phase == ["liquid2"] : # phases[0]:
        Zt = min(roots)
        # if Zt<0:
        #     # Zt=max(roots)
        #     Zt = 0.9

        # Zt = max(roots)
        # v = (Zt * R * T) / P
    elif phase == ["vapour"]: #phases[2]:
        Zt = max(roots)
        # Zt = min(roots)
        v = (Zt * R * T) / P
    else:
        print("the value is not correct")
    bmii = np.array(bi / bmi)
    if Zt <= B:
        fugVal = np.zeros((len(composition), 1))
        # fugVal = 1000
    else:
        Z = Zt
        fugVal = (bmii * (Z * np.ones((nc, 1)) - np.ones((nc, 1)))) - np.log(
            Z * np.ones((nc, 1)) - B * np.ones((nc, 1))) + (A / B) * (bmii - (2 / ami * (np.dot(alphaij, Zi).reshape(-1, 1)))) * np.log(
            (1.0 + (B / (Z * np.ones((nc, 1))))))




    # if Z<=B:
    # fugVal = (bmii * (Z * np.ones((nc, 1)) - np.ones((nc, 1)))) + (
    #                      A / B) * (bmii - (2 / ami * (np.dot(alphaij, Zi).reshape(-1, 1)))) * np.log(
    #         (1.0 + (B / (Z * np.ones((nc, 1))))))
    #     Z = 0.9
    #
    # fugVal = (bmii * (Z * np.ones((nc, 1)) - np.ones((nc, 1)))) - np.log(
    #         Z * np.ones((nc, 1)) - B * np.ones((nc, 1))) + (
    #                      A / B) * (bmii - (2 / ami * (np.dot(alphaij, Zi).reshape(-1, 1)))) * np.log(
    #         (1.0 + (B / (Z * np.ones((nc, 1))))))
    #
    # else:
    #     Z = Zt






    # return fugVal
# ===============================================================================
    # Density - based phase envelope construction Dan Vladimir Nichita  pg 12
 # ==========================================================================
    #  derivatives
#     epsilon=1e-3
#     Kappa = Z * R * T / bmi / P
#     F1 = 1.0 / (Kappa - 1.0)
#     F2 = 2.0 / (Kappa + 1.0)
#     F3 = 1.0 / (Kappa + 1.0) / (Kappa + 1.0)
#     F5 = 2.0 * np.log((Kappa + 1.0) / Kappa)
#     F6 = F2 - F5
#     testf=np.zeros((len(composition), 1))
#     test=np.zeros((len(composition), 1))
#     parFij = np.ones((nc, nc))
#     for i in range(len(composition)):
#         bi = 0.08664 * R * composition[i]['Tc'] / composition[i]['Pc']
#         Betai = bi/ bmi
#         ai[j] = 0.42748 * (pow(R, 2) * pow(composition[i]['Tc'], 2) / composition[i]['Pc'])
#         mi[j] = 0.480 + 1.574 * composition[i]['w'] - 0.176 * pow(composition[i]['w'], 2)
#         alphai[i] = pow(1 + mi[i] * (1 - pow(T / composition[i]['Tc'], 0.5)), 2)
#         for j in range(len(composition)):
#             bj = 0.08664 * R * composition[j]['Tc'] / composition[j]['Pc']
#             Betaj = bj/ bmi
#             aj[j] = 0.42748 * (pow(R, 2) * pow(composition[j]['Tc'], 2) / composition[j]['Pc'])
#             mj[j] = 0.480 + 1.574 * composition[j]['w'] - 0.176 * pow(composition[j]['w'], 2)
#             alphaj[j] = pow(1 + mj[j] * (1 - pow(T / composition[j]['Tc'], 0.5)), 2)
# # The fugacity of component i in the mixture [newton paper A8]
#             testf[j] = np.log(composition[j]['z']) + Betai * F1 - np.log(bmi / (F1 * R * T)) - ami / (bmi * R * T) * (
#                         alphai[i] * F5 + 0.5 * Betai * F6)
#
#             test[j] = np.log(composition[j]['z']+epsilon) + Betai * F1 - np.log(bmi / (F1 * R * T)) - ami / (bmi * R * T) * (
#                     alphai[i] * F5 + 0.5 * Betai * F6)
#             d=(test[j]-testf[j])/epsilon
#
#             parFij[i][j] = (Betai * Betaj) *F1 + Betai * Betaj * F1 * F1 +  ami / (bmi * R * T) * (
#                     Betai * Betaj * F3 - alphaij[i, j] / ami * F5 + (Betai * Betai - alphai[i] * Betaj - alphaj[j] * Betai)*F6)
    return fugVal

# def fugZi(pressure, temp, composition, Zi, phasezi):
#
#     R = np.float64(8.314472)  # Ideal gas constant [J.mol^{-1}.K^{-1}]  MPa.cm^3/mol.K
#     T = np.float64(temp)  # Temperature [K]
#     P = np.float64(pressure)  # Pressure [Pa]
#     nc = len(composition)  # Components number of the composition
#
#     from PPR78 import EoS
#     ai, bi, alphai = EoS(pressure, temp, composition)
#
#     # =================aij  bij ================================================================================
#     from mixingRules import mixRules
#     ami, bmi , alphaij,sig= mixRules(pressure, temp, composition,Zi, ai, bi, alphai)
#
#
#     # =================Compressibility factor roots & Fugacity Coefficients of the cubic EoS====================================
#     # ======Parameters ami and bmi are still part of mixing rules calculus===============
#     # ami =np.array([sum(alphaij.dot(xi) * xi)])
#     # bmi =np.array(sum(bi*xi)) #sum(bij.dot(xi))
#     # ======end of Parameters ami and bmi are still part of mixing rules calculus===============
#
#     A = (ami * P) / (pow(R * T, 2))
#     B = bmi * P / (R * T)
#
#     A0 = (ami * P) / (pow(R * T, 2))
#     B0 = (bmi * P) / (R * T)
#
#     A = np.array(np.squeeze(A0))
#     B = np.array(np.squeeze(B0))
#
#
#     #============END of ONLY FOR PLOTTING===============================
#
#     # rootSol = np.roots([1,B - 1, A - 2 * B - 3 * B*B,B*B + B*B*B- (A * B)])
#     rootSol = np.roots([1, - 1, A - B - B*B , -(A * B)])
#     roots = np.real(rootSol[np.isreal(rootSol)])
#
#
#
#
#     if phasezi == ["liquid1"]  or phase == ["liquid2"] : # phases[0]:
#         Zt = min(roots)
#         if Zt<0:
#             Zt=max(roots)
#         # Zt = max(roots)
#         v = (Zt * R * T) / P
#     elif phasezi == ["vapour"]: #phases[2]:
#         Zt = max(roots)
#         # Zt = min(roots)
#         v = (Zt * R * T) / P
#     else:
#         print("the value is not correct")
#     bmii = np.array(bi / bmi)
#     Z = Zt
#
#     fugVal = (bmii * (Z * np.ones((nc, 1)) - np.ones((nc, 1)))) - np.log(Z * np.ones((nc, 1)) - B * np.ones((nc, 1))) + (
#                 A / B) * (bmii - (2 / ami * (np.dot(alphaij, Zi).reshape(-1, 1)))) * np.log((1.0 + (B / (Z * np.ones((nc, 1))))))
#     return fugVal
#     # print(fugVal)



# def fugWi(pressure, temp, composition, Wi, phasewi):
#
#     R = np.float64(8.314472)  # Ideal gas constant [J.mol^{-1}.K^{-1}]  MPa.cm^3/mol.K
#     T = np.float64(temp)  # Temperature [K]
#     P = np.float64(pressure)  # Pressure [Pa]
#     nc = len(composition)  # Components number of the composition
#
#     from PPR78 import EoS
#     ai, bi, alphai = EoS(pressure, temp, composition)
#
#     # =================aij  bij ================================================================================
#     from mixingRules import mixRules
#     ami, bmi , alphaij,sig= mixRules(pressure, temp, composition,Wi, ai, bi, alphai)
#
#
#     A = (ami * P) / (pow(R * T, 2))
#     B = bmi * P / (R * T)
#
#     A0 = (ami * P) / (pow(R * T, 2))
#     B0 = (bmi * P) / (R * T)
#
#     A = np.array(np.squeeze(A0))
#     B = np.array(np.squeeze(B0))
#
#
#     #============END of ONLY FOR PLOTTING===============================
#
#     # rootSol = np.roots([1,B - 1, A - 2 * B - 3 * B*B,B*B + B*B*B- (A * B)])
#     rootSol = np.roots([1, - 1, A - B - B*B , -(A * B)])
#     roots = np.real(rootSol[np.isreal(rootSol)])
#
#
#     # print(rootSol)
#     # print(roots)
#
#     if phasewi == ["liquid1"]  or phasewi == ["liquid2"] : # phases[0]:
#         Zt = min(roots)
#         if Zt<0:
#             Zt=max(roots)
#         # Zt = max(roots)
#         v = (Zt * R * T) / P
#     elif phasewi == ["vapour"]: #phases[2]:
#         Zt = max(roots)
#         # Zt = min(roots)
#         v = (Zt * R * T) / P
#     else:
#         print("the value is not correct")
#     bmii = np.array(bi / bmi)
#     Z = Zt
#
#     fugVal = (bmii * (Z * np.ones((nc, 1)) - np.ones((nc, 1)))) - np.log(Z * np.ones((nc, 1)) - B * np.ones((nc, 1))) + (
#                 A / B) * (bmii - (2 / ami * (np.dot(alphaij, Wi).reshape(-1, 1)))) * np.log((1.0 + (B / (Z * np.ones((nc, 1))))))
#     return fugVal
#     # print(fugVal)
def TPD_minimum(cPress, cTemp,composition,  phasezi,phasewi, Zi):
    TPDr=[]
    TPDi=[]

    # for phasezi in phasesZi:
    #     for phasewi in phasesWi:
    #         print('            ======================', phasezi, phasewi, '=================')
    # Types = [1, 2, 3, 4]
    Types = [1,3]
    typ = 0
    for typ in Types:
        # print(
        #     '===================================================================================================')
        # print('type ==', typ, '<==============>', 'phase ==', phasezi,phasewi)
        TPD_typ = stability_typ(cPress, cTemp,composition, phasezi ,phasewi, Zi, typ)
        # return TPD_typ
        # print("typ=  " ,  typ,'============', "TPD=  " ,    TPD_typ)
        TPDr.append(TPD_typ)
        Min_TPDr = min(TPDr)
        if Min_TPDr <= -1.0e-6:
            # print(Min_TPDr,"<=====>   type=   ", typ)
            return Min_TPDr

    for i in range(nc):
        TPD_test = stability_test(cPress, cTemp,composition, phasezi,phasewi, Zi,i)
        TPDi.append(TPD_test)
        Min_TPDi = min(TPDi)
        # print('======================================================================================')
        # print('Method : Ki{test[0.9]~[0.1]}', '<-->', 'trial component ==', i, '<==============>', Min_TPDi)
        Min_TPD = min(Min_TPDi, Min_TPDr)

        if Min_TPDi <=  -1.0e-6 :
            print(TPD_test, "<===+++++++++++++++++++++++++++++++++++++++==>   i=   ", i)
            return Min_TPD



        else:
            if i >= nc - 1:
                return Min_TPD
                print(TPD_test ,"<===>   i=   ", i)
            # return Min_TPD

#

#  ============ K Wilson --------------------------
def Kwil(pressure, temp, composition):
    # Kwil=pressure/temp
    Kwil=np.zeros((len(composition), 1))
    for i in range(0, len(composition)):
        Kwil[i,0]= (composition[i]['Pc']/pressure)* np.exp(5.373*(1+ composition[i]['w'])*(1-(composition[i]['Tc']/temp)))
    return Kwil

# def KSRK(pressure, temp, composition):
#     # Kwil=pressure/temp
#     KSRK=np.zeros((len(composition), 1))
#     for i in range(0, len(composition)):
#         Kwil[i,0]= (composition[i]['Pc']/pressure)* np.exp(5.373*( 1.0 + composition[i]['w'])*( 1.0 -(composition[i]['Tc']/temp)))
#     return Kwil


# print(Kwil(pressure, temp, composition))






#---===========    Algorithm: SSI–Newton      ==================---------------------------------------------------


#======= Stability ==============================================
def stability_typ(pressure, temp,composition, phasezi,phasewi, Zi,typ):
        # from fugacity import fug

        #-----====== loop ======--------------------------------
        Wi = Zi
        nWi = Zi
        oWi = Zi
        minKi = 1.0e3
        iter = 0
        diff = 0.01
        i=0
        eps = 1.0e-6
        LnZi = np.log(Zi)
        # Lnphi-Zi is the coeficient of fugacity look at deep learning paper pg 20
        LnPhi_Zi = fug(pressure, temp,composition, Zi, phasezi)
        di_Zi = LnZi + LnPhi_Zi
        KiWil = Kwil(pressure, temp, composition)  # Wilson
        #==== test ========================================================
        if (typ == 1):
            Ki=KiWil
        elif(typ == 2):
            Ki = 1/KiWil
        elif (typ == 3):
            Ki = np.cbrt(KiWil)
            # Ki = np.power(KiWil,0.333)
        else:
            Ki = 1 / (np.cbrt(KiWil))

        if phasewi == ["vapour"]:
            Wi = Ki * Zi
        else:
            Wi = Zi / Ki
        diff = 0.00001
        while diff > eps and iter < 1000:
            LnPhi_Wi = fug(pressure, temp,composition, Wi, phasewi)
            # print(LnPhi_Wi[0])
            if LnPhi_Wi[0] == [0]:
                TPDt=1
                return TPDt
            nWi=np.exp(di_Zi-LnPhi_Wi)    # Firooz Appendix A - 4.1
            Max_diff =max(abs(nWi-Wi))
            if Max_diff < diff:
                diff = Max_diff
            oWi=Wi
            LnoWi = np.log(oWi)
            Wi=nWi
            TPDp1 = np.sum(oWi * [(LnoWi + LnPhi_Wi)- di_Zi])
            iter +=1
            sumWi = sum(Wi)
        TPDt = -np.log(sumWi)
        return  TPDt


####3#######  Stability test ===================================================
# GENERAL STRATEGY FOR STABILITY TESTING AND PHASE-SPLIT CALCULATION IN TWO AND THREE PHASES

def stability_test(pressure, temp,composition, phasezi,phasewi, Zi,i):

        #-----====== loop ======--------------------------------
        Wi = Zi
        nWi = Zi
        oWi = Zi
        minKi = 1.0e10
        iter = 0
        diff = 1.0
        eps = 1.0e-6
        LnZi = np.log(Zi)
        LnPhi_Zi = fug(pressure, temp,composition, Zi, phasezi)
        di_Zi = LnZi + LnPhi_Zi
        KiWil = Kwil(cPress, cTemp, composition)  # Wilson
        #==== test =======================
        Ki = np.zeros((nc, 1))
        for j in range(nc):
            if i == j:
                Ki[j] = 0.9 / Zi[j]
                # Ki[j] = 1.0
            else:
                Ki[j] = (0.1 / (nc - 1)) / Zi[j]
                # Ki[j] = 1.0e-3
        # print(i,Ki)
        if phasewi == ["vapour"]:
            Wi = Ki * Zi
        else:
            Wi = Zi / Ki
        diff = 1.0
        while diff > eps and iter < 1000:
            LnPhi_Wi = fug(pressure, temp,composition, Wi, phasewi)
            if LnPhi_Wi[0] == [0]:
                TPDi=1
                return TPDi

            nWi=np.exp(di_Zi-LnPhi_Wi)    # Firooz Appendix A - 4.1
            Max_diff = max(abs(nWi - Wi))
            if Max_diff < diff:
                diff = Max_diff

            oWi=Wi
            LnoWi = np.log(oWi)
            Wi=nWi
            TPDp1 = np.sum(oWi * [(LnoWi + LnPhi_Wi)- di_Zi])
            iter +=1
        sumWi = sum(Wi)
        TPDi = -np.log(sumWi)
        return TPDi




# Set the filename for the CSV file
filename = 'results.csv'

# Check if the file already exists
if os.path.isfile(filename):

    # If the file exists, prompt the user to choose whether to overwrite it or skip writing to it
    choice = input("The file already exists. Do you want to REMOVE it? (y/n)")

    if choice.lower() == 'y':
        # If the user chooses to remove the file
        os.remove(filename)
    else:
        # If the user chooses not to overwrite the file, exit the program
        exit()
else:
    # If the file doesn't exist, open it in append mode
    mode = 'a'


#==== loop ===================================================
# TPDr = []

# inputs for 14 comp ==========================================
# [ 0 : 600 ] F = [ 255 , 588 ] K = [250 , 600]
# [ 0 : 4500 ] psia = [ 0 , 31.02 ] mPa = [1 , 31]
#
#




# temp = Temp0 = 100
# cTemp = 100
# Temp1 = 600
# pressure = Press0 = 0.01e+6
# cPress = 0.01e+6
# Press1 = 31.0e+6


# # inputs for 14 comp ==========================================
# temp = Temp0 = 300
# cTemp = 300
# Temp1 = 800
# pressure = Press0 = 1.0e+6
# cPress = 1.0e+6
# Press1 = 180.0e+6

# # inputs for 21 comp ==========================================
temp = Temp0 = 100
cTemp = 100
Temp1 = 850
pressure = Press0 = 0.1e+6
cPress = 0.1e+6
Press1 = 33.1e+6



nT=15
nP=11
dT = (Temp1-Temp0) / nT
dP=(Press1-Press0)/ nP
sign=np.ones((nP,nT))

i,j = 0,0
while (i < nP and cPress<Press1):
    j=0
    while (j < nT and cTemp<Temp1) :
        # TPD00 = TPD_minimum(cPress, cTemp,composition, ["liquid1"] ,["liquid1"], Zi)
        # TPD01 = TPD_minimum(cPress, cTemp,composition, ["liquid1"],["vapour"], Zi)
        # TPD11 = TPD_minimum(cPress, cTemp,composition, ["vapour"],["vapour"], Zi)
        TPD10 = TPD_minimum(cPress, cTemp,composition, ["vapour"],["liquid1"], Zi)
        Min=TPD10
        # Min = min(TPD00, TPD01, TPD11, TPD10)
        # TPD11 = TPD_minimum(cPress, cTemp, composition, ["vapour"], ["vapour"], Zi)
        # TPD10 = TPD_minimum(cPress, cTemp, composition, ["vapour"], ["liquid1"], Zi)
        # Min = min(TPD00, TPD01)
        # print(cTemp, '<==>', cPress, '<----->', TPD00, '<----->', TPD01,'<----->', TPD11,'<----->', TPD10)
        if Min >= -1.0e-6:
            S =  1
            print(cPress, "======", cTemp, "---------", "x")
        else:
            S=  0
            print(cPress, "======", cTemp, "---------", "-")
        # sign.append(S)
        sign[i][j]=S

        j+=1

        cTemp = Temp0 + j * dT
    # print(sign[i],'======', i)
# Print the results in csv form==================================================

    # Open a new CSV file in write mode
    with open('results.csv', mode='a', newline='') as file:

        # Create a CSV writer object
        writer = csv.writer(file)

        # Write each row of data to the CSV file

        writer.writerow(sign[i])

    i+=1
    cTemp = Temp0
    cPress = Press0 + i * dP
print(sign)




# Time consuming
T2 = (time.time() - t2)/60
print(T2)









