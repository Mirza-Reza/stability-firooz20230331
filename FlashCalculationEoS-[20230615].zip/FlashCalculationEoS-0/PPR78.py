import numpy as np
import math
import matplotlib.pyplot as plt
import scipy.optimize
from scipy.optimize import fsolve


def EoS(pressure, temp, composition):

    R = np.float64(8.314472);  # Ideal gas constant [J.mol^{-1}.K^{-1}]  MPa.cm^3/mol.K
    T = np.float64(temp);  # Temperature [K]
    P = np.float64(pressure);  # Pressure [Pa]
    aiVal = np.zeros((len(composition), 1))
    biVal = np.zeros((len(composition), 1))
    miVal = np.zeros((len(composition), 1))

    bi = np.zeros(len(composition))


    for i in range(len(composition)):
        biVal[i, 0] = 0.0777960739 * R * composition[i]['Tc'] / composition[i]['Pc']
        bi[i] = np.array([0.0777960739 * R * composition[i]['Tc'] / composition[i]['Pc']])
        if composition[i]['w'] <= 0.491:
            miVal[i, 0] = 0.37464 + 1.5422 * composition[i]['w'] - 0.26992 * pow(composition[i]['w'], 2)
        else:
            miVal[i, 0] = 0.379642 + 1.48503 * composition[i]['w'] - 0.164423 * pow(composition[i]['w'],
                                                                                 2) + 0.016666 * pow(
                composition[i]['w'], 3)
        aiVal[i, 0] = 0.457235529 * (pow(R, 2) * pow(composition[i]['Tc'], 2) / composition[i]['Pc']) * (
            pow(1 + miVal[i, 0] * (1 - pow(T / composition[i]['Tc'], 0.5)), 2))

    return aiVal, biVal

        #========================new constants =========================================================

    # for i in range(len(composition)):
    #     ai[i] = 0.42748 * (pow(R, 2) * pow(composition[i]['Tc'], 2) / composition[i]['Pc'])
    #     mi[i] = 0.480 + 1.574 * composition[i]['w'] - 0.176 * pow(composition[i]['w'], 2)
    #     alphai[i] =pow(1 + mi[i] * (1 - pow(T / composition[i]['Tc'], 0.5)), 2)
    #     bi[i] = 0.08664 * R * composition[i]['Tc'] / composition[i]['Pc']
    # return ai, bi, alphai
