import numpy as np
import math
import matplotlib.pyplot as plt
from scipy.optimize import fsolve


def thetaFunc(zi, nph, Ki, beta):
    # from FlashCalc import zi
    # from FlashCalc import nph
    # from FlashCalc import Ki
    # from FlashCalc import beta
    # from FlashCalc import Krm

    Krmm = np.zeros((len(zi), nph - 1));  # Reference equilibrium factors column vector
    for i in range(nph - 1):
        Krmm[:, i] = Ki[:, 0]


    thetaVal = np.log(np.dot((zi / (np.vstack(Ki[:, 0]) + np.dot(np.vstack(Ki[:, 1:nph]) - Krmm,
                                                                 np.array(beta[0, 1:nph]).reshape(-1, 1)))).flatten(),
                             np.vstack(Ki[:, 0])) / np.dot((zi / (
            np.vstack(Ki[:, 0]) + np.dot(np.vstack(Ki[:, 1:nph] - Krmm),
                                         np.array(beta[0, 1:nph]).reshape(-1, 1)))).flatten(),
                                                           np.vstack(Ki[:, 1:nph])))


    return thetaVal
