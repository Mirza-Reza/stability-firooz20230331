import numpy as np
import pandas as pd
import math
import matplotlib.pyplot as plt
import scipy.optimize
from scipy.optimize import fsolve

import csv


def mixRules(pressure, temp, composition, ai, bi,fixedKij=[]):
    R = np.float64(8.314472);  # Ideal gas constant [J.mol^{-1}.K^{-1}]  MPa.cm^3/mol.K
    T = np.float64(temp);  # Temperature [K]
    P = np.float64(pressure);  # Pressure [Pa]

    aijVal = np.zeros((len(composition), len(composition)))
    bijVal = np.zeros((len(composition), len(composition)))

    # ============Kij==========================
    # comp = np.array(pd.read_csv('4CompMixture.csv', sep=';'))
    # comp1 = np.array(composition[])

    groups = np.array(pd.read_csv(r'MoleculeGroups.csv', sep=';'))
    Bkl = np.array(pd.read_csv(r'Bkl.csv', sep=';'))
    Akl = np.array(pd.read_csv(r'Akl.csv', sep=';'))

    nc = len(composition)  # Components number of the composition
    ng = len(groups[0]) - 3  # Decomposition group numbers defined to the Group Composition Method (GCM) analyze


    alpha = np.zeros((nc, ng))
    for index0, var0 in enumerate(composition[0:nc]):
        for index in range(len(groups)):
            if composition[index0]['name'] == groups[index, 1]:
                for index1, var in enumerate(groups[index, 2:ng + 2]):
                    alpha[index0, index1] = groups[index, index1 + 2] / groups[index, ng + 2]

    DS = np.zeros((nc, nc))
    DS0 = np.zeros((len(alpha), len(alpha[0])))
    # print(len(alpha), 'x', len(alpha[0]))
    for i in range(nc):
        for j in range(nc):  # range(len(alpha)):
            if i == j:
                DS[i, j] = 0
            else:
                for k in range(len(alpha[0])):  # enumerate(alpha[ind0, 0:len(alpha[0])]):
                    # print(ind, ',   ', DS[ind, :])
                    for l, val1 in enumerate(alpha[j, 0:len(alpha[0])]):
                        if k == l or (Bkl[k, l + 1] == Akl[k, l + 1]):
                            # alpha[ind0, ind] = 123
                            DS[i, j] += 0
                            # DS[ind, ind1] = 0
                        else:
                            DS[i, j] += -0.5 * ((alpha[i, k] - alpha[j, k]) * \
                                                (((alpha[i, l]) - (alpha[j, l])) * (
                                                        (Akl[k, l + 1]) * math.pow(298.15 / T, (
                                                        Bkl[k, l + 1] / Akl[k, l + 1]) - 1))))


    Kij = np.zeros((nc, nc))
    for i in range(nc):
        for j in range(nc):
            if i == j:
                Kij[i, j] = 0.0
            else:
                Kij[i, j] = ((DS[i, j] - (pow(((pow(ai[i], 0.5) / bi[i]) - (pow(ai[j], 0.5) / bi[j])), 2))) / \
                             (2 * (pow(ai[i] * ai[j], 0.5)) / (bi[i] * bi[j])))
    np.savetxt('outputt.csv', Kij[:, :], delimiter=',', fmt='%f')
    #================================================================================
    Kij = np.array([[0, -0.02, 0.12, 0.12, 0.12, 0.12, 0.12, 0.12, 0.12, 0.12, 0.12, 0.12, 0.12, 0.12],
                  [- 0.02, 0, 0.093, 0.128, 0.123, 0.136, 0.125, 0.131, 0.12, 0.12, 0.12, 0.12, 0.12, 0.12],
                  [0.12, 0.093, 0, 0, 0, 0.02, 0.02, 0.025, 0.025, 0.035, 0.038, 0.038, 0.038, 0.038],
                  [0.12, 0.128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                  [0.12, 0.123, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                  [0.12, 0.136, 0.02, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                  [0.12, 0.125, 0.02, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                  [0.12, 0.131, 0.025, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                  [0.12, 0.12, 0.025, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                  [0.12, 0.12, 0.035, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                  [0.12, 0.12, 0.038, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                  [0.12, 0.12, 0.038, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                  [0.12, 0.12, 0.038, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                  [0.12, 0.12, 0.038, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]])
    # print(k)
    # =====Adjustment settings##################################################
    # print(Kij)
    # print(Kij[:, :])
    # np.savetxt('output.csv', kij[:,j], delimiter=',')
# break



    # if (len(fixedKij)!=0):
    #     Kij[20, :] = Kij[:, 20] = fixedKij[0]
        # Kij[20, 17] = Kij[17, 20] = fixedKij[0]
        # print(fixedKij)

    # print(Kij[i, j])
    # print(Kij[20, :])

    # print(kGlobal)
    # Kij[20, :]=kGlobal

    # Kij[20, :]=Kij[:, 20]=0.102
    # Kij[20, 20] = 0.07
    # Kij[20, 17] = Kij[17, 20] = 0.117
    # if ZCO2 < 0.6:
    #     Kij[20, 17] = Kij[17, 20] = -0.9
    # elif ZCO2<0.8 :
    #     Kij[20, 17] = Kij[17, 20] = -0.09
    # else:
    #     Kij[20, 17] = Kij[17, 20] = -0.05

    # ================end Kij=================================
    # aijVal = np.zeros((nc, nc))
    # lijValOld= np.array([[0., 0.],
    #                 [0., 0.]]);
    lijVal=np.zeros((nc, nc))
    j=0
    for i in range(len(composition)):
        #bij[i] = bi[i]
        for j in range(len(composition)):
            aijVal[i, j] = (pow(ai[i] * ai[j], 0.5)) * (1 - Kij[i, j])
            bijVal[i, j] = (1 - lijVal[i, j]) * (bi[i] + bi[j]) / 2
        j = 0
    sig = np.zeros((1, len(composition)))
    for i in range(len(composition)):
        for j in range(len(composition)):
            sig[0, i] = composition[i]['z'] * aijVal[i, j]
    return aijVal, bijVal , sig