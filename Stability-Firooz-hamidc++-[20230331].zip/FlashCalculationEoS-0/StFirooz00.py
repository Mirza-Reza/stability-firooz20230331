import numpy as np
from PPR78 import EoS
import math
import matplotlib.pyplot as plt
import scipy.optimize
from scipy.optimize import fsolve
import numpy as np
import pandas as pd
import math
import matplotlib.pyplot as plt
import scipy.optimize
from scipy.optimize import fsolve
import copy
import csv
import math

#See discussions, stats, and author profiles for this publication at: https://www.researchgate.net/publication/227541887
#based on Firoozabadi paper





def fug(pressure, temp, xi, phase, bi, aij, bij, composition):

    R = np.float64(8.314472);  # Ideal gas constant [J.mol^{-1}.K^{-1}]  MPa.cm^3/mol.K
    T = np.float64(temp);  # Temperature [K]
    P = np.float64(pressure);  # Pressure [Pa]
    nc = len(composition)  # Components number of the composition


    # =================Compressibility factor roots & Fugacity Coefficients of the cubic EoS====================================
    # ======Parameters ami and bmi are still part of mixing rules calculus===============
    ami =np.array([sum(aij.dot(xi) * xi)])
    bmi =np.array([sum(bij.dot(xi) * xi)]) #sum(bij.dot(xi))
    # ======end of Parameters ami and bmi are still part of mixing rules calculus===============

    A = (ami * P) / (pow(R * T, 2))
    B = bmi * P / (R * T)


    #============END of ONLY FOR PLOTTING===============================

    rootSol = np.roots([1,B - 1, A - 2 * B - 3 * B*B,B*B + B*B*B- (A * B)])
    roots = np.real(rootSol[np.isreal(rootSol)])
    # print(rootSol)
    # print(roots)

    if phase == ["liquid1"]  or phase == ["liquid2"] : # phases[0]:
        Zt = min(roots);
        # Zt = max(roots);
        v = (Zt * R * T) / P;
    elif phase == ["vapour"]: #phases[2]:
        Zt = max(roots);
        # Zt = min(roots);
        v = (Zt * R * T) / P;
    else:
        print("the value is not correct")
    bmii = np.array(bi / bmi);
    Z = Zt;

    fugVal= np.exp(
        (bmii * (Z * np.ones((nc, 1)) - np.ones((nc, 1)))) - np.log(Z * np.ones((nc, 1)) - B * np.ones((nc, 1))) - (
                    A / (2 * np.sqrt(2) * B)) * ((2 * (np.dot(aij,xi).reshape(-1,1))) / ami - bmii) * np.log(
            (Z + 2.414 * B) / (Z - 0.414 * B)))
    # print(fugVal, '-----------------------------------')
    return fugVal


#--------- TPD ---------------------------------------------------
def TPD(composition,pressure, temp, phase, Zi, Wi, bi, aij, bij):
    from fugacity import fug
    phi_Zi = fug(pressure, temp, Zi, phase, bi, aij, bij, composition)
    phi_Wi = fug(pressure, temp, Wi, phase, bi, aij, bij, composition)
    LnPhi_Zi = np.log(phi_Zi)
    LnPhi_Wi = np.log(phi_Wi)
    Ln_Zi = np.log(Zi)
    Ln_Wi = np.log(Wi)
    di_Wi = (LnPhi_Wi + Ln_Wi)
    di_Zi =  LnPhi_Zi + Ln_Zi
    TPD = np.sum(Wi * [di_Wi - di_Zi])
    return TPD

#  ============ K Wilson --------------------------
def Kwil(pressure, temp, composition):
    # Kwil=pressure/temp
    Kwil=np.zeros((len(composition), 1))
    for i in range(0, len(composition)):
        Kwil[i,0]= (composition[i]['Pc']/pressure)* np.exp(5.373*(1+ composition[i]['w'])*(1-(composition[i]['Tc']/temp)))
    return Kwil

# print(Kwil(pressure, temp, composition))


#=========================  2  =========================================
composition = [{'name': 'CH4', 'z': 0.7, 'Tc': 489.21, 'Pc': 3102000, 'w': 0.2251},
               {'name': 'C6H14', 'z': 0.3, 'Tc': 370.01, 'Pc': 4260000, 'w': 0.152}]
nc = len(composition)


#========================= 14  =========================================
# composition = [{'name': 'N2', 'z': 0.0417, 'Tc': 126.2, 'Pc': 3.35e6, 'w': 0.040},
#                {'name': 'CO2', 'z': 0.0366, 'Tc': 304.2, 'Pc': 7.28e6, 'w': 0.225},
#                {'name': 'C1', 'z': 0.0217, 'Tc': 190.6, 'Pc': 4.54e6, 'w': 0.008},
#                {'name': 'C2', 'z': 0.0176, 'Tc': 305.4, 'Pc': 4.82e6, 'w': 0.098},
#                {'name': 'C3', 'z': 0.0105, 'Tc': 369.8, 'Pc': 4.19e6, 'w': 0.152},
#                {'name': 'iC4', 'z': 0.0159, 'Tc': 408.1, 'Pc': 3.6e6, 'w': 0.176},
#                {'name': 'nC4', 'z': 0.0233, 'Tc': 425.2, 'Pc': 3.75e6, 'w': 0.193},
#                {'name': 'iC5', 'z': 0.0133, 'Tc': 460.4, 'Pc': 3.34e6, 'w': 0.227},
#                {'name': 'nC5', 'z': 0.0044, 'Tc': 469.6, 'Pc': 3.33e6, 'w': 0.251},
#                {'name': 'C6-C9', 'z': 0.0223, 'Tc': 547.43, 'Pc': 3.03e6, 'w': 0.4099},
#                {'name': 'C10-C14', 'z': 0.0109, 'Tc': 643.77, 'Pc': 2.29e6, 'w': 0.6714},
#                {'name': 'C15-C19', 'z': 0.0046, 'Tc': 724.23, 'Pc': 1.7e6, 'w': 0.9296},
#                {'name': 'C20-C24', 'z': 0.0147, 'Tc': 777.38, 'Pc': 1.34e6, 'w': 1.1603},
#                {'name': 'C25+', 'z': 0.0128, 'Tc': 849.61, 'Pc': 0.99e6, 'w': 1.6043}]
# nc = len(composition)

#=== inputs ===============================================
mainComposition = copy.deepcopy(composition)
pressure = 10.0e6
phase = ["vapour"]
# phase = ["liquid1"]
temp = 500

###### kij +++++++++++++++++++++++++++++++++++++++++++++++
# in the case of 2 component kij considered 0
k = [ [ 0 for i in range(nc) ] for j in range(nc) ]
for i in range(nc):
    for j in range(nc):
        k[i][j]=0
print(k)
# -------------------------------------------------------



#===========================================================
########### ai bi ###################################
from PPR78 import EoS
ai, bi = EoS(pressure, temp, composition)

# =================aij  bij ================================================================================
from mixingRules import mixRules
aij, bij = mixRules(pressure, temp, composition, ai, bi)


#---===========    Algorithm: SSI–Newton      ==================---------------------------------------------------

from fugacity import fug

# 1. Initialize the K-values from Wilson’s correlation
#=======  ki-Wilson  ================================================


# 2. For given zi, calculate di(z) from Eq. 3.
#===== diZ ==========================================

# extract zi from composition
Zi = np.zeros((1, nc)).transpose()
for comp in range(0, nc):
    Zi[comp, 0] = np.array([[composition[comp]['z']]])
# print(zi)

LnZi = np.log(Zi)
Phi_Zi = fug(pressure, temp, Zi, phase, bi, aij, bij, composition)
LnPhi_Zi = np.log(Phi_Zi)
di_Zi = LnZi + LnPhi_Zi
print(di_Zi)



#======= Stability ==============================================
def stability(composition,pressure, temp, phase, Zi, bi, aij, bij,typ):
    # from fugacity import fug

    #-----====== loop ======--------------------------------
    Wi = Zi
    nWi = Zi
    oWi = Zi
    minKi = 1.0e10
    iter = 0
    diff = 1.0
    i=0
    # typ=5
    eps = 1.0e-12
    LnZi = np.log(Zi)
    Phi_Zi = fug(pressure, temp, Zi, phase, bi, aij, bij, composition)
    LnPhi_Zi = np.log(Phi_Zi)
    di_Zi = LnZi + LnPhi_Zi
    KiWil = Kwil(pressure, temp, composition)  # Wilson
    #==== test ========================================================
    if (typ == 1):
        Ki=KiWil
    elif(typ == 2):
        Ki = 1/KiWil
    elif (typ == 3):
        Ki = np.cbrt(KiWil)
    else:
        Ki = 1 / (np.cbrt(KiWil))

    if phase == ["liquid1"]:
        Wi = Ki * Zi
    else:
        Wi = Zi / Ki
    while diff > eps and iter < 1000:
        diff=0
        Phi_Wi = fug(pressure, temp, Wi, phase, bi, aij, bij, composition)
        # LnWi = np.log(Wi)
        LnPhi_Wi = np.log(Phi_Wi)
        # di_Wi = (LnPhi_Wi + LnWi)
        # TPDp1 = np.sum(oWi * [di_Wi - di_Zi])

        nWi=np.exp(di_Zi-LnPhi_Wi)    # Firooz Appendix A - 4.1
        Max_diff =max(abs(nWi-Wi))
        if Max_diff >= diff:
            diff= Max_diff
        else:
            diff=diff
        oWi=Wi
        LnoWi = np.log(oWi)
        Wi=nWi
        LnPhi_nWi = np.log(Phi_Wi)

        TPDp1 = np.sum(oWi * [(LnoWi + LnPhi_nWi)- di_Zi])

        # TPDp1 = TPD(composition,pressure, temp, phase, Zi, Wi, bi, aij, bij)
        TPDp2=sum(Wi)
        yi=-np.log(Wi)
        TPDt = TPD(composition,pressure,temp,phase,Zi,yi,bi,aij,bij)
        # print('===================================================================================================')
        print( 'TPD =',TPDt,   '======','Iter =', iter,'<==========>' ,  'sum(Yi) =', TPDp2, '----', 'diff==', diff)
        iter +=1


####3#######  Stability test ===================================================
# GENERAL STRATEGY FOR STABILITY TESTING AND PHASE-SPLIT CALCULATION IN TWO AND THREE PHASES

def stability_test(composition,pressure, temp, phase, Zi, bi, aij, bij,i):
    # from fugacity import fug

    #-----====== loop ======--------------------------------
    Wi = Zi
    nWi = Zi
    oWi = Zi
    minKi = 1.0e10
    iter = 0
    diff = 1.0
    # i=0
    typ=1
    eps = 1.0e-8
    LnZi = np.log(Zi)
    Phi_Zi = fug(pressure, temp, Zi, phase, bi, aij, bij, composition)
    LnPhi_Zi = np.log(Phi_Zi)
    di_Zi = LnZi + LnPhi_Zi
    KiWil = Kwil(pressure, temp, composition)  # Wilson
    #==== test =======================
    Ki = np.zeros((nc, 1))
    for j in range(nc):
        if i == j:
            Ki[j] = 0.9 / Zi[j]
        else:
            Ki[j] = (0.1 / (nc - 1)) / Zi[j]
    # print(i,Ki)
    if phase == ["liquid1"]:
        Wi = Ki * Zi
    else:
        Wi = Zi / Ki
    while diff > eps and iter < 1000:
        diff=0
        Phi_Wi = fug(pressure, temp, Wi, phase, bi, aij, bij, composition)
        # LnWi = np.log(Wi)
        LnPhi_Wi = np.log(Phi_Wi)
        # di_Wi = (LnPhi_Wi + LnWi)
        # TPDp1 = np.sum(oWi * [di_Wi - di_Zi])

        nWi=np.exp(di_Zi-LnPhi_Wi)    # Firooz Appendix A - 4.1
        Max_diff =max(abs(nWi-Wi))
        if Max_diff >= diff:
            diff= Max_diff
        else:
            diff=diff
        oWi=Wi
        LnoWi = np.log(oWi)
        Wi=nWi
        LnPhi_nWi = np.log(Phi_Wi)

        TPDp1 = np.sum(oWi * [(LnoWi + LnPhi_nWi)- di_Zi])

        # TPDp1 = TPD(composition,pressure, temp, phase, Zi, Wi, bi, aij, bij)
        TPDp2=sum(Wi)
        yi=-np.log(Wi)
        TPDt = TPD(composition,pressure,temp,phase,Zi,yi,bi,aij,bij)
        print(i ,'<->', 'TPD =',TPDt,   '======','Iter =', iter,'<==========>' ,  'sum(Yi) =', TPDp2, '----', 'diff==', diff)
        iter +=1

phases=[["vapour"], ["liquid1"]]
for phase in phases:
    print('            ======================',     phase    , '=================')
    Types=[1,2,3,4]
    typ=0
    for typ in Types:
        print('===================================================================================================')
        print('type ==', typ,'<==============>' ,'phase ==', phase)
        TPD01 = stability(composition,pressure, temp, phase, Zi, bi, aij, bij,typ)


    for i in range(nc):
        print('===================================================================================================')
        print('Method : Ki{test[0.9]~[0.1]}','<-->' ,'trial component ==', i, '<==============>', 'phase ==', phase)
        TPD02 = stability_test(composition,pressure, temp, phase, Zi, bi, aij, bij,i)
        i+=1
# def TPD (composition,pressure, temp, phase, zi, xi, bi, aij, bij):
#     TPD00=stability(composition,pressure, temp, zi, phase ,bi, aij, bij)
#     if TPD00 > 0.0:
#         TPD01=stability(composition,pressure, temp, zi, phase ,bi, aij, bij)
#         if TPD01 > 0.0:
#             minTPD=min(TPD00,TPD01)
#             TPD=stability(composition,pressure, temp, zi, phase ,bi, aij, bij)
#             minTPD=min(minTPD, TPD)
#             return minTPD
#         else:
#             return min(TPD00, TPD01)
#     else:
#         return TPD00


























