import numpy as np
from PPR78 import EoS
from mixingRules import mixRules
from fugacity import fug
from fugacityCriteria import fugC
from rachfordRiceEq import rrm
from theta import thetaFunc
import math
import scipy.optimize
import copy

from sympy import symbols, Eq, solve

def solveEOS(temp,pressure,composition,xo,beta0,phases0,ZCO2):

    phases = copy.deepcopy(phases0) #[['liquid1'], ['liquid2'], ['vapour']]

    nc = len(composition)  # Components number of the composition
    nph = len(phases)  # phases number
    nUph = nph

    zi = np.zeros((1, nc)).transpose()
    for comp in range(0, nc):
        zi[comp, 0] = np.array([[composition[comp]['z']]])

    betaInitVal = copy.deepcopy(beta0) #  # Initial guess of the phase fraction -beta-  [liquid, vapour]


    # betaInitVal = np.array([[0.0001, 0.4600, 0.5399]])  # Initial guess of the phase fraction -beta-  [liquid, vapour]
    betaVal = betaInitVal[0, 1:nUph]

    theta = np.zeros((1, nph))  # stability function

    # =======================END of Component properties composition & input variables=============================

    # =================Global constants setting of the EoS model ==================================================
    # from PPR78 import EoS

    ai, bi = EoS(pressure, temp, composition)
    # print("ai=", ai)
    # print("bi=", bi)
    # =================END of Global constants setting of the EoS model ============================================

    # =================Mixing rules ================================================================================
    # from mixingRules import mixRules

    aij, bij = mixRules(pressure, temp, composition, ai, bi, ZCO2)

    # print("aij=", aij)
    # print("bij=", bij)
    # =================END of Mixing rules ===========================================================================
    # nUph = nph
    tolf = 1e-6
    tol = 1
    iter = 0
    iterMax = 50000
    # xoGuess=xo
    # xrro = xo.copy()
    # #
    # tol2OLD = 0.0
    # #
    while tol > tolf and iter < iterMax:


        xro = copy.deepcopy(xo)

        # =================================Fugacity coeficients (phi) loop for every phase=====================================

        phi = np.zeros((nc, nph))
        v = np.zeros((1, nph))
        for i in range(nph):
            xi = xo[:, i]
            if iter < iterMax:
                phi[:, i] = np.array(
                    fug(pressure, temp, xi, phases[i], bi, aij, bij, composition)).transpose()
            else:
                phi[:, i] = np.array(fugC(pressure, temp, xi, phases[i], bi, aij, bij, composition)).transpose()
                # print("phase:", nPhase=fugC(pressure, temp, xi, phases[i], bi, aij, bij, composition) )
            # print("phi=", phi)

        # =================================END of Fugacity coeficients (phi) loop for every phase================================

        # ==================Equilibrium factors Ki & Rachford-Rice equation===================================
        Ki = np.zeros((nc, nUph));  # Equilibrium factors
        Xm = np.zeros((nc, nUph));  # Ones´ matrix to define the maximum values of the xi composition by row


        Xm = xo[:, 0: nUph] == np.max(xo[:, 0: nUph], axis=1).reshape(-1, 1)
        phir = np.max(phi[:, 0:nUph] * Xm, axis=1).reshape(-1, 1)  # Reference fugacity coefficients column vector for each component

        Ki = phir / phi
        # print(phir)

        betaFuncAux = scipy.optimize.root(rrm, betaVal, args=(zi, Ki, nUph), method='lm')
        betaFunc = betaFuncAux.x  # * 0.01 + betaVal * 0.99
        #print("result", betaFunc, rrm(betaFunc, zi, Ki, nUph))


        # =======================================================================================
        beta = np.zeros((1, nph))
        # nph
        for i in range(1, nUph):  # enumerate(comp[0:nc]):
            if betaFunc[i - 1] < 0:
                    beta[0, i] = 0
            else:
                beta[0, i] = betaFunc[i - 1]
                # beta[i-1] = 1 - beta[i]
        beta[0, 0] = 1 - sum(beta[0, 1:nph])
        if beta[0, 0] < 0:
            beta[0, 0] = 0

        # ==============GUARANTED THE SYSTEM HAS AT LEAST TWO EQUILIBRIUM PHASES===============
        zeroPosBeta = np.where(beta[0, 0:nUph] == 0)[0]
        nbZero = len(zeroPosBeta)
        # print(zeroPosBeta)
        if nbZero > 1:
            nbZero = nbZero - 1  # To guarantted two phases when all Betas are negatives
            zeroPosBeta = np.delete(zeroPosBeta, 0)
            # When there are two negative Beta values.  Convert other phases different to the reference one, into shodow phases
        for i in range(nbZero):
            if zeroPosBeta[0] == 0:
                indexCol = np.r_[1:nph, 0]
                xro = xro[:, indexCol]
                Ki = Ki[:, indexCol]
                beta = beta[:, indexCol]
                phases = [phases[i] for i in indexCol]
            else:
                indx = np.r_[0:zeroPosBeta]
                indxx = np.r_[zeroPosBeta + 1:nph]
                indxxx = np.r_[zeroPosBeta]
                indexColumn = np.concatenate((indx, indxx, indxxx))
                xro = xro[:, indexColumn]
                Ki = Ki[:, indexColumn]
                beta = beta[:, indexColumn]
                phases = [phases[i] for i in indexColumn]
        # ==============END of GUARANTED THE SYSTEM HAS AT LEAST TWO EQUILIBRIUM PHASES===============

        theta[0, 1:nph] = thetaFunc(zi, nph, Ki, beta)  # Eq. 3.77 Pag.43 Reinaldo´s Thesis
        #print("theta=", theta)

        if nUph == 2:
            if nbZero == 1:
                theta[0, 0] = 0
            else:
                theta[0, 0:nUph] = 0
        else:
            nUph = nUph - nbZero  # This conditions guaranteed at leat two phases for the flash calculation
            theta[0,
            0:nUph] = 0  # quando tenho mais de duas fazes posso levar variaveis antes consideradas no equilibrio para fases sombra

        nnz = nph - nUph
        if nnz > 0:
            for l in range(nUph, nph):
                if theta[0, l] < 0:
                    if nnz == 1:
                        nUph = nUph + 1
                        beta[0, l] = 1e-10
                    else:
                        i = np.r_[0:nUph + 1]
                        ii = np.r_[l]
                        iii = np.r_[nUph + 1:nph]
                        indexC = np.concatenate((i, ii, iii))
                        xro = xro[:, indexC]
                        xro = np.delete(xro, l, 1)
                        Ki = Ki[:, indexC]
                        Ki = np.delete(Ki, l, 1)
                        beta[0, l] = 1e-10
                        beta = beta[:, indexC]
                        beta = np.delete(beta, l, 1)
                        # print(phases)
                        phases = [phases[i] for i in indexC]
                        phases = np.delete(phases, l, 0).tolist()
                        nUph = nUph + 1

        oBetaVal = betaVal.copy()
        oPhases = phases.copy()

        # ================Eliminaiting trivial solutions for mixtures with more than two phases=============
        npo = nph

        if nph > 2:
            for s in range(2, nph):  # np.r_[2:nph]:
                for ss in range(0, s):
                    alpha = sum(abs(xro[:, s] - xro[:, ss]))
                    # print("alpha=", alpha)
                    if alpha < 2e-4:
                        xro = np.delete(xro, s, 1)
                        xo = np.delete(xo, s, 1)
                        Ki = np.delete(Ki, s, 1)
                        beta = np.delete(beta, s, 1)
                        theta = np.delete(theta, s, 1)
                        phases = np.delete(phases, s).reshape(-1, 1)
                        phases = phases.tolist()
                        if s + 1 <= nUph:  # it is s+1 because of the third phase
                            nUph = nUph - 1
                        nph = nph - 1
                        break
                if npo != nph:
                    break

        # ================END of Eliminaiting trivial solutions for mixtures with more than two phases=============
        betaVal = beta[0, 1:nUph]
        diff2 = 0.0

        ##Updating molar composition Eq. 3.73 pag.42 Reinaldo´s Thesis
        Krm = np.zeros((len(zi), nph - 1))  # Reference equilibrium factors column vector
        for i in range(nph - 1):
            Krm[:, i] = Ki[:, 0]

        Xri = zi / (np.vstack(Ki[:, 0]) + np.dot((np.vstack(Ki[:, 1:nph]) - Krm),
                                                 np.array(beta[0, 1:nph]).reshape(-1, 1)))



        # TAKING INTO THE ACCOUNT THETA PARAMETER FOR THE STABILITY ANALYSYS
        for j in range(nph):
            xo[:, j] = np.array(Xri).flatten() * Ki[:, j] * math.exp(
                theta[0, j])  # Residual Function, Eq. 3.70 Pag. 41 Reinaldo´s Thesis
            # print("x_i=", xo)

            for i in range(nc):
                if xo[i, j] < 0:
                    xo[i, j] = 1e-10
            if j < nUph:
                xo[:, j] = xo[:, j] / sum(xo[:, j])

        delta = abs(xo - xro)
        tol = sum((sum(delta))) + diff2 * 100
        iter = iter + 1
        # print(beta)

        if tol <= tolf:
            if beta[0, 0] > 1:
                print("====>", beta)
                beta[0, 0] = 1

    if (beta[0,-1]==0 and len(beta[0])>2):
        print("XXXXX",len(beta[0]))
        beta = np.delete(beta,nUph,1)
        xo = np.delete(xo, nUph, 1)
        phases.pop()

    return iter,beta,xo,phases,tol
