"""
Predictive Peng Robinson 78 EoS  (PPR78) for mixtures
J.-N. Jaubert, F. Mutelet / Fluid Phase Equilibria 224 (2004) 285–304 (doi:10.1016/j.fluid.2004.06.059)
@author: Gustavo Oviedo
"""

import numpy as np
import copy
import pandas as pd
import matplotlib.pyplot as plt
# import functions
import csv
import math
import scipy.optimize
from scipy.optimize import fsolve, least_squares

from sympy import symbols, Eq, solve
import time
from PPR78 import EoS
from mixingRules import mixRules
from fugacity import fug
from fugacityCriteria import fugC
from rachfordRiceEq import rrm
from theta import thetaFunc
from solver import solveEOS
from carbon import addCarbon

import warnings
import random


warnings.filterwarnings("ignore",
                        category=np.VisibleDeprecationWarning)  # I need to check the reason.  =asanyarray(ary)

tic = time.perf_counter()
# ==================Component properties composition & input variables==========================================
# modelEoS= [{'PR78', 'PPR78', 'SRK', 'PC-SAFT', 'CPA'}]
tempMinVal = 298.15  # 189  # 155.60857142857      #Critical point 203.465 #203.468
tempMaxInVal = 298.15  # 189  # 155.60857142857    #Critical point203.465  #203.468
tempNumbSpaces = 1  # 150
tempVal = np.zeros([tempNumbSpaces])
DtempVal = (tempMaxInVal - tempMinVal) / tempNumbSpaces

pressMinVal = 7.1480e6 #9.8e6 7.5e6
pressMaxInVal = 7.1480e6 #9.8e6 7.5e6
pressNumbSpaces = 1
pressVal = np.zeros([pressNumbSpaces])
DpressVal = (pressMaxInVal - pressMinVal) / pressNumbSpaces

zCarbonDioxMinVal = 0.1659 #0.0659  # Minimum molar composition of carbon dioxide (CO2).
zCarbonDioxMaxVal = 0.1659 #0.0659 # Maximum molar composition of carbon dioxide (CO2).
zCarbonDioxNumbSpaces = 1
if zCarbonDioxNumbSpaces > 0:
    zCarbonDioxVal = np.zeros([zCarbonDioxNumbSpaces])
    DzCarbonDioxVal = (zCarbonDioxMaxVal - zCarbonDioxMinVal) / zCarbonDioxNumbSpaces
else:
    zCarbonDioxVal = []

betaPrint = []
xoPrint = []
p = 0
#====================live oil-x2  ==================================
# composition = [{'name': '2,2-dimethylbutane', 'z': 0.0715, 'Tc': 489.21, 'Pc': 3102000, 'w': 0.2251},
#                {'name': 'n-heptane', 'z': 0.0628, 'Tc': 540.3, 'Pc': 2734000, 'w': 0.3481},
#                {'name': 'ethylcyclohexane', 'z': 0.0373, 'Tc': 606.9, 'Pc': 3250000, 'w': 0.318},
#                {'name': 'n-nonane', 'z': 0.0302, 'Tc': 594.7, 'Pc': 2280000, 'w': 0.4409},
#                {'name': 'propylcyclohexane', 'z': 0.0181, 'Tc': 630.8, 'Pc': 2860000, 'w': 0.3149},
#                {'name': '1,2,3,4-tetrahydronaphthalene', 'z': 0.0272, 'Tc': 719.5, 'Pc': 3630000, 'w': 0.3318},
#                {'name': '1,3,5-triethylbenzene', 'z': 0.04, 'Tc': 679, 'Pc': 2330000, 'w': 0.507},
#                {'name': '1-phenylhexane', 'z': 0.0227, 'Tc': 695, 'Pc': 2350000, 'w': 0.4498},
#                {'name': 'n-tridecane', 'z': 0.0076, 'Tc': 676, 'Pc': 1679000, 'w': 0.6099},
#                {'name': '1-phenyloctane', 'z': 0.0383, 'Tc': 725, 'Pc': 1980000, 'w': 0.5845},
#                {'name': 'n-pentadecane', 'z': 0.0186, 'Tc': 707.5, 'Pc': 1479000, 'w': 0.7192},
#                {'name': 'n-hexadecane', 'z': 0.0079, 'Tc': 722.4, 'Pc': 1401000, 'w': 0.7442},
#                {'name': 'octadecane', 'z': 0.0252, 'Tc': 747.7, 'Pc': 1292000, 'w': 0.802},
#                {'name': 'nonadecane', 'z': 0.0219, 'Tc': 755.3, 'Pc': 1160000, 'w': 0.8722},
#                {'name': '1-phenylhexadecane', 'z': 0.0269, 'Tc': 827.35, 'Pc': 1279000, 'w': 0.9055},
#                {'name': 'tetracosane', 'z': 0.004, 'Tc': 799.8, 'Pc': 1075000, 'w': 1.184},
#                {'name': 'squalane', 'z': 0.1399, 'Tc': 820, 'Pc': 900000, 'w': 1.2436},
#                {'name': 'methane', 'z': 0.3252, 'Tc': 190.56, 'Pc': 4599000, 'w': 0.01},
#                {'name': 'ethane', 'z': 0.0504, 'Tc': 305.32, 'Pc': 4885000, 'w': 0.099},
#                {'name': 'propane', 'z': 0.0244, 'Tc': 370.01, 'Pc': 4260000, 'w': 0.152}]
#
# nc = len(composition)  # Components number of the composition
#==================================================================

#=========================Live oil =x3=========================================
# composition = [{'name': '2,2-dimethylbutane', 'z': 0.0417, 'Tc': 489.21, 'Pc': 3102000, 'w': 0.2251},
#                {'name': 'n-heptane', 'z': 0.0366, 'Tc': 540.3, 'Pc': 2734000, 'w': 0.3481},
#                {'name': 'ethylcyclohexane', 'z': 0.0217, 'Tc': 606.9, 'Pc': 3250000, 'w': 0.318},
#                {'name': 'n-nonane', 'z': 0.0176, 'Tc': 594.7, 'Pc': 2280000, 'w': 0.4409},
#                {'name': 'propylcyclohexane', 'z': 0.0105, 'Tc': 630.8, 'Pc': 2860000, 'w': 0.3149},
#                {'name': '1,2,3,4-tetrahydronaphthalene', 'z': 0.0159, 'Tc': 719.5, 'Pc': 3630000, 'w': 0.3318},
#                {'name': '1,3,5-triethylbenzene', 'z': 0.0233, 'Tc': 679, 'Pc': 2330000, 'w': 0.507},
#                {'name': '1-phenylhexane', 'z': 0.0133, 'Tc': 695, 'Pc': 2350000, 'w': 0.4498},
#                {'name': 'n-tridecane', 'z': 0.0044, 'Tc': 676, 'Pc': 1679000, 'w': 0.6099},
#                {'name': '1-phenyloctane', 'z': 0.0223, 'Tc': 725, 'Pc': 1980000, 'w': 0.5845},
#                {'name': 'n-pentadecane', 'z': 0.0109, 'Tc': 707.5, 'Pc': 1479000, 'w': 0.7192},
#                {'name': 'n-hexadecane', 'z': 0.0046, 'Tc': 722.4, 'Pc': 1401000, 'w': 0.7442},
#                {'name': 'octadecane', 'z': 0.0147, 'Tc': 747.7, 'Pc': 1292000, 'w': 0.802},
#                {'name': 'nonadecane', 'z': 0.0128, 'Tc': 755.3, 'Pc': 1160000, 'w': 0.8722},
#                {'name': '1-phenylhexadecane', 'z': 0.0157, 'Tc': 827.35, 'Pc': 1279000, 'w': 0.9055},
#                {'name': 'tetracosane', 'z': 0.0023, 'Tc': 799.8, 'Pc': 1075000, 'w': 1.184},
#                {'name': 'squalane', 'z': 0.0816, 'Tc': 820, 'Pc': 900000, 'w': 1.2436},
#                {'name': 'methane', 'z': 0.5285, 'Tc': 190.56, 'Pc': 4599000, 'w': 0.01},
#                {'name': 'ethane', 'z': 0.0819, 'Tc': 305.32, 'Pc': 4885000, 'w': 0.099},
#                {'name': 'propane', 'z': 0.0397, 'Tc': 370.01, 'Pc': 4260000, 'w': 0.152}]
#
# nc = len(composition)  # Components number of the composition

#========================================================================================
# #=========================dead oil=========================================
composition = [{'name': '2,2-dimethylbutane', 'z': 0.1192, 'Tc': 489.21, 'Pc': 3102000, 'w': 0.2251},
               {'name': 'n-heptane', 'z': 0.1047, 'Tc': 540.3, 'Pc': 2734000, 'w': 0.3481},
               {'name': 'ethylcyclohexane', 'z': 0.0621, 'Tc': 606.9, 'Pc': 3250000, 'w': 0.318},
               {'name': 'n-nonane', 'z': 0.0503, 'Tc': 594.7, 'Pc': 2280000, 'w': 0.4409},
               {'name': 'propylcyclohexane', 'z': 0.0301, 'Tc': 630.8, 'Pc': 2860000, 'w': 0.3149},
               {'name': '1,2,3,4-tetrahydronaphthalene', 'z': 0.0454, 'Tc': 719.5, 'Pc': 3630000, 'w': 0.3318},
               {'name': '1,3,5-triethylbenzene', 'z': 0.0666, 'Tc': 679, 'Pc': 2330000, 'w': 0.507},
               {'name': '1-phenylhexane', 'z': 0.0379, 'Tc': 695, 'Pc': 2350000, 'w': 0.4498},
               {'name': 'n-tridecane', 'z': 0.0127, 'Tc': 676, 'Pc': 1679000, 'w': 0.6099},
               {'name': '1-phenyloctane', 'z': 0.0638, 'Tc': 725, 'Pc': 1980000, 'w': 0.5845},
               {'name': 'n-pentadecane', 'z': 0.0310, 'Tc': 707.5, 'Pc': 1479000, 'w': 0.7192},
               {'name': 'n-hexadecane', 'z': 0.0131, 'Tc': 722.4, 'Pc': 1401000, 'w': 0.7442},
               {'name': 'octadecane', 'z': 0.0420, 'Tc': 747.7, 'Pc': 1292000, 'w': 0.802},
               {'name': 'nonadecane', 'z': 0.0365, 'Tc': 755.3, 'Pc': 1160000, 'w': 0.8722},
               {'name': '1-phenylhexadecane', 'z': 0.0449, 'Tc': 827.35, 'Pc': 1279000, 'w': 0.9055},
               {'name': 'tetracosane', 'z': 0.0066, 'Tc': 799.8, 'Pc': 1075000, 'w': 1.184},
               {'name': 'squalane', 'z': 0.2331, 'Tc': 820, 'Pc': 900000, 'w': 1.2436}]

               # {'name': 'methane', 'z': 0.0, 'Tc': 190.56, 'Pc': 4599000, 'w': 0.01},
               # {'name': 'ethane', 'z': 0.0, 'Tc': 305.32, 'Pc': 4885000, 'w': 0.099},
               # {'name': 'propane', 'z': 0.0, 'Tc': 370.01, 'Pc': 4260000, 'w': 0.152}]

nc = len(composition)  # Components number of the composition



#======initial for x2 and x3 =======================================

# xo = np.array([[0.01, 0.1, 0.005],
#                [0.015, 0.09, 0.105],
#                [0.02, 0.08, 0.205],
#                [0.025, 0.07, 0.105],
#                [0.03, 0.06, 0.108333333333333],
#                [0.035, 0.05, 0.00833333333333333],
#                [0.04, 0.04, 0.0116666666666667],
#                [0.045, 0.03, 0.015],
#                [0.05, 0.03125, 0.0183333333333333],
#                [0.055, 0.0325, 0.0216666666666667],
#                [0.06, 0.03375, 0.025],
#                [0.0625, 0.035, 0.0283333333333333],
#                [0.065, 0.03625, 0.0316666666666667],
#                [0.0675, 0.0375, 0.035],
#                [0.07, 0.03875, 0.0383333333333333],
#                [0.0725, 0.04, 0.0416666666666667],
#                [0.075, 0.04125, 0.045],
#                [0.0775, 0.0425, 0.0483333333333333],
#                [0.08, 0.04375, 0.0516666666666667],
#                [0.045, 0.0675, 0.05167]])  # initial guess of the molar fraction equilibrium composition of zi
#

import random

# print()
# # our initial guess
# xo = np.zeros((nc, 3))
# for i in range(0,nc):
#     d = 0.1* random.random()
#     d1 = [np.array([[composition[i]['z']]]),0.01, (1+d)*np.array([[composition[i]['z']]])]
#     for j in range(0, 3):
#         xo[i, j] = d1[j] #np.array([[composition[i]['z']]])


#==== initial for x1---with 17 components=========================================

xo = np.array([[0.0875, 0.1425, 0.05333333],
               [0.095, 0.13375, 0.15666667],
               [0.065, 0.1475, 0.25667],
               [0.025, 0.07, 0.105],
               [0.03, 0.06, 0.108333333333333],
               [0.035, 0.05, 0.00833333333333333],
               [0.04, 0.04, 0.0116666666666667],
               [0.045, 0.03, 0.015],
               [0.05, 0.03125, 0.0183333333333333],
               [0.055, 0.0325, 0.0216666666666667],
               [0.06, 0.03375, 0.025],
               [0.0625, 0.035, 0.0283333333333333],
               [0.065, 0.03625, 0.0316666666666667],
               [0.0675, 0.0375, 0.035],
               [0.07, 0.03875, 0.0383333333333333],
               [0.0725, 0.04, 0.0416666666666667],
               [0.075, 0.04125, 0.045]])



               # [0.0775, 0.0425, 0.0483333333333333],
               # [0.08, 0.04375, 0.0516666666666667],
               # [0.045, 0.0675, 0.05167]])  # initial guess of the molar fraction equilibrium composition of zi




#   20,19,18 add to 1,2,3===> sum=1
#================================================================================

ZCO2 = 0.9
mainXo = xo
mainComposition = copy.deepcopy(composition)

nc,composition,xo = addCarbon(ZCO2,composition,xo)
# nc,composition,xo = addCarbon(0.2208,composition,xo)

startPressure = 1.0e6
targetPressure = 60.0e6
beta = np.array([[0.09, 0.01, 0.81]])
# beta = np.array([[0.909, 0.09, 0.001]])
# beta = np.array([[1, 0.0, 0.0]])
phases = [['liquid1'], ['liquid2'], ['vapour']]
Nsamples = 800
xres1 = []
pCounter=0
# iter, beta, xo, phases, tol = solveEOS(298.15, 6.0654e6, composition, xo, beta, phases)
# iter, beta, xo, phases, tol = solveEOS(290 , startPressure, composition, xo, beta, phases)
# iter, beta, xo, phases, tol = solveEOS(295, startPressure, composition, xo, beta, phases)

temp = 373
hBeta = []
hXo = []
hPhases = []
hPressure = []

i = 0
condBreak = -1
while i < Nsamples and condBreak == -1:
    currentPressure = (targetPressure-startPressure)/ Nsamples * i + startPressure
    iter, beta, xo, phases,tol = solveEOS(temp, currentPressure, composition, xo, beta,phases)
    print(i, ",", currentPressure*1e-6,",",tol, ",", beta[0, 0])
    hBeta.append(beta)
    hXo.append(xo)
    hPhases.append(phases)
    hPressure.append(currentPressure)
    i = i + 1
    if  beta[0, 0]>0.99999:
    # if beta[0, 0] < 0.999:
        condBreak = 0


print(xo)
print(beta)

dPressure = (targetPressure -startPressure)/ Nsamples

startPressure = hPressure[-1]
dz = (0.8-0.0)/100.0
dzz = (1.0-0.8)/100.0
j = 1
ZCO2 = 0.9
XOOO = []
BetaOOO = []

while (j<800 and ZCO2<1.02 ):
    # ZCO2 = (1.0 - 0.0009) / 100.0 * j + 0.0009
    # ZCO2 = (1.0 - 0.0009) / 100.0 * j + 0.0009
    # ZCO2 = 0.820162
    nc,composition,_ = addCarbon(ZCO2,mainComposition,mainXo)
    #print(composition)
    condBreak = -1
    i = 0
    while i < 500 and condBreak == -1:
        currentPressure = dPressure * i + startPressure
        # currentPressure = startPressure - dPressure * i
        # if ZCO2 < 0.97 :
        #     currentPressure = dPressure * i + startPressure
        # else :
        #     currentPressure = dPressure * i + startPressure
            # currentPressure = dPressure / 10 * i + startPressure
        if currentPressure < 0 :
            currentPressure = 0.0
            print(ZCO2, currentPressure * 1e-6, i)
            break
        iter, beta, xo, phases,tol = solveEOS(temp, currentPressure, composition, xo, beta,phases)
        #print(i,",ZCo2=",ZCO2, ",", currentPressure,",",tol, ",", beta[0, 0])
        i = i + 1
        if beta[0, 0] > 0.99999:
           condBreak = 0
           XOOO.append(xo)
           BetaOOO.append(beta)

        # if beta[0, 0] > 0.99999:
        #     i = i + 1
        # else:
        #     condBreak = 0




    # print(f'{ZCO2:.10f}' , f'{currentPressure:.10f}')
    # if ZCO2 < 0.8:
    #     startPressure = currentPressure - 5 * dPressure
    # elif ZCO2 > 0.8 and ZCO2< 0.91:
    #     startPressure = currentPressure +5  * dPressure
    # else:
        # if ZCO2 < 0.95:
        #     startPressure = currentPressure - 15 * dPressure
        # elif ZCO2 > 0.95 and ZCO2 < 0.97:
        #     startPressure = currentPressure -25 * dPressure
        # startPressure = currentPressure - 40 * dPressure


    # print(ZCO2,currentPressure,i)
    # startPressure = currentPressure - 10*dPressure
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    if i == 1 and pCounter < 20 :  #and ZCO2 > 0.8:
        startPressure = currentPressure - 5.0 * dPressure
        # print("XXXX")
        # xo = copy.deepcopy(XOOO[-1])
        # beta = copy.deepcopy(BetaOOO[-2])
        # startPressure = currentPressure + 2.0 * dPressure
        #ZCO2=ZCO2
        pCounter += 1
    else:
        j = j + 1
        print(ZCO2, currentPressure * 1e-6, i)
        # ZCO2 += dz
        # startPressure = currentPressure - dPressure
        startPressure = currentPressure  + 2 * dPressure
        if ZCO2 < 0.8 :
            ZCO2 += dz
        else :
            ZCO2 += dzz
            startPressure = currentPressure + 2 * dPressure



        pCounter = 0

#+++++++++++++++++++++++++++++++++++++++++++++++++++
    # j = j + 1

# print("==========================================================")
# print(xres1)
# print("==========================================================")
# print(xo)
# print("==========================================================")

# if len(phases)==2:
#     nXo = np.zeros((21, 3))
#     nXo[:, 0] = xo[:, 0].copy()
#     nXo[:, 1] = xo[:, 1].copy()
#     if not ('liquid1' in phases):
#         phases = [phases[0], phases[1],['liquid1']]
#         A = np.array(phases).reshape(3).tolist().index('liquid2') #np.where(np.array(phases).reshape(3)=='liquid2')
#         nXo[:, 2] = xo[:, A].copy()
#     elif not ('liquid2' in phases):
#         phases = [phases[0], phases[1], ['liquid2']]
#         A = np.array(phases).reshape(3).tolist().index('liquid2')
#         nXo[:, 2] = xo[:, A].copy()
#     else:
#         print("Error!!!")
#     xo = nXo.copy()
#     beta = np.array([[beta[0, 0] - 0.001, beta[0, 1] - 0.001, 0.002]])
# elif len(phases)==1:
#     print("XXXXXXX")