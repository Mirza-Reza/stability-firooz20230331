import numpy as np
import copy


def addCarbon(ZCO2,composition0,xo0):
    compCarbonDiox = [{'name': 'carbon dioxide', 'z': 0.6, 'Tc': 304.16, 'Pc': 7.378e6, 'w': 0.231}]
    compCarbonDiox[0]['z'] = ZCO2
    compCarbonDiox = compCarbonDiox[0]

    xo = copy.deepcopy(xo0)
    composition = copy.deepcopy(composition0)

    if (ZCO2>0):

        if composition[-1]['name'] == 'carbon dioxide':
            composition[-1]['z'] = compCarbonDiox['z']
            nc = len(composition)  # Components number of the composition
            for xoInd in range(0, len(xo[0, :])):
                for xz in range(0, nc - 1):
                    if xoInd == 0:
                        composition[xz]['z'] = composition[xz]['z'] * (1 - composition[nc - 1]['z'])

        else:
            # if there is no co2 in the composition
            composition.append(compCarbonDiox)

            nc = len(composition)  # Components number of the composition
            # xoCoo = [0.6, 0.015, 0.05]  # INITIAL GUESS FOR THE CARBON DIOXIDE MOLAR COMPOSITION
            xoCoo = [0.6, 0.075, 0.0005]  # INITIAL GUESS FOR THE CARBON DIOXIDE MOLAR COMPOSITION
            # xo = np.vstack([xoGuess, xoCoo])
            xo = np.vstack([xo, xoCoo])

            for xoInd in range(0, len(xo[0, :])):
                for xz in range(0, nc - 1):
                    xo[xz, xoInd] = xo[xz, xoInd] * (1 - xo[nc - 1, xoInd])
                    if xoInd == 0:
                        composition[xz]['z'] = composition[xz]['z'] * (1 - composition[nc - 1]['z'])

    return nc,composition,xo