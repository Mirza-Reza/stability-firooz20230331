import numpy as np
import math
import matplotlib.pyplot as plt
from scipy.optimize import fsolve


def rrm(betaVal, zi, Ki, nUph):
    Krm = np.zeros((len(zi), nUph - 1));  # Reference equilibrium factors column vector
    for i in range(nUph-1):
        Krm[:, i] = Ki[:, 0]

    #===========================OK=================================================
    rrmVal = np.dot(np.array(zi / (np.vstack(Ki[:, 0]) + np.dot((np.vstack(Ki[:, 1:nUph]) - Krm),np.vstack(betaVal).reshape(-1,1)))).flatten(),
                    np.vstack(Ki[:, 1:nUph]) - Krm)
    # ===========================OK=================================================


    return rrmVal
