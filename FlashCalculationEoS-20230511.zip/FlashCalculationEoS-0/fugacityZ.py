import numpy as np
import math
import matplotlib.pyplot as plt
import scipy.optimize
from scipy.optimize import fsolve


def fugZi(pressure, temp,Zi, xi, phasezi, composition):

    R = np.float64(8.314472)  # Ideal gas constant [J.mol^{-1}.K^{-1}]  MPa.cm^3/mol.K
    T = np.float64(temp)  # Temperature [K]
    P = np.float64(pressure)  # Pressure [Pa]
    nc = len(composition)  # Components number of the composition

    from PPR78 import EoS
    ai, bi, alphai = EoS(pressure, temp, composition)

    # =================aij  bij ================================================================================
    from mixingRules import mixRules
    ami, bmi = mixRules(pressure, temp, composition,Zi, ai, bi, alphai)
    # ======end of Parameters ami and bmi are still part of mixing rules calculus===============

    A = (ami * P) / (pow(R * T, 2))
    B = bmi * P / (R * T)

    A0 = (ami * P) / (pow(R * T, 2))
    B0 = (bmi * P) / (R * T)

    A = np.array(np.squeeze(A0))
    B = np.array(np.squeeze(B0))

    # ============END of ONLY FOR PLOTTING===============================

    # rootSol = np.roots([1,B - 1, A - 2 * B - 3 * B*B,B*B + B*B*B- (A * B)])
    rootSol = np.roots([1, - 1, A - B - B * B, -(A * B)])
    roots = np.real(rootSol[np.isreal(rootSol)])

    # print(rootSol)
    # print(roots)

    if phasezi == ["liquid1"] or phase == ["liquid2"]:  # phases[0]:
        Zt = min(roots)
        if Zt < 0:
            Zt = max(roots)
        # Zt = max(roots)
        v = (Zt * R * T) / P
    elif phasezi == ["vapour"]:  # phases[2]:
        Zt = max(roots)
        # Zt = min(roots)
        v = (Zt * R * T) / P
    else:
        print("the value is not correct")
    bmii = np.array(bi / bmi)
    Z = Zt

    # # ==============================================
    # R0 = A * B
    # R1 = A - B * (1.0 + B)
    # f = Z * Z * Z - Z * Z + R1 * Z - R0
    # if Zt<=0 or f>1.0e-3:
    #     go=0
    #     iter=0
    #     nZ=0.9
    #     while (go < 2):
    #         while (abs(nZ / Z - 1.0) > 1.0e-8 and iter < 1000):
    #             Z = nZ
    #             f = Z * Z * Z - Z * Z + R1 * Z - R0
    #             fp = 3.0 * Z * Z - 2.0 * Z + R1
    #             fpp = 6.0 * Z - 2.0
    #             nZ = Z - f / fp / (1.0 - f * fpp / 2.0 / fp / fp)
    #             iter+=1
    #
    #
    # else:
    #     go = 2

    # fugVal= np.exp(
    #     (bmii * (Z * np.ones((nc, 1)) - np.ones((nc, 1)))) - np.log(Z * np.ones((nc, 1)) - B * np.ones((nc, 1))) - (
    #                 A / (2 * np.sqrt(2) * B)) * ((2 * (np.dot(aij,xi).reshape(-1,1))) / ami - bmii) * np.log(
    #         (Z + 2.414 * B) / (Z - 0.414 * B)))
    # print(fugVal, '-----------------------------------')
    fugVal = (bmii * (Z * np.ones((nc, 1)) - np.ones((nc, 1)))) - np.log(
        Z * np.ones((nc, 1)) - B * np.ones((nc, 1))) + (
                     A / B) * (bmii - (2 / ami * (np.dot(alphaij, xi).reshape(-1, 1)))) * np.log(
        (1.0 + (B / (Z * np.ones((nc, 1))))))
    return fugVal
    print(fugVal)

# =================END Compressibility factor roots & Fugacity Coefficients of the cubic EoS====================================

