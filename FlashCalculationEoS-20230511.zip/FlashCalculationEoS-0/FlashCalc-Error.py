"""
Predictive Peng Robinson 78 EoS  (PPR78) for mixtures
J.-N. Jaubert, F. Mutelet / Fluid Phase Equilibria 224 (2004) 285–304 (doi:10.1016/j.fluid.2004.06.059)
@author: Gustavo Oviedo
"""
import os

import numpy as np
import copy
from sklearn import linear_model
import csv
import pandas as pd
import matplotlib.pyplot as plt
# import functions
import csv
import math
import scipy.optimize
from scipy.optimize import fsolve, least_squares

from sympy import symbols, Eq, solve
import time
from sklearn.metrics import mean_squared_error, max_error
from sklearn.metrics import mean_absolute_error as mae
from math import sqrt
from keras import backend as K

# https://pyquestions.com/rmse-rmsle-loss-function-in-keras
import tensorflow as tf
# import tensorflow.keras.backend as k




import mixingRules
from PPR78 import EoS
from mixingRules import mixRules
from fugacity import fug
from fugacityCriteria import fugC
from rachfordRiceEq import rrm
from theta import thetaFunc
from solver import solveEOS
from carbon import addCarbon
import pandas as pd
import numpy as np

import warnings
import random


def root_mean_squared_log_error(y_true, y_pred):
    msle = tf.keras.losses.MeanSquaredLogarithmicError()
    return K.sqrt(msle(y_true, y_pred))

#================================================================================


# LiveOil1-EXP==============================================================================================================



# T373-LO1
# zEXP=[0.0648,0.22,0.2739,0.4205,0.4433,0.5996,0.632,0.7286,0.7595,0.79,0.8157,0.845,0.8724,0.9164,0.9503,0.9613,0.9678,0.9725,0.9788,0.9827,0.9846]
# pEXP=[13.06,15.46,16.45,19.55,20.05,23.56,24.37,26.75,27.34,27.92,28.28,28.75,29.06,29.5,28.95,28,27.5,26.95,25.92,25.03,24.45]




# Note that the first zEXP and pEXP is excluded since it started with z=0.



# T423-Lo1
# zEXP=[0.0643,0.2197,0.4203,0.5995,0.7285,0.79,0.8724,0.9164,0.9503,0.9613,0.9678,0.9725]
# pEXP=[14.47,17.45,22.46,27.51,30.87,31.96,33.12,33.38,32.75,31.5,31.03,30.02]



# LiveOil2-EXP==============================================================================================================
# T423-Lo2
# zEXP=[0.12690,0.33480,0.50760,0.62620,0.67110,0.75350,0.82300,0.86080,0.88370,0.90100,0.92200,0.95030,0.96950,0.99020]
# pEXP=[29.58000,32.45000,34.28000,35.10000,35.30000,35.20000,35.10000,34.70000,34.25000,33.50000,32.80000,31.12000,29.01000,25.37000]


# T373-Lo2
# zEXP=[0.1401,0.3425,0.5121,0.629,0.7078,0.7588,0.8114,0.8432,0.8923,0.9225,0.9565,0.9624,0.9753,0.9788,0.9859,0.9922,0.9933]
# pEXP=[28.015,29.52,31.38,32.14,32.692,32.45,31.75,31.1,29.815,28.645,26.215,25.62,24.05,23.22,22.13,21.07,20.25]



# T323-Lo2
# zEXP=[0.1403, 0.3426, 0.5122, 0.6291, 0.7078, 0.7605, 0.8432, 0.8835, 0.9226 , 0.9412, 0.9526, 0.9594, 0.9653, 0.9773, 0.9855, 0.9933, 0.9944]
# pEXP=[25.03,25.83,26.77,27.12,26.95,26.75,26.4,26,25.35,23.62,22.05,21.13,19.94,18.4,16.9,15.02,14.13]
# Note that the first zEXP and pEXP is excluded since it started with z=0.

#===============================================================================================================
# Dash-Alg-LO1===========================================================================================
# T323-LO1
# zEXP=[0.0654,0.2205,0.4208,0.5998,0.7287,0.79,0.8297,0.8494,0.8724,0.875,0.9041,0.9164,0.9323,0.9453,0.9493,0.9583,0.9618,0.9717,0.9788,0.9846,0.9868,0.9915]
# pEXP=[11.04,12.48,14.62,16.71,20.24,22.15,23.52,24.05,25.05,24.93,26.42,27.05,26.45,25.85,25.55,24.5,24,22.15,20.22,16.65,16.23,14.92]
# pDash=[10.829,11.404,12.44,13.63,15.476,17.361,18.818,19.378,19.941,20.199,21.105,21.413,20.851,19.63,19.216,17.938,17.051,15.582,14.612,13.689,13.126,12.232]

# print(np.shape(zEXP),np.shape(pEXP), np.shape(pDash))
# pLine=[]
# pInG=[]

# T373-Lo1
# zEXP=[0.0648,0.22,0.2739,0.4205,0.4433,0.5996,0.632,0.7286,0.7595,0.79,0.8157,0.845,0.8724,0.9164,0.9503,0.9613,0.9678,0.9725,0.9788,0.9827,0.9846]
# pEXP=[13.06,15.46,16.45,19.55,20.05,23.56,24.37,26.75,27.34,27.92,28.28,28.75,29.06,29.5,28.95,28,27.5,26.95,25.92,25.03,24.45]
# pDash=[]
# pLine=[]
# pInG=[]


# T423-Lo1
zEXP=[0.0643,0.2197,0.4203,0.5995,0.7285,0.79,0.8724,0.9164,0.9503,0.9613,0.9678,0.9725]
pEXP=[14.47,17.45,22.46,27.51,30.87,31.96,33.12,33.38,32.75,31.5,31.03,30.02]
# pDash=[]
# pLine=[]
# pInG=[]

#============================================================================================================
# Dash-Alg-LO2===============================================================================================
# T323-Lo2
# zEXP=[0.1403, 0.3426, 0.5122, 0.6291, 0.7078, 0.7605, 0.8432, 0.8835, 0.9226 , 0.9412, 0.9526, 0.9594, 0.9653, 0.9773, 0.9855, 0.9933, 0.9944]
# pEXP=[25.03,25.83,26.77,27.12,26.95,26.75,26.4,26,25.35,23.62,22.05,21.13,19.94,18.4,16.9,15.02,14.13]
# pDash=[]
# pLine=[]
# pInG=[]


# T373-Lo2
# zEXP=[0.1401,0.3425,0.5121,0.629,0.7078,0.7588,0.8114,0.8432,0.8923,0.9225,0.9565,0.9624,0.9753,0.9788,0.9859,0.9922,0.9933]
# pEXP=[28.015,29.52,31.38,32.14,32.692,32.45,31.75,31.1,29.815,28.645,26.215,25.62,24.05,23.22,22.13,21.07,20.25]
# pDash=[]
# pLine=[]
# pInG=[]


# T423-Lo2
zEXP=[0.12690,0.33480,0.50760,0.62620,0.67110,0.75350,0.82300,0.86080,0.88370,0.90100,0.92200,0.95030,0.96950,0.99020]
pEXP=[29.58000,32.45000,34.28000,35.10000,35.30000,35.20000,35.10000,34.70000,34.25000,33.50000,32.80000,31.12000,29.01000,25.37000]

# pDash=[]
# pLine=[]
# pInG=[]




#==================================================================================
P=[]
data = pd.read_csv("Error-LO2.csv")
#value = data["columnname"]
#
z = data.cz423
p = data.cp423
print(z)
# print(pDash)

for i in range(len(zEXP)):
    for j in range(len(p)):
        LastZ=0.1
        if zEXP[i] >= z[j]  and zEXP[i] < z[j+1]:
            l=zEXP[i]-z[j]
            r=z[j+1]-zEXP[i]
            if l<= r:
                print(zEXP[i], z[j], '<=====>', zEXP[i] - z[j], 'L' )
                P.append(p[j])
            else:
                print(zEXP[i], z[j+1], '<=====>', zEXP[i] - z[j+1], 'R')
                P.append(p[j+1])

            # writer.writerow(pKij)
            # data=pKij
print(P, np.shape(P))

# cvs_writer.writerows(pKij)

# fh.close()

# LastZ = ZCO2



# result = mean_squared_error(pEXP, pKij)
# Err.append(result)
print('MSE=', mean_squared_error(pEXP, P),'------------------>')
print('max=', max_error(pEXP, P), '==================')
print('RMSE=', sqrt(mean_squared_error(pEXP, P)), '==================')
print('MAE=', mae(pEXP, P), '==================')
print('RMSLE=', root_mean_squared_log_error(pEXP, P), '==================')
#














