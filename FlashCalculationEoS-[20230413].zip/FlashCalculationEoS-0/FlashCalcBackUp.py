"""
Predictive Peng Robinson 78 EoS  (PPR78) for mixtures
J.-N. Jaubert, F. Mutelet / Fluid Phase Equilibria 224 (2004) 285–304 (doi:10.1016/j.fluid.2004.06.059)
@author: Gustavo Oviedo
"""

import numpy as np
import pandas as pd
# import functions
import  csv
import math
from scipy.optimize import fsolve
from fugacity import fug

# ==================Component properties composition & input variables==========================================
# modelEoS= [{'PR78', 'PPR78', 'SRK', 'PC-SAFT', 'CPA'}]
tempMinVal=230.15
tempMaxInVal=230.15
tempNumbSpaces=1
tempVal=np.zeros([tempNumbSpaces])
DtempVal=(tempMaxInVal-tempMinVal)/tempNumbSpaces

betaPrint=[]
xoPrint=[]
p=0

for dt in range(tempNumbSpaces):
    if dt==0:
        tempVal[dt]=tempMinVal
    else:
        tempVal[dt]=tempVal[dt-1]+DtempVal

# print("TempertureArray=",tempVal)
# print("lenght=", len(tempVal))

# tempVal=np.array([205.15, 217.15, 230.15, 232.15, 250.15])
betaEnvelope=[]
xoEnvelope=[]
for t in tempVal:
    temp = np.float64(t);  # Temperature [K]

    pressure = np.float64(4.5e06);  # Pressure [Pa]

    composition = [
        {'name': 'carbon dioxide', 'z': 0.5, 'Tc': 304.16, 'Pc': 7.378e6, 'w': 0.231},
        {'name': 'methane', 'z': 0.5, 'Tc': 190.56, 'Pc': 4.599e6, 'w': 0.01}];
    # composition = [
    #     {'name': 'carbon dioxide', 'z': 0.2, 'Tc': 304.16, 'Pc': 7.378e6, 'w': 0.231},
    #     {'name': 'n_heptane', 'z': 0.8, 'Tc': 540.3, 'Pc': 2.734e6, 'w': 0.3481}];

    zi = np.array([[composition[0]['z']],
                   [composition[1]['z']]])

    xo = np.array([[.15, .3],
                   [.85, .7]])  # initial guess of the molar fraction equilibrium composition of zi

    betaInitVal = np.array([0.9, 0.1])   #Initial guess of the phase fraction -beta-  [vapour, liquid]

    phases = [['vapour'], ['liquid']];

    nph = len(phases)  # phases number

    nc = len(composition)  # Components number of the composition

    theta = np.zeros((1, nph))  # stability function

    # =======================END of Component properties composition & input variables=============================

    # =================Global constants setting of the EoS model ==================================================
    from PPR78 import EoS

    ai,bi=EoS(pressure,temp,composition)
    # print("ai=", ai)
    # print("bi=", bi)
    # =================END of Global constants setting of the EoS model ============================================

    # =================Mixing rules ================================================================================
    from mixingRules import mixRules

    aij,bij=mixRules(pressure,temp,composition,ai,bi)
    # print("aij=", aij)
    # print("bij=", bij)
    # =================END of Mixing rules ===========================================================================

    tolf = 1e-06;
    tol = 1
    iter = 1
    iterMax = 500
    # while (tol > tolf or iter < iterMax):
    while tol > tolf:
        xro = xo.copy()

        #=================================Fugacity coneficients (phi) loop for every phase=====================================
        phi = np.zeros((nc, nph));
        v = np.zeros((1, nph));
        for i in range(nph):
            xi = xo[:, i]


            phi[:, i] = np.array(fug(pressure, temp, xi, phases[i], bi, aij, bij)).transpose();
            # print("phi=", phi)
        # print("phi=", phi)
        #=================================END of Fugacity coneficients (phi) loop for every phase================================

        # ==================Equilibrium factors Ki & Rachford-Rice equation===================================
        Ki = np.zeros((nc, nph));  # Equilibrium factors
        Xm = np.zeros((nc, nph));  # Ones´ matrix to define the maximum values of the xi composition by row

        Xm = xo == np.max(xo, axis=1).reshape(-1, 1)
        phir = np.max(phi * Xm, axis=1).reshape(-1, 1)  # Reference fugacity coefficients column vector for each component

        Ki = phir / phi
        # print(phir)

        Krm = np.zeros((len(zi), nph - 1));  # Reference equilibrium factors column vector
        for i in range(nph - 1):
            Krm[:, i] = Ki[:, i]

        from rachfordRiceEq import rrm

        # betaFunc = fsolve(rrm, betaInitVal[0])
        betaFunc = fsolve(rrm, [0.1])
        # betaFunc=rrm(betaInitVal,zi,Ki,Krm)
        # beta = np.zeros((1, nph))
        # print("betaFun=", betaFunc)
        beta = betaInitVal
        for i in range(1,nph):  # enumerate(comp[0:nc]):
            if betaFunc < 0:
                beta[i] = 0
            else:
                beta[i] = betaFunc
                # beta[i-1] = 1 - beta[i]
        beta[0] = 1 - beta[1]
        if beta[0] < 0:
            beta[0] = 0

            # ==============GUARANTED THE SYSTEM HAS AT LIST TWO EQUILIBRIUM PHASES===============
            zeroPosBeta = np.where(beta == 0)[0]
            nbZero = len(zeroPosBeta)
            # print(zeroPosBeta)
            if nbZero > 1:
                nbZero = nbZero - 1
                zeroPosBeta[0, 0] = []

            for i in range(nbZero):
                if zeroPosBeta == 0:
                    xo = xo[:, [1, 0]]
                    Ki = Ki[:, [1, 0]]
                    beta = beta[[1, 0]]
                    phases[0], phases[1] = phases[1], phases[0]
                else:
                    xo = xo[:, [1, 0]]
                    Ki = Ki[:, [1, 0]]
                    beta = beta[[1, 0]]
                    phases[0], phases[1] = phases[1], phases[0]

                # print("beta=", beta)
        # ==============END of GUARANTED THE SYSTEM HAS AT LIST TWO EQUILIBRIUM PHASES===============

        from theta import thetaFunc

        theta[0, 1] = thetaFunc()  #Eq. 3.77 Pag.43 Reinaldo´s Thesis
        # print("theta=", theta)
        ##Updating molar composition Eq. 3.73 pag.42 Reinaldo´s Thesis
        Xri = zi * pow((np.vstack(Ki[:, 0]) + (np.vstack(Ki[:, nph - 1]) - Krm) * beta[1]), -1)
        # print("Xri=", Xri)
        # print("xro=", xro)
        # TAKING INTO THE ACCOUNT THETA PARAMETER FOR THE STABILITY ANALYSYS
        for j in range(nph):
            xo[:, j] = np.array(Xri).flatten() * Ki[:, j] * math.exp(theta[0, j])  #Residual Function, Eq. 3.78 Pag. 47 Reinaldo´s Thesis
            # print("x_i=", xo)

        delta = abs(xo - xro)
        tol = sum((sum(delta)))
        iter = iter + 1
        print("iter=",iter)
        if tol<=tolf:
            betaEnvelope.append(beta)
            xoEnvelope.append(xo.tolist())
            # print("betaVal=",betaEnvelope)

# betaPrint = pd.DataFrame(betaEnvelope)
# betaPrint.to_csv(r'D:\GEOCelis_Drive\Dpbx_GEOCelis\FlowSimulation\FlashCalculationEoS\beta.csv',';')

xoEnvelopeFlat=[item for sublist in xoEnvelope for item in sublist]
with open("Xo.csv","w+",newline='') as my_csv:
    csvWriter=csv.writer(my_csv,delimiter=';')
    csvWriter.writerows(xoEnvelopeFlat)
print("betaVals=", beta)
print("xo=", xoEnvelope)
print("Temp=", tempVal)
# ==================end of Equilibrium factors Ki & Rachford-Rice equation===================================
