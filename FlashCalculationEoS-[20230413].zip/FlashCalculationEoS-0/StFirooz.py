import numpy as np
from PPR78 import EoS
import math
import matplotlib.pyplot as plt
import scipy.optimize
from scipy.optimize import fsolve
import pandas as pd
import copy
import csv

#See discussions, stats, and author profiles for this publication at: https://www.researchgate.net/publication/227541887
#based on Firoozabadi paper





def fugZi(pressure, temp, xi, phasezi, bi, aij, bij, composition):

    R = np.float64(8.314472)  # Ideal gas constant [J.mol^{-1}.K^{-1}]  MPa.cm^3/mol.K
    T = np.float64(temp)  # Temperature [K]
    P = np.float64(pressure)  # Pressure [Pa]
    nc = len(composition)  # Components number of the composition

    from PPR78 import EoS
    ai, bi = EoS(pressure, temp, composition)

    # =================aij  bij ================================================================================
    from mixingRules import mixRules
    aij, bij , sigi = mixRules(pressure, temp, composition, ai, bi)


    # =================Compressibility factor roots & Fugacity Coefficients of the cubic EoS====================================
    # ======Parameters ami and bmi are still part of mixing rules calculus===============
    ami =np.array([sum(aij.dot(xi) * xi)])
    bmi =np.array(sum(bi*xi)) #sum(bij.dot(xi))
    # ======end of Parameters ami and bmi are still part of mixing rules calculus===============

    A = (ami * P) / (pow(R * T, 2))
    B = bmi * P / (R * T)

    A0 = (ami * P) / (pow(R * T, 2))
    B0 = (bmi * P) / (R * T)

    A = np.array(np.squeeze(A0))
    B = np.array(np.squeeze(B0))


    #============END of ONLY FOR PLOTTING===============================

    # rootSol = np.roots([1,B - 1, A - 2 * B - 3 * B*B,B*B + B*B*B- (A * B)])
    rootSol = np.roots([1, - 1, A - B - B*B , -(A * B)])
    roots = np.real(rootSol[np.isreal(rootSol)])


    # print(rootSol)
    # print(roots)

    if phasezi == ["liquid1"]  or phase == ["liquid2"] : # phases[0]:
        Zt = min(roots)
        if Zt<0:
            Zt=max(roots)
        # Zt = max(roots)
        v = (Zt * R * T) / P
    elif phasezi == ["vapour"]: #phases[2]:
        Zt = max(roots)
        # Zt = min(roots)
        v = (Zt * R * T) / P
    else:
        print("the value is not correct")
    bmii = np.array(bi / bmi)
    Z = Zt

    # # ==============================================
    # R0 = A * B
    # R1 = A - B * (1.0 + B)
    # f = Z * Z * Z - Z * Z + R1 * Z - R0
    # if Zt<=0 or f>1.0e-3:
    #     go=0
    #     iter=0
    #     nZ=0.9
    #     while (go < 2):
    #         while (abs(nZ / Z - 1.0) > 1.0e-8 and iter < 1000):
    #             Z = nZ
    #             f = Z * Z * Z - Z * Z + R1 * Z - R0
    #             fp = 3.0 * Z * Z - 2.0 * Z + R1
    #             fpp = 6.0 * Z - 2.0
    #             nZ = Z - f / fp / (1.0 - f * fpp / 2.0 / fp / fp)
    #             iter+=1
    #
    #
    # else:
    #     go = 2



    # fugVal= np.exp(
    #     (bmii * (Z * np.ones((nc, 1)) - np.ones((nc, 1)))) - np.log(Z * np.ones((nc, 1)) - B * np.ones((nc, 1))) - (
    #                 A / (2 * np.sqrt(2) * B)) * ((2 * (np.dot(aij,xi).reshape(-1,1))) / ami - bmii) * np.log(
    #         (Z + 2.414 * B) / (Z - 0.414 * B)))
    # print(fugVal, '-----------------------------------')
    fugVal = (bmii * (Z * np.ones((nc, 1)) - np.ones((nc, 1)))) - np.log(Z * np.ones((nc, 1)) - B * np.ones((nc, 1))) + (
                A / B) * (bmii - (2 / ami * (np.dot(aij, xi).reshape(-1, 1)))) * np.log((1.0 + (B / (Z * np.ones((nc, 1))))))
    return fugVal
    print(fugVal)


#--------- TPD ---------------------------------------------------
#
# def TPD(composition,cPress, cTemp, phasezi,phasewi, Zi, Wi, bi, aij, bij):
#     min_TPD = 1.0
#     TPD0 = stability_typ(composition, pressure, temp, ["liquid1"], ["liquid1"], Zi, bi, aij, bij)
#     if (TPD0>0):
#         TPD01 = stability_test(composition, pressure, temp, ["liquid1"], ["vapour"], Zi, bi, aij, bij)
#         if (TPD01>0):
#             minTPD = min(TPD00, TPD01)
#             TPD-typ=
#             return minTPD
#
#     return TPD0

#
#
#
#
#
#     TPD01 = stability(composition, pressure, temp, ["liquid1"], ["vapour"], Zi, bi, aij, bij)
#     TPD11 = stability(composition, pressure, temp, ["vapour"], ["vapour"], Zi, bi, aij, bij)
#     TPD10 = stability(composition, pressure, temp, ["vapour"], ["liquid1"], Zi, bi, aij, bij)
#     phi_Zi = fugZi(pressure, temp, Zi, phasezi, bi, aij, bij, composition)
#     phi_Wi = fugWi(pressure, temp, Wi, phasewi, bi, aij, bij, composition)
#     LnPhi_Zi = np.log(phi_Zi)
#     LnPhi_Wi = np.log(phi_Wi)
#     Ln_Zi = np.log(Zi)
#     Ln_Wi = np.log(Wi)
#     di_Wi = (LnPhi_Wi + Ln_Wi)
#     di_Zi =  LnPhi_Zi + Ln_Zi
#     TPD = np.sum(Wi * [di_Wi - di_Zi])
#     return TPD








# def TPD(composition,pressure, temp, phasezi,phasewi, Zi, Wi, bi, aij, bij):
#     # from fugacity import fug
#     phi_Zi = fugZi(pressure, temp, Zi, phasezi, bi, aij, bij, composition)
#     phi_Wi = fugWi(pressure, temp, Wi, phasewi, bi, aij, bij, composition)
#     LnPhi_Zi = np.log(phi_Zi)
#     LnPhi_Wi = np.log(phi_Wi)
#     Ln_Zi = np.log(Zi)
#     Ln_Wi = np.log(Wi)
#     di_Wi = (LnPhi_Wi + Ln_Wi)
#     di_Zi =  LnPhi_Zi + Ln_Zi
#     TPD = np.sum(Wi * [di_Wi - di_Zi])
#     return TPD


def TPD_minimum(composition, cPress, cTemp, phasezi,phasewi, Zi, bi, aij, bij):
    TPDr=[]
    TPDi=[]

    # for phasezi in phasesZi:
    #     for phasewi in phasesWi:
    #         print('            ======================', phasezi, phasewi, '=================')
    # Types = [1, 2, 3, 4]
    Types = [1,3]
    typ = 0
    for typ in Types:
        # print(
        #     '===================================================================================================')
        # print('type ==', typ, '<==============>', 'phase ==', phasezi,phasewi)
        TPD_typ = stability_typ(composition, cPress, cTemp, phasezi ,phasewi, Zi, bi, aij, bij, typ)
        # print("typ=  " ,  typ,'============', "TPD=  " ,    TPD_typ)
        TPDr.append(TPD_typ)
        Min_TPDr = min(TPDr)
        if Min_TPDr < 0:
            print(Min_TPDr,"<=====>   type=   ", typ)
            return Min_TPDr

    for i in range(nc):
        TPD_test = stability_test(composition, cPress, cTemp, phasezi,phasewi, Zi, bi, aij, bij, i)
        TPDi.append(TPD_test)
        Min_TPDi = min(TPDi)
        # print('======================================================================================')
        # print('Method : Ki{test[0.9]~[0.1]}', '<-->', 'trial component ==', i, '<==============>', Min_TPDi)
        Min_TPD = min(Min_TPDi, Min_TPDr)
        if Min_TPDi > 0 :
            print(TPD_test, "<=====>   i=   ", i)
            if i>= 13:
                return Min_TPD
        else:
            print(TPD_test, "<=====>   i=   ", i)
            return Min_TPD




    #     if TPD1 <= 0:
    #         print('INSTABLITY')
    #         # TPD=0
    #     else:
    #         # TPD=1
    #         TPDr.append(TPD1)
    #     i += 1
    # M1=min(TPDr)
    # M2=min(TPDi)
    # Min_TPD = min(M1,M2)
    # print(TPDr, '===================', Min_TPD)
    # return Min_TPD
#  ============ K Wilson --------------------------
def Kwil(pressure, temp, composition):
    # Kwil=pressure/temp
    Kwil=np.zeros((len(composition), 1))
    for i in range(0, len(composition)):
        Kwil[i,0]= (composition[i]['Pc']/pressure)* np.exp(5.373*(1+ composition[i]['w'])*(1-(composition[i]['Tc']/temp)))
    return Kwil

# def KSRK(pressure, temp, composition):
#     # Kwil=pressure/temp
#     KSRK=np.zeros((len(composition), 1))
#     for i in range(0, len(composition)):
#         Kwil[i,0]= (composition[i]['Pc']/pressure)* np.exp(5.373*( 1.0 + composition[i]['w'])*( 1.0 -(composition[i]['Tc']/temp)))
#     return Kwil


# print(Kwil(pressure, temp, composition))


#=========================  2  =========================================
# composition = [{'name': 'CH4', 'z': 0.7, 'Tc': 489.21, 'Pc': 3102000, 'w': 0.2251},
#                {'name': 'C6H14', 'z': 0.3, 'Tc': 370.01, 'Pc': 4260000, 'w': 0.152}]
# nc = len(composition)


#========================= 14  =========================================
composition = [{'name': 'N2', 'z': 0.0019, 'Tc': 126.2, 'Pc': 3.35e6, 'w': 0.040},
               {'name': 'CO2', 'z': 0.0101, 'Tc': 304.2, 'Pc': 7.28e6, 'w': 0.225},
               {'name': 'C1', 'z': 0.8649, 'Tc': 190.6, 'Pc': 4.54e6, 'w': 0.008},
               {'name': 'C2', 'z': 0.02480, 'Tc': 305.4, 'Pc': 4.82e6, 'w': 0.098},
               {'name': 'C3', 'z': 0.01280, 'Tc': 369.8, 'Pc': 4.19e6, 'w': 0.152},
               {'name': 'iC4', 'z': 0.00720, 'Tc': 408.1, 'Pc': 3.6e6, 'w': 0.176},
               {'name': 'nC4', 'z': 0.00370, 'Tc': 425.2, 'Pc': 3.75e6, 'w': 0.193},
               {'name': 'iC5', 'z': 0.00220, 'Tc': 460.4, 'Pc': 3.34e6, 'w': 0.227},
               {'name': 'nC5', 'z': 0.00140, 'Tc': 469.6, 'Pc': 3.33e6, 'w': 0.251},
               {'name': 'C6-C9', 'z': 0.009978, 'Tc': 547.43, 'Pc': 3.03e6, 'w': 0.4099},
               {'name': 'C10-C14', 'z': 0.012590, 'Tc': 643.77, 'Pc': 2.29e6, 'w': 0.6714},
               {'name': 'C15-C19', 'z': 0.012321, 'Tc': 724.23, 'Pc': 1.7e6, 'w': 0.9296},
               {'name': 'C20-C24', 'z': 0.009024, 'Tc': 777.38, 'Pc': 1.34e6, 'w': 1.1603},
               {'name': 'C25+', 'z': 0.027087, 'Tc': 849.61, 'Pc': 0.99e6, 'w': 1.6043}]
nc = len(composition)

#=== inputs ===============================================
###### kij +++++++++++++++++++++++++++++++++++++++++++++++
# in the case of 2 component kij considered 0
# k = [[ 0 for i in range(nc) ] for j in range(nc)]
# for i in range(nc):
#     for j in range(nc):
#         k[i][j]=0

# -------------------------------------------------------
Kij = np.array([[0,-0.02,0.12,0.12,0.12,0.12,0.12,0.12,0.12,0.12,0.12,0.12,0.12,0.12],
[- 0.02,0,0.093,0.128,0.123,0.136,0.125,0.131,0.12,0.12,0.12,0.12,0.12,0.12],
[0.12,0.093,0,0,0,0.02,0.02,0.025,0.025,0.035,0.038,0.038,0.038,0.038],
[0.12,0.128,0,0,0,0,0,0,0,0,0,0,0,0],
[0.12,0.123,0,0,0,0,0,0,0,0,0,0,0,0],
[0.12,0.136,0.02,0,0,0,0,0,0,0,0,0,0,0],
[0.12,0.125,0.02,0,0,0,0,0,0,0,0,0,0,0],
[0.12,0.131,0.025,0,0,0,0,0,0,0,0,0,0,0],
[0.12,0.12,0.025,0,0,0,0,0,0,0,0,0,0,0],
[0.12,0.12,0.035,0,0,0,0,0,0,0,0,0,0,0],
[0.12,0.12,0.038,0,0,0,0,0,0,0,0,0,0,0],
[0.12,0.12,0.038,0,0,0,0,0,0,0,0,0,0,0],
[0.12,0.12,0.038,0,0,0,0,0,0,0,0,0,0,0],
[0.12,0.12,0.038,0,0,0,0,0,0,0,0,0,0,0]])


#===========================================================

mainComposition = copy.deepcopy(composition)
pressure = 10.0e8
# phase = ["vapour"]
phase = ["liquid1"]
temp = 400
########### ai bi ###################################
from PPR78 import EoS
ai, bi = EoS(pressure, temp, composition)

# =================aij  bij ================================================================================
from mixingRules import mixRules
aij, bij, sigi = mixRules(pressure, temp, composition, ai, bi)


#---===========    Algorithm: SSI–Newton      ==================---------------------------------------------------

from fugacity import fug

# 1. Initialize the K-values from Wilson’s correlation
#=======  ki-Wilson  ================================================


# 2. For given zi, calculate di(z) from Eq. 3.
#===== diZ ==========================================

# extract zi from composition
Zi = np.zeros((1, nc)).transpose()
for comp in range(0, nc):
    Zi[comp, 0] = np.array([[composition[comp]['z']]])
# print(zi)

# LnZi = np.log(Zi)
# Phi_Zi = fug(pressure, temp, Zi, phaseZi, bi, aij, bij, composition)
# LnPhi_Zi = np.log(Phi_Zi)
# di_Zi = LnZi + LnPhi_Zi
# print(di_Zi)

#---------------------------------------------------------------
# pressure=20.0e6
# temp=600
# phase= ['vapour']
# # A=fugZi(pressure, temp, Zi, phase, bi, aij, bij, composition)
# AR=fug(pressure, temp, Zi, phase, bi, aij, bij, composition)

#======= Stability ==============================================
def stability_typ(composition,pressure, temp, phasezi,phasewi, Zi, bi, aij, bij,typ):
    # from fugacity import fug

    #-----====== loop ======--------------------------------
    Wi = Zi
    nWi = Zi
    oWi = Zi
    minKi = 1.0e3
    iter = 0
    diff = 0.01
    i=0
    # typ=1
    eps = 1.0e-6
    LnZi = np.log(Zi)
    # Lnphi-Zi is the coeficient of fugacity look at deep learning paper pg 20
    LnPhi_Zi = fugZi(pressure, temp, Zi, phasezi, bi, aij, bij, composition)
    di_Zi = LnZi + LnPhi_Zi
    KiWil = Kwil(pressure, temp, composition)  # Wilson
    #==== test ========================================================
    if (typ == 1):
        Ki=KiWil
    elif(typ == 2):
        Ki = 1/KiWil
    elif (typ == 3):
        Ki = np.cbrt(KiWil)
        # Ki = np.power(KiWil,0.333)
    else:
        Ki = 1 / (np.cbrt(KiWil))

    if phasewi == ["vapour"]:
        Wi = Ki * Zi
    else:
        Wi = Zi / Ki
    diff = 1.0
    while diff > eps and iter < 100:
        LnPhi_Wi = fugZi(pressure, temp, Wi, phasewi, bi, aij, bij, composition)
        # LnWi = np.log(Wi)
        # LnPhi_Wi = np.log(Phi_Wi)
        # di_Wi = (LnPhi_Wi + LnWi)
        # TPDp1 = np.sum(oWi * [di_Wi - di_Zi])
        nWi=np.exp(di_Zi-LnPhi_Wi)    # Firooz Appendix A - 4.1
        Max_diff =max(abs(nWi-Wi))
        if Max_diff < diff:
            diff = Max_diff
        else:
            diff = diff
        oWi=Wi
        LnoWi = np.log(oWi)
        Wi=nWi
        # print(Wi)
        # LnPhi_nWi = fugZi(pressure, temp, Wi, phasewi, bi, aij, bij, composition)
        TPDp1 = np.sum(oWi * [(LnoWi + LnPhi_Wi)- di_Zi])
        sumWi = sum(Wi)
        TPDt = -np.log(sumWi)
        # TPDD = TPD(composition,pressure,temp,phasezi,phasewi,Zi,Wi,bi,aij,bij)
        #-----------------------------------------------------------------------
        # Phi_yi = fugWi(pressure, temp, yi, phasewi, bi, aij, bij, composition)
        # LnPhi_yi = np.log(Phi_yi)
        # TPDf =  np.sum(oWi * [(LnoWi + LnPhi_yi)- di_Zi])
        ###############-------------------------------
        # print('===================================================================================================')
        # print('TPD =', TPDp1, 'Iter =', iter, '<=====>',  'diff==', diff, "--///\\\\--", sumWi, TPDt )
        iter +=1

    return  TPDt


####3#######  Stability test ===================================================
# GENERAL STRATEGY FOR STABILITY TESTING AND PHASE-SPLIT CALCULATION IN TWO AND THREE PHASES

def stability_test(composition,pressure, temp, phasezi,phasewi, Zi, bi, aij, bij,i):
    # from fugacity import fug

    #-----====== loop ======--------------------------------
    Wi = Zi
    nWi = Zi
    oWi = Zi
    minKi = 1.0e10
    iter = 0
    diff = 1.0
    # i=0
    typ=1
    eps = 1.0e-6
    LnZi = np.log(Zi)
    # Phi_Zi = fugZi(pressure, temp, Zi, phasezi, bi, aij, bij, composition)
    LnPhi_Zi = fugZi(cPress, cTemp, Zi, phasezi, bi, aij, bij, composition)
    di_Zi = LnZi + LnPhi_Zi
    KiWil = Kwil(cPress, cTemp, composition)  # Wilson
    #==== test =======================
    Ki = np.zeros((nc, 1))
    for j in range(nc):
        if i == j:
            # Ki[j] = 0.9 / Zi[j]
            Ki[j] = 1.0
        else:
            # Ki[j] = (0.1 / (nc - 1)) / Zi[j]
            Ki[j] = 1.0e-3
    # print(i,Ki)
    if phasewi == ["vapour"]:
        Wi = Ki * Zi
    else:
        Wi = Zi / Ki
    diff = 1.0
    while diff > eps and iter < 1000:
        LnPhi_Wi = fugZi(cPress, cTemp, Wi, phasewi, bi, aij, bij, composition)
        # LnWi = np.log(Wi)
        # LnPhi_Wi = np.log(Phi_Wi)
        # di_Wi = (LnPhi_Wi + LnWi)
        # TPDp1 = np.sum(oWi * [di_Wi - di_Zi])
        nWi=np.exp(di_Zi-LnPhi_Wi)    # Firooz Appendix A - 4.1
        Max_diff =max(abs(nWi-Wi))
        if Max_diff < diff:
            diff = Max_diff
        else:
            diff = diff
        oWi=Wi
        LnoWi = np.log(oWi)
        Wi=nWi
        # print(Wi)
        # LnPhi_nWi = fugZi(pressure, temp, Wi, phasewi, bi, aij, bij, composition)
        TPDp1 = np.sum(oWi * [(LnoWi + LnPhi_Wi)- di_Zi])
        sumWi = sum(Wi)
        TPDi = -np.log(sumWi)
        iter +=1
    return TPDi


# #==== Generate the TPD results for both phases-Single T&P  ===================================================
#
# # temp = 700
# # pressure = 16000
#
# phases=[["vapour"], ["liquid1"]]
# phasesZi=[["vapour"], ["liquid1"]]
# phasesWi=[["vapour"], ["liquid1"]]
# # phasezi=["liquid1"]
# # phasewi=["liquid1"]
# TPDr=[]
# for phasezi in phasesZi:
#     for phasewi in phasesWi:
#         print('            ======================',  phasezi , phasewi  , '=================')
#         Types=[1,2,3,4]
#         # typ=0
#         for typ in Types:
#             print('===================================================================================================')
#             print('type ==', typ,'<==============>' ,'phase ==',phasezi, phasewi)
#             TPD00 = stability(composition,pressure, temp, phasezi,phasewi, Zi, bi, aij, bij,typ)
#             if TPD00 <= 0:
#                 print('INSTABLITY')
#             else:
#                 TPDr.append(TPD00)
#                 Min_TPD = min(TPDr)
#                 if TPD00 <= Min_TPD:
#                     Min_TPD=TPD00
#         Min_TPD = min(TPDr)
#     #
#         print(TPDr, '===================', Min_TPD)
#
#     if Min_TPD>=0:
#         print(1)
#     else:
#         print(0)


#==== loop ===================================================

phases=[["liquid1"], ["vapour"]]
# phasesZi=[["liquid1"], ["vapour"]]
# phasesWi=[["liquid1"], ["vapour"]]
# phasezi=["liquid1"]
# phasewi=["liquid1"]
TPDr = []
temp = Temp0 = 300
cTemp = 300
Temp1 = 800
pressure = Press0 = 1.0e+6
cPress = 1.0e+6
Press1 = 1.0e+6
dT = (Temp1-Temp0) / 10
# dT = 5
# dP=9
dP=(Press1-Press0)/10
i,j = 0,0
while (i< 100 and cPress<220.0e+6):
    j=0
    while (j<100 and cTemp<801) :
        # print( phasezi)
        # TPD00 = stability(composition,pressure, temp, phasezi,phasewi, Zi, bi, aij, bij)
        TPD00 = TPD_minimum(composition,cPress, cTemp, ["liquid1"] ,["liquid1"], Zi, bi, aij, bij)
        TPD01 = TPD_minimum(composition,cPress, cTemp, ["liquid1"],["vapour"], Zi, bi, aij, bij)
        TPD11 = TPD_minimum(composition,cPress, cTemp, ["vapour"],["vapour"], Zi, bi, aij, bij)
        TPD10 = TPD_minimum(composition,cPress, cTemp, ["vapour"],["liquid1"], Zi, bi, aij, bij)
        Min=min(TPD00,TPD01,TPD11,TPD10)
        print(cTemp, '<==>', cPress, '<----->', TPD00, '<----->', TPD01,'<----->', TPD11,'<----->', TPD10)
        if Min >= -1.0e-6:
            S =  [1]
        else:
            S= [ -1]

        print(cTemp, '<==>', cPress, '<----->', Min, "!!!!!!!!!!!!",   S)
        print('+=+=+=+=+=+=+=+=+=+=+=+=+==+=+=+=+=+=+=+=')
        # ---- Print results--------
        # with open(r'TPD-Sign.csv', 'w') as f1:  # need "a" and not w to append to a file, if not will overwrite
        #     f1.close()
        # result = np.hstack((temp, pressure, Min))
        # with open(r'TPD-Sign.csv', 'a') as f1:
        #     headers = ['Temp', 'Press', 'Sign']
        #     writer = csv.writer(f1, delimiter=',', lineterminator='\n')
        #     writer.writerow(headers)
        #     for row in result:
        #         writer.writerow(row)

        j+=1
        cTemp = Temp0 + j * dT
    i+=1
    # cPress = 0
    cTemp = 300
    cPress = Press0 + i * dP

# #---- Print results--------
# with open(r'TPD-Sign.csv', 'w') as f1:  # need "a" and not w to append to a file, if not will overwrite
#     f1.close()
# result= np.hstack((temp, pressure,Min_TPD))
# with open(r'TPD-Sign.csv', 'a') as f1:
#     headers = ['Temp', 'Press', 'Sign']
#     writer = csv.writer(f1,  delimiter=',', lineterminator='\n')
#     writer.writerow(headers)
#     for row in result:
#         writer.writerow(row)

# TPDr=[]
# Types = [1, 2, 3, 4]
# for typ in Types:
#     print('===================================================================================================')
#     print('type ==', typ,'<==============>' ,'phase ==', phase)
#     TPD0 = stability(composition,pressure, temp, phase, Zi, bi, aij, bij,typ)
#     if TPD0 <= 0:
#         print('INSTABLITY')
#     else:
#         TPDr.append(TPD0)
#         Min_TPD = min(TPDr)
#     print(TPDr, '===================',Min_TPD )





#==== Comparision ===============================================================================
# def TPD (composition,pressure, temp, phase, zi, xi, bi, aij, bij):
#     TPD00=stability(composition,pressure, temp, zi, phase ,bi, aij, bij)
#     if TPD00 > 0.0:
#         TPD01=stability(composition,pressure, temp, zi, phase ,bi, aij, bij)
#         if TPD01 > 0.0:
#             minTPD=min(TPD00,TPD01)
#             TPD=stability(composition,pressure, temp, zi, phase ,bi, aij, bij)
#             minTPD=min(minTPD, TPD)
#             return minTPD
#         else:
#             return min(TPD00, TPD01)
#     else:
#         return TPD00








#########
#########
#########
#################################################################################################
########
###########
############     Figure 2   ###############################################################

#==== Generate the TPD results  T/TPD   Fig 2  ===================================================
#
# temp = 600.0
# pressure = 20.0e6
# # pressure = 180
#
# phases=[["vapour"], ["liquid1"]]
# phasesZi=[["vapour"], ["liquid1"]]
# phasesWi=[["vapour"], ["liquid1"]]
# # phasezi=["liquid1"]
# # phasewi=["liquid1"]
# TPDr=[]
# for phasezi in phasesZi:
#     for phasewi in phasesWi:
#         print('======================',  phasezi , phasewi , '=================')
#         # Types=[1,2,3,4]
#         Types=[1]
#         # typ=0
#         for typ in Types:
#             print('===================================================================================================')
#             print('type ==', typ,'<==============>' ,'phase ==',phasezi, phasewi)
#             TPD = stability(composition,pressure, temp, phasezi,phasewi, Zi, bi, aij, bij,typ)
#             if TPD <= 0:
#                 Min_TPD = -1
#             else:
#                 TPDr.append(TPD)
#                 Min_TPD = min(TPDr)
#                 if TPD <= Min_TPD:
#                     Min_TPD=TPD
#         Min_TPD = min(TPDr)
#     #
#         print(TPDr, '===================', Min_TPD)
#
#     if Min_TPD>=0:
#         print(1)
#     else:
#         print(0)


















