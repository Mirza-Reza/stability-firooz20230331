import numpy as np
import math
import matplotlib.pyplot as plt
import scipy.optimize
from scipy.optimize import fsolve


def fug(pressure, temp, xi, phase, bi, aij, bij, composition):

    R = np.float64(8.314472);  # Ideal gas constant [J.mol^{-1}.K^{-1}]  MPa.cm^3/mol.K
    T = np.float64(temp);  # Temperature [K]
    P = np.float64(pressure);  # Pressure [Pa]
    nc = len(composition)  # Components number of the composition


    # =================Compressibility factor roots & Fugacity Coefficients of the cubic EoS====================================
    # ======Parameters ami and bmi are still part of mixing rules calculus===============
    ami =np.array([sum(aij.dot(xi) * xi)])
    bmi =np.array([sum(bij.dot(xi) * xi)]) #sum(bij.dot(xi))
    # ======end of Parameters ami and bmi are still part of mixing rules calculus===============

    A0 = (ami * P) / (pow(R * T, 2))
    B0 =  (bmi * P) / (R * T)

    A=np.array(np.squeeze(A0))
    B=np.array(np.squeeze(B0))

    # print(A,B)
    # CC=np.squeeze(A)
    # Loof=np.array(CC)
    # print(Loof)



    # A=np.array(1.389016)
    # B=np.array(0.154623)

    # A=np.array(1.7199618)
    # B=np.array(0.3538492)



    #============END of ONLY FOR PLOTTING===============================

    rootSol = np.roots([1,B - 1, A - 2 * B - 3 * B*B,B*B + B*B*B- (A * B)])
    roots = np.real(rootSol[np.isreal(rootSol)])
    print(rootSol)
    print(roots)

    if phase == ["liquid1"]  or phase == ["liquid2"] : # phases[0]:
        Zt = min(roots);
        # Zt = max(roots);
        v = (Zt * R * T) / P;
    elif phase == ["vapour"]: #phases[2]:
        Zt = max(roots);
        # Zt = min(roots);
        v = (Zt * R * T) / P;
    else:
        print("the value is not correct")
    bmii = np.array(bi / bmi);
    Z = Zt;

    fugVal= np.exp(
        (bmii * (Z * np.ones((nc, 1)) - np.ones((nc, 1)))) - np.log(Z * np.ones((nc, 1)) - B * np.ones((nc, 1))) - (
                    A / (2 * np.sqrt(2) * B)) * ((2 * (np.dot(aij,xi).reshape(-1,1))) / ami - bmii) * np.log(
            (Z + 2.414 * B) / (Z - 0.414 * B)))
    # print(fugVal, '-----------------------------------')
    return fugVal



    # =================END Compressibility factor roots & Fugacity Coefficients of the cubic EoS====================================

