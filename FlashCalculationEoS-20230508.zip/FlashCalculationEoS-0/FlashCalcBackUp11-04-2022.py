"""
Predictive Peng Robinson 78 EoS  (PPR78) for mixtures
J.-N. Jaubert, F. Mutelet / Fluid Phase Equilibria 224 (2004) 285–304 (doi:10.1016/j.fluid.2004.06.059)
@author: Gustavo Oviedo
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# import functions
import csv
import math
from scipy.optimize import fsolve
import time
from PPR78 import EoS
from mixingRules import mixRules
from fugacity import fug
from fugacityCriteria import fugC
from rachfordRiceEq import rrm
from theta import thetaFunc
import warnings

warnings.filterwarnings("ignore", category=np.VisibleDeprecationWarning)  #I need to check the reason.  =asanyarray(ary)

tic = time.perf_counter()
# ==================Component properties composition & input variables==========================================
# modelEoS= [{'PR78', 'PPR78', 'SRK', 'PC-SAFT', 'CPA'}]
tempMinVal=200  #155.60857142857      #Critical point 203.465 #203.468
tempMaxInVal=270  #155.60857142857    #Critical point203.465  #203.468
tempNumbSpaces=350  #150
tempVal=np.zeros([tempNumbSpaces])
DtempVal=(tempMaxInVal-tempMinVal)/tempNumbSpaces

pressMinVal=.3e6
pressMaxInVal=9.0e6
pressNumbSpaces=200
pressVal=np.zeros([pressNumbSpaces])
DpressVal=(pressMaxInVal-pressMinVal)/pressNumbSpaces

betaPrint=[]
xoPrint=[]
p=0

for dt in range(tempNumbSpaces):
    if dt==0:
        tempVal[dt]=tempMinVal

    else:
        tempVal[dt]=tempVal[dt-1]+DtempVal

for dp in range(pressNumbSpaces):
    if dp==0:
        pressVal[dp]=pressMinVal

    else:
        pressVal[dp]=pressVal[dp-1]+DpressVal

# print("TempertureArray=",tempVal)
# print("lenght=", len(tempVal))

betaStorage= [0] * len(pressVal)
betaEnvelope=[]
tempEnvelope=[]
pressEnvelope=[]
xoEnvelope=[]


for p in range(len(pressVal)):
    pressure = np.float64(pressVal[p]);  #Critical point 5.899e06 Pressure [Pa]
    pressEnvelope.append(pressure)

    for t in tempVal:
        temp = np.float64(t);  # Temperature [K]

        # composition = [
        #     {'name': 'methaneC1', 'z': 0.943, 'Tc': 190.564, 'Pc': 4.599e6, 'w': 0.011},
        #     {'name': 'ethaneC2', 'z': 0.027, 'Tc': 305.32, 'Pc': 4.872e6, 'w': 0.099},
        #     {'name': 'propaneC3', 'z': 0.0074, 'Tc': 369.83, 'Pc': 4.248e6, 'w': 0.153},
        #     {'name': 'nbutane-nC4', 'z': 0.0049, 'Tc': 425.12, 'Pc': 3.796e6, 'w': 0.199},
        #     {'name': 'pentane-nC5', 'z': 0.0027, 'Tc': 469.7, 'Pc': 3.37e6, 'w': 0.251},
        #     {'name': 'nhexane-nC6', 'z': 0.0010, 'Tc': 507.6, 'Pc': 3.025e6, 'w': 0.299},
        #     {'name': 'nitrogenN2', 'z': 0.014, 'Tc': 126.21, 'Pc': 3.39e6, 'w': 0.039}];

        # zi = np.array([[composition[0]['z']],
        #                [composition[1]['z']],
        #                [composition[2]['z']],
        #                [composition[3]['z']],
        #                [composition[4]['z']],
        #                [composition[5]['z']],
        #                [composition[6]['z']]])

        composition = [
            {'name': 'carbon dioxide', 'z': 0.5, 'Tc': 304.16, 'Pc': 7.378e6, 'w': 0.231},
            {'name': 'methane', 'z': 0.5, 'Tc': 190.56, 'Pc': 4.599e6, 'w': 0.01}];
        # composition = [
        #     {'name': 'carbon dioxide', 'z': 0.2, 'Tc': 304.16, 'Pc': 7.378e6, 'w': 0.231},
        #     {'name': 'n_heptane', 'z': 0.8, 'Tc': 540.3, 'Pc': 2.734e6, 'w': 0.3481}];

        zi = np.array([[composition[0]['z']],
                       [composition[1]['z']]])

        xo = np.array([[0.778299, 0.178377],  # WELL WORKING SHOOT for 2 COMPONENT-MIXTURE
                       [0.221701, 0.821623]])  # initial guess of the molar fraction equilibrium composition of zi

        # xo = np.array([[0.665044172630132, 0.951796701776454],  # WELL WORKING SHOOT for 5.899 MPa FOR - COMPONENT-MIXTURE
        #                [0.090553410528368, 0.024988671780748],
        #                [0.062885402787889, 0.005644006805362],
        #                [0.082943080410745, 0.002430105014940],
        #                [0.066063347693634, 0.000694686859085],
        #                [0.028910755723735, 0.000116684846005],
        #                [0.003599830225497,
        #                 0.014329142917407]])  # initial guess of the molar fraction equilibrium composition of zi

        betaInitVal = np.array([0.1, 0.9])   #Initial guess of the phase fraction -beta-  [liquid, vapour]
        betaVal=betaInitVal[1]
        phases = [['liquid'], ['vapour']];

        nph = len(phases)  # phases number

        nc = len(composition)  # Components number of the composition

        theta = np.zeros((1, nph))  # stability function

        # =======================END of Component properties composition & input variables=============================

        # =================Global constants setting of the EoS model ==================================================
        # from PPR78 import EoS

        ai,bi=EoS(pressure,temp,composition)
        # print("ai=", ai)
        # print("bi=", bi)
        # =================END of Global constants setting of the EoS model ============================================

        # =================Mixing rules ================================================================================
        # from mixingRules import mixRules

        aij,bij=mixRules(pressure,temp,composition,ai,bi)
        # print("aij=", aij)
        # print("bij=", bij)
        # =================END of Mixing rules ===========================================================================

        tolf = 1e-06;
        tol = 1000
        iter = 0
        iterMax = 1500
        xrro = xo.copy()
        while tol > tolf and iter < iterMax:
            xro = xo.copy()
            # if temp>=206.9 and temp<208:
            #     print("##################")
            #=================================Fugacity coeficients (phi) loop for every phase=====================================

            phi = np.zeros((nc, nph))
            v = np.zeros((1, nph))
            for i in range(nph):
                xi = xo[:, i]
                if iter < iterMax:
                    phi[:, i] = np.array(fug(pressure, temp, xi, phases[i], bi, aij, bij, composition, phases)).transpose()
                else:
                    phi[:, i] = np.array(fugC(pressure, temp, xi, phases[i], bi, aij, bij, composition)).transpose()
                    # print("phase:", nPhase=fugC(pressure, temp, xi, phases[i], bi, aij, bij, composition) )
                # print("phi=", phi)

            #=================================END of Fugacity coeficients (phi) loop for every phase================================

            # ==================Equilibrium factors Ki & Rachford-Rice equation===================================
            Ki = np.zeros((nc, nph));  # Equilibrium factors
            Xm = np.zeros((nc, nph));  # Ones´ matrix to define the maximum values of the xi composition by row

            Xm = xo == np.max(xo, axis=1).reshape(-1, 1)
            phir = np.max(phi * Xm, axis=1).reshape(-1, 1)  # Reference fugacity coefficients column vector for each component

            Ki = phir / phi
            # print(phir)

            Krm = np.zeros((len(zi), nph - 1));  # Reference equilibrium factors column vector
            for i in range(nph - 1):
                Krm[:, i] = Ki[:, i]
            # Krm = Ki
            # from rachfordRiceEq import rrm

            # betaFunc = fsolve(rrm, [0.1]])


            betaFunc = fsolve(rrm, [betaVal], (zi,Ki, Krm))
            beta = betaInitVal
            for i in range(1,nph):  # enumerate(comp[0:nc]):
                if betaFunc < 0:
                    beta[i] = 0
                else:
                    beta[i] = betaFunc
                    # beta[i-1] = 1 - beta[i]
            beta[0] = 1 - beta[1]
            if beta[0] < 0:
                beta[0] = 0


            # ==============GUARANTED THE SYSTEM HAS AT LEAST TWO EQUILIBRIUM PHASES===============
            zeroPosBeta = np.where(beta == 0)[0]
            nbZero = len(zeroPosBeta)
            # print(zeroPosBeta)
            if nbZero > 1:
                nbZero = nbZero - 1
                zeroPosBeta[0, 0] = []

            for i in range(nbZero):
                if zeroPosBeta == 0:
                    xo = xo[:, [1, 0]]
                    Ki = Ki[:, [1, 0]]
                    beta = beta[[1, 0]]
                    phases[0], phases[1] = phases[1], phases[0]
                else:
                    xo = xo
                    Ki = Ki
                    beta = beta
                    phases[0], phases[1] = phases[0], phases[1]

                    # print("beta=", beta)
            # ==============END of GUARANTED THE SYSTEM HAS AT LEAST TWO EQUILIBRIUM PHASES===============

           # theta[0, 1] = thetaFunc(zi, nph, Ki, beta)  #Eq. 3.77 Pag.43 Reinaldo´s Thesis
            theta[0,1] = thetaFunc(zi, nph, Ki, beta)  #Eq. 3.77 Pag.43 Reinaldo´s Thesis
            betaVal=beta[1]
            # print("theta=", theta)



            ##Updating molar composition Eq. 3.73 pag.42 Reinaldo´s Thesis
            Xri = zi * pow((np.vstack(Ki[:, 0]) + (np.vstack(Ki[:, nph - 1]) - Krm) * beta[1]), -1)
            # print("Xri=", Xri)
            # print("xro=", xro)
            # TAKING INTO THE ACCOUNT THETA PARAMETER FOR THE STABILITY ANALYSYS
            for j in range(nph):
                #xo[:, j] = np.array(Xri).flatten() * Ki[:, j] * math.exp(theta[0,j])  #Residual Function, Eq. 3.78 Pag. 47 Reinaldo´s Thesis
                xo[:, j] = np.array(Xri).flatten() * Ki[:, j] * math.exp(theta[0,j])  #* 0.1 + .9 * xro[:, j]  #Residual Function, Eq. 3.78 Pag. 47 Reinaldo´s Thesis
                # xo[:, j] = np.array(Xri).flatten() * Ki[:, j] * math.exp(theta[0, j])  #Residual Function, Eq. 3.78 Pag. 47 Reinaldo´s Thesis
                # print("x_i=", xo)

            delta = abs(xo - xro)
            tol = sum((sum(delta)))
            iter = iter + 1
            #print("iter=",iter)
            #print("temperatue[K]=", temp)
            if tol <= tolf:
                print(beta)
                if beta[0] >1:
                    beta[0]=1
                betaEnvelope.append(beta[0])
                tempEnvelope.append(temp)
                xoEnvelope.append(xo.tolist())
                # aaa = np.zeros(xo.shape)
                # aaa[0, 0] = temp
                # xoEnvelope.append(aaa.tolist())
                # print("betaVal=",betaEnvelope)
                # sssp.append(p)
                # ssst.append(t)
                # sssb.append(beta[0])

        if (iter>=iterMax):
            print("xxxxxx")
            xo = xrro.copy()
            beta=[0,0]
            betaEnvelope.append(beta[0])
            tempEnvelope.append(temp)
            xoEnvelope.append(xo.tolist())

    betaStorage[p]=betaEnvelope
    betaEnvelope=[]
    # betaPrint = pd.DataFrame(betaEnvelope, tempEnvelope, pressEnvelope)
    # print(betaPrint)
    # betaPrint.to_csv(r'D:\GEOCelis_Drive\Dpbx_GEOCelis\FlowSimulation\FlashCalculationEoS\beta.csv',';')

    # betaEnvelopeFlat=[item for sublist in rawData for item in sublist]
    # with open("beta.csv","w+",newline='') as mycsv:
    #     csvWriter=csv.writer(mycsv,delimiter=';')
    #     csvWriter.writerows(betaEnvelopeFlat)

    xoEnvelopeFlat=[item for sublist in xoEnvelope for item in sublist]
    with open("xo2CM.csv","w+",newline='') as my_csv:
        csvWriter=csv.writer(my_csv,delimiter=';')
        csvWriter.writerows(xoEnvelopeFlat)
    print("betaValues=", betaPrint)
    # print("xoValues=", xoEnvelope)
    # print("Temp=", tempVal)
    print("dTemp=", DtempVal)

# betaPrint= pd.DataFrame(betaStorage)
betaPrint= pd.DataFrame(betaStorage, pressVal, tempVal)
# betaPrint= pd.DataFrame(betaStorage, pressVal, tempEnvelope)

betaPrint.to_csv(r'D:\GEOCelis_Drive\Dpbx_GEOCelis\FlowSimulation\FlashCalculationEoS\beta2CM.csv',';')

xT=tempVal
yP=pressVal
betaStorage=np.array(betaStorage)
XT, YP=np.meshgrid(xT, yP)
plt.contourf(XT, YP, betaStorage)
plt.colorbar
plt.show()
print(betaPrint)
toc = time.perf_counter()
print(f"Time= {toc - tic:0.4f} seconds")

# ssst = np.linspace(tempMinVal, tempMaxInVal, 20)
# sssp = np.linspace(pressMinVal, pressMaxInVal, 20)
# sssb = np.array(sssb).reshape((20,20))
# plt.contour(np.array(ssst), np.array(sssp), sssb)
# plt.show()




# envelopeDataPrint = pd.DataFrame(betaEnvelope, tempEnvelope, pressEnvelope)
# print(betaPrint)
# betaPrint.to_csv(r'D:\GEOCelis_Drive\Dpbx_GEOCelis\FlowSimulation\FlashCalculationEoS\beta.csv',';')

# ==================end of Equilibrium factors Ki & Rachford-Rice equation===================================
