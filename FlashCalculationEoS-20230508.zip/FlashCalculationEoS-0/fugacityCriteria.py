import numpy as np
import math
import matplotlib.pyplot as plt
import scipy.optimize
from scipy.optimize import fsolve


def fugC(pressure, temp, xi, phase, bi, aij, bij, composition):

    R = np.float64(8.314472);  # Ideal gas constant [J.mol^{-1}.K^{-1}]  MPa.cm^3/mol.K
    T = np.float64(temp);  # Temperature [K]
    P = np.float64(pressure);  # Pressure [Pa]
    nc = len(composition)  # Components number of the composition


    # =================Compressibility factor roots & Fugacity Coefficients of the cubic EoS====================================
    # ======Parameters ami and bmi are still part of mixing rules calculus===============
    ami =np.array([sum(aij.dot(xi) * xi)])
    bmi =np.array([sum(bij.dot(xi) * xi)]) #sum(bij.dot(xi))
    # ======end of Parameters ami and bmi are still part of mixing rules calculus===============

    A = (ami * P) / (pow(R * T, 2))
    B = bmi * P / (R * T)


    #============END of ONLY FOR PLOTTING===============================

    rootSol = np.roots([1,B - 1, A - 2 * B - 3 * B*B,B*B + B*B*B- (A * B)])
    roots = np.real(rootSol[np.isreal(rootSol)])
    # print(rootSol)
    # print(roots)
    bmii = np.array(bi / bmi);

    if len(roots)>1:
        Zl=min(roots)
        Zv=max(roots)
        phiL=np.dot(xi,(
            (bmii * (Zl * np.ones((nc, 1)) - np.ones((nc, 1)))) - np.log(Zl * np.ones((nc, 1)) - B * np.ones((nc, 1))) - (
                    A / (2 * np.sqrt(2) * B)) * ((2 * (np.dot(aij, xi).reshape(-1, 1))) / ami - bmii) * np.log(
                (Zl + 2.414 * B) / (Zl - 0.414 * B))))

        phiV=np.dot(xi, (
            (bmii * (Zv * np.ones((nc, 1)) - np.ones((nc, 1)))) - np.log(Zv * np.ones((nc, 1)) - B * np.ones((nc, 1))) - (
                    A / (2 * np.sqrt(2) * B)) * ((2 * (np.dot(aij, xi).reshape(-1, 1))) / ami - bmii) * np.log(
                (Zv + 2.414 * B) / (Zv - 0.414 * B))))

        if phiV<phiL:
            Z=Zv
            nPhase={'vapour'}
        else:
            Z=Zl
            nPhase={'liquid'}

    else:
        Z=roots
        nPhase=phase

    fugCVal= np.exp(
        (bmii * (Z * np.ones((nc, 1)) - np.ones((nc, 1)))) - np.log(Z * np.ones((nc, 1)) - B * np.ones((nc, 1))) - (
                    A / (2 * np.sqrt(2) * B)) * ((2 * (np.dot(aij,xi).reshape(-1,1))) / ami - bmii) * np.log(
            (Z + 2.414 * B) / (Z - 0.414 * B)))
    return fugCVal
    # =================END Compressibility factor roots & Fugacity Coefficients of the cubic EoS====================================
